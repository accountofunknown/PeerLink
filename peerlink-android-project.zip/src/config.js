export const APP = { name: 'PeerLink', version: '1.0.0', scheme: 'peerlink' };
