import { Emitter } from './util.js';

export const bus = new Emitter();

export const DEFAULT_SETTINGS = {
  theme: 'auto',            // auto | light | dark
  accent: '#6366f1',
  server: { mode: 'cloud', host: '', port: 443, path: '/', key: 'peerjs', secure: true },
  ice: { mode: 'default', servers: '', relayOnly: false },
  notify: true,
  sound: true,
  preview: true,            // show message text in notifications
  haptics: true,
  receipts: true,           // send read receipts
  typing: true,             // send typing indicators
  autoAcceptMB: 25,         // auto-accept files up to N MB from contacts (0 = ask always)
  autoAcceptImages: true,
  callsFromUnknown: false,
  enterSend: false,
  pin: null,                // { salt, hash }
  autoLock: 60,             // seconds in background before locking
  debug: false,
  ttlDefault: 0,
};

export const S = {
  profile: '',
  me: null,                 // { id, name, emoji, color, bio, created }
  settings: { ...DEFAULT_SETTINGS },
  contacts: new Map(),
  chats: new Map(),
  presence: new Map(),      // id -> { online, route, rtt, since }
  typing: new Map(),        // chatId -> Map(peerId -> expiresAt)
  netState: 'idle',
  active: null,             // currently open chat id
  visible: true,
  locked: false,
};

const lsKey = () => `peerlink:${S.profile || 'main'}:settings`;

export function loadSettings() {
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(lsKey()) || '{}'); } catch { /* ignore */ }
  S.settings = {
    ...DEFAULT_SETTINGS, ...saved,
    server: { ...DEFAULT_SETTINGS.server, ...(saved.server || {}) },
    ice: { ...DEFAULT_SETTINGS.ice, ...(saved.ice || {}) },
  };
  return S.settings;
}

export function saveSettings(patch) {
  const next = { ...S.settings, ...patch };
  if (patch.server) next.server = { ...S.settings.server, ...patch.server };
  if (patch.ice) next.ice = { ...S.settings.ice, ...patch.ice };
  S.settings = next;
  try { localStorage.setItem(lsKey(), JSON.stringify(next)); } catch { /* quota */ }
  bus.emit('settings', patch);
}
