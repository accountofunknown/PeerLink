// Messaging logic: contacts, direct chats, mesh groups, receipts, reactions,
// edits, disappearing messages, and the persistent outbox.

import { S, bus } from './state.js';
import * as D from './data.js';
import * as db from './db.js';
import { net } from './net.js';
import { transfer } from './transfer.js';
import { uid, now, tick, normId, validId, throttle } from './util.js';
import { showNotification, clearNotification, beep, haptic } from './notify.js';

const OUTBOX_TTL = 14 * 24 * 3600 * 1000;
const MAX_REQUESTS = 40;
const clip = (v, n) => String(v ?? '').slice(0, n);

class ChatService {
  init() {
    net.on('data', (id, d) => this.onData(id, d));
    net.on('link', (link, info) => this.onLink(link, info));
    net.on('down', (id) => this.onDown(id));
    net.on('state', (st) => { if (st === 'online') setTimeout(() => this.retryOutbox(), 2500); });
    transfer.hooks = {
      resolveChat: (from, gid) => this.resolveChat(from, gid),
      targets: (ch) => this.targets(ch),
      incoming: (ch, m) => this.afterIncoming(ch, m),
    };
    setInterval(() => this.sweep(), 30000);
    setInterval(() => this.retryOutbox(), 45000);
    setTimeout(() => this.sweep(), 3000);
  }

  /* =============================== contacts =============================== */

  async addContact(rawId, name = '') {
    const id = normId(rawId);
    if (!validId(id)) throw new Error('That is not a valid PeerLink ID.');
    if (id === S.me.id) throw new Error('That is your own ID.');
    const old = D.getContact(id);
    if (old && !old.implicit && !old.blocked) throw new Error('Already in your contacts.');
    const c = { emoji: '', color: '', fp: null, ...(old || {}), id, name: clip(name, 40) || old?.name || '', alias: old?.alias || '', addedAt: now(), blocked: false, implicit: false };
    await D.saveContact(c);
    const ch = await this.ensureDm(id);
    if (ch.request) { ch.request = false; await D.saveChat(ch); }
    net.connect(id).catch(() => {});
    return c;
  }

  async updateContact(id, patch) {
    const c = D.getContact(id);
    if (!c) return;
    await D.saveContact({ ...c, ...patch });
  }

  async removeContact(id) {
    await D.removeContact(id);
    const ch = D.getChat(id);
    if (ch && ch.type === 'dm') { ch.request = true; await D.saveChat(ch); }
  }

  async setBlocked(id, blocked) {
    const c = D.getContact(id) || { id, name: '', alias: '', emoji: '', color: '', fp: null, addedAt: now(), implicit: true };
    await D.saveContact({ ...c, blocked });
    if (blocked) net.closeLink(id);
  }

  async trustKey(id) {
    const c = D.getContact(id);
    if (!c?.keyChanged) return;
    await D.saveContact({ ...c, fp: c.keyChanged.fp, pk: c.keyChanged.pk, keyChanged: null, verified: false });
  }

  async ensureDm(id) {
    let ch = D.getChat(id);
    if (!ch) {
      ch = { id, type: 'dm', ts: now(), unread: 0, pinned: false, muted: false, request: !D.isContact(id), ttl: S.settings.ttlDefault || 0, created: now() };
      await D.saveChat(ch);
    }
    return ch;
  }

  async acceptRequest(chatId) {
    const ch = D.getChat(chatId);
    if (!ch) return;
    if (ch.type === 'dm') {
      const info = net.link(chatId)?.info;
      if (!D.getContact(chatId)) await D.saveContact({ id: chatId, name: info?.name || '', alias: '', emoji: info?.emoji || '', color: info?.color || '', fp: info?.fp || null, pk: info?.pk, addedAt: now(), blocked: false });
    }
    ch.request = false;
    await D.saveChat(ch);
    this.markRead(chatId); // receipts were withheld while this was a request
  }

  broadcastProfile() {
    const me = S.me;
    for (const id of net.onlineIds()) net.trySend(id, { t: 'profile', name: me.name, emoji: me.emoji, color: me.color, bio: me.bio || '' });
  }

  /* =============================== presence =============================== */

  async onLink(link, info) {
    const id = link.id;
    if (D.isBlocked(id)) { net.closeLink(id); return; }
    const c = D.getContact(id);
    if (c) {
      let dirty = false;
      for (const k of ['name', 'emoji', 'color']) if (info[k] !== undefined && c[k] !== info[k]) { c[k] = info[k]; dirty = true; }
      if (!c.fp) { c.fp = info.fp; c.pk = info.pk; dirty = true; }
      else if (c.fp !== info.fp && c.keyChanged?.fp !== info.fp) { c.keyChanged = { fp: info.fp, pk: info.pk, at: now() }; dirty = true; bus.emit('key-changed', id); }
      c.lastSeen = now();
      if (dirty) await D.saveContact(c);
    }
    S.presence.set(id, { online: true, since: now(), route: link.route });
    bus.emit('presence', id);
    this.flushOutbox(id);
  }

  async onDown(id) {
    S.presence.set(id, { online: false, since: now() });
    const c = D.getContact(id);
    if (c) { c.lastSeen = now(); await D.saveContact(c); }
    bus.emit('presence', id);
  }

  async probeAll() {
    const ids = [...S.contacts.values()].filter((c) => !c.blocked && !c.implicit).map((c) => c.id);
    const queue = [...ids];
    const worker = async () => {
      while (queue.length) {
        const id = queue.shift();
        if (net.isOnline(id)) continue;
        try { await net.connect(id); } catch { S.presence.set(id, { online: false, since: now() }); bus.emit('presence', id); }
      }
    };
    await Promise.all([worker(), worker(), worker()]);
  }

  /* =============================== dispatch =============================== */

  async onData(from, d) {
    if (D.isBlocked(from)) return;
    switch (d.t) {
      case 'msg': return this.onMsg(from, d);
      case 'ack': return this.onAck(from, d);
      case 'edit': return this.onEdit(from, d);
      case 'del': return this.onDel(from, d);
      case 'react': return this.onReact(from, d);
      case 'typing': return this.onTyping(from, d);
      case 'profile': return this.onProfile(from, d);
      case 'ginv': case 'gupd': return this.onGroup(from, d);
      case 'gleave': return this.onGleave(from, d);
      case 'ttl': return this.onTtl(from, d);
      default:
        if (typeof d.t === 'string' && d.t[0] === 'f') return transfer.onData(from, d);
    }
  }

  /** Resolve (or create) the local chat an incoming item belongs to. */
  resolveChat(from, gid) {
    if (D.isBlocked(from)) return null;
    if (gid) {
      const ch = D.getChat(`g:${clip(gid, 80)}`);
      return ch && !ch.left && ch.members.includes(from) ? ch : null;
    }
    let ch = D.getChat(from);
    if (!ch) {
      const pending = [...S.chats.values()].filter((c) => c.request).length;
      if (!D.isContact(from) && pending >= MAX_REQUESTS) return null;
      ch = { id: from, type: 'dm', ts: now(), unread: 0, pinned: false, muted: false, request: !D.isContact(from), ttl: S.settings.ttlDefault || 0, created: now() };
      S.chats.set(from, ch);
      D.saveChat(ch);
    }
    return ch;
  }

  targets(ch) {
    if (ch.type === 'dm') return D.isBlocked(ch.id) ? [] : [ch.id];
    return ch.left ? [] : ch.members.filter((x) => x !== S.me.id && !D.isBlocked(x));
  }

  async afterIncoming(ch, m) {
    await D.touchChat(ch, m, { unread: 1 });
    const here = S.visible && S.active === ch.id && !S.locked;
    if (here) { this.markRead(ch.id); return; }
    this.notifyIncoming(ch, m);
  }

  notifyIncoming(ch, m) {
    if (ch.muted) return;
    beep('in');
    haptic('light');
    const sender = ch.type === 'group' ? `${D.nameOf(m.from)} · ${D.chatTitle(ch)}` : D.chatTitle(ch);
    const body = ch.request ? 'Message request' : S.settings.preview ? D.preview(m) : 'New message';
    if (S.visible && !S.locked) bus.emit('banner', { chatId: ch.id, title: sender, body });
    else showNotification({ key: ch.id, title: S.settings.preview || !ch.request ? sender : 'PeerLink', body, chatId: ch.id });
  }

  /* =============================== receiving =============================== */

  async onMsg(from, d) {
    if (typeof d.id !== 'string' || d.id.length > 80) return;
    const ch = this.resolveChat(from, d.g);
    if (!ch) return;
    const dup = await D.getMsg(d.id);
    if (dup) { if (dup.from === from) net.trySend(from, { t: 'ack', ids: [d.id], s: 'd' }); return; }
    const m = { id: d.id, chatId: ch.id, from, ts: Math.min(Number(d.ts) || now(), now()), rts: now(), kind: 'text', text: clip(d.text, 20000), reactions: {}, status: 'received' };
    if (d.rt && typeof d.rt === 'object') m.replyTo = { id: clip(d.rt.id, 80), from: clip(d.rt.from, 60), text: clip(d.rt.text, 140), kind: clip(d.rt.kind, 10) };
    if (typeof d.fw === 'string') m.fwd = clip(d.fw, 60);
    if (ch.ttl) m.exp = now() + ch.ttl * 1000;
    await D.saveMsg(m);
    this.clearTyping(ch.id, from);
    net.trySend(from, { t: 'ack', ids: [m.id], s: 'd' });
    await this.afterIncoming(ch, m);
  }

  async onAck(from, d) {
    if (!Array.isArray(d.ids) || (d.s !== 'd' && d.s !== 'r')) return;
    const status = d.s === 'r' ? 'read' : 'delivered';
    for (const id of d.ids.slice(0, 500)) {
      await D.patchMsg(String(id), (m) => {
        if (m.from !== S.me.id) return false;
        const ch = D.getChat(m.chatId);
        if (ch?.type === 'group') {
          m.acks = m.acks || {};
          if (D.rank(m.acks[from]) >= D.rank(status)) return false;
          m.acks[from] = status;
          const others = ch.members.filter((x) => x !== S.me.id);
          const min = Math.min(...others.map((x) => D.rank(m.acks[x] || 'sent')));
          const agg = min >= 4 ? 'read' : min >= 3 ? 'delivered' : 'sent';
          if (D.rank(agg) > D.rank(m.status)) m.status = agg; else if (m.status === 'sending' || m.status === 'queued') m.status = 'sent';
        } else {
          if (D.rank(m.status) >= D.rank(status)) return false;
          m.status = status;
        }
      });
    }
  }

  async onEdit(from, d) {
    await D.patchMsg(String(d.id), (m) => {
      if (m.from !== from || m.kind !== 'text' || m.deleted) return false;
      m.text = clip(d.text, 20000);
      m.edited = Math.min(Number(d.ts) || now(), now());
    });
    this.refreshLast(String(d.id));
  }

  async onDel(from, d) {
    const m = await D.patchMsg(String(d.id), (x) => {
      if (x.from !== from || x.deleted) return false;
      x.deleted = true; x.text = ''; x.reactions = {}; x.replyTo = null;
      if (x.file) { x.file = { ...x.file, thumb: null, state: 'deleted' }; }
    });
    if (m?.file) transfer.drop(m.file.tid);
    this.refreshLast(m?.id);
  }

  async refreshLast(id) {
    if (!id) return;
    const m = await D.getMsg(id);
    const ch = m && D.getChat(m.chatId);
    if (ch?.last?.id === id) { ch.last.text = D.preview(m); await D.saveChat(ch); }
  }

  async onReact(from, d) {
    const emoji = d.e == null ? null : clip(d.e, 8);
    await D.patchMsg(String(d.id), (m) => {
      const ch = D.getChat(m.chatId);
      if (!ch || m.deleted) return false;
      if (ch.type === 'dm' ? from !== ch.id : !ch.members.includes(from)) return false;
      applyReaction(m, from, emoji);
    });
  }

  onTyping(from, d) {
    const chatId = d.g ? `g:${clip(d.g, 80)}` : from;
    const ch = D.getChat(chatId);
    if (!ch || ch.request || (ch.type === 'group' && !ch.members.includes(from))) return;
    let map = S.typing.get(chatId);
    if (!map) S.typing.set(chatId, (map = new Map()));
    map.set(from, now() + 5000);
    bus.emit('typing', chatId);
    setTimeout(() => this.clearTyping(chatId, from, true), 5200);
  }

  clearTyping(chatId, from, onlyExpired = false) {
    const map = S.typing.get(chatId);
    if (!map) return;
    if (onlyExpired && (map.get(from) || 0) > now()) return;
    map.delete(from);
    bus.emit('typing', chatId);
  }

  async onProfile(from, d) {
    const c = D.getContact(from);
    if (!c) return;
    await D.saveContact({ ...c, name: clip(d.name, 40), emoji: clip(d.emoji, 8), color: clip(d.color, 16) });
  }

  /* =============================== sending =============================== */

  /** Send now if possible, otherwise persist to the outbox. */
  async deliver(to, payload, key, queue = true) {
    try {
      await net.send(to, payload);
      return true;
    } catch {
      if (queue && key) await db.put('outbox', { key, to, payload, ts: now() });
      return false;
    }
  }

  async sendAck(to, ids, s) {
    if (net.trySend(to, { t: 'ack', ids, s })) return;
    const key = `${to}|ack|${s}`;
    const ex = await db.get('outbox', key);
    const merged = [...new Set([...(ex?.payload.ids || []), ...ids])].slice(-500);
    await db.put('outbox', { key, to, payload: { t: 'ack', ids: merged, s }, ts: ex?.ts || now() });
  }

  async sendText(chatId, text, { replyTo, fwd } = {}) {
    text = String(text || '').trim();
    const ch = D.getChat(chatId);
    if (!text || !ch || ch.left) return null;
    const m = { id: uid(), chatId, from: S.me.id, ts: tick(), kind: 'text', text: text.slice(0, 20000), reactions: {}, status: 'sending', acks: {} };
    if (replyTo) m.replyTo = { id: replyTo.id, from: replyTo.from, text: D.preview(replyTo).slice(0, 140), kind: replyTo.kind };
    if (fwd) m.fwd = fwd;
    if (ch.ttl) m.exp = now() + ch.ttl * 1000;
    await D.saveMsg(m);
    await D.touchChat(ch, m);
    this.dispatch(ch, m);
    return m;
  }

  async dispatch(ch, m) {
    const payload = { t: 'msg', id: m.id, ts: m.ts, text: m.text, rt: m.replyTo || undefined, fw: m.fwd || undefined, g: ch.type === 'group' ? ch.gid : undefined };
    const targets = this.targets(ch);
    let sent = 0;
    await Promise.all(targets.map(async (to) => { if (await this.deliver(to, payload, `${to}|${m.id}`)) sent++; }));
    const status = sent > 0 ? 'sent' : 'queued';
    // never downgrade: an ack may already have moved the status past "sent"
    await D.patchMsg(m.id, (x) => { if (x.status !== 'sending' && x.status !== 'queued') return false; x.status = status; });
  }

  async retryMessage(id) {
    const m = await D.getMsg(id);
    const ch = m && D.getChat(m.chatId);
    if (!m || !ch || m.from !== S.me.id) return;
    if (m.file) return transfer.retry(id);
    await D.patchMsg(id, (x) => { x.status = 'sending'; });
    this.dispatch(ch, m);
  }

  async editMessage(id, text) {
    text = String(text || '').trim();
    const m = await D.getMsg(id);
    if (!m || m.from !== S.me.id || m.kind !== 'text' || m.deleted || !text || text === m.text) return;
    const ch = D.getChat(m.chatId);
    const ts = now();
    await D.patchMsg(id, (x) => { x.text = text.slice(0, 20000); x.edited = ts; });
    this.refreshLast(id);
    for (const to of this.targets(ch)) this.deliver(to, { t: 'edit', id, text: text.slice(0, 20000), ts, g: ch.type === 'group' ? ch.gid : undefined }, `${to}|edit|${id}`);
  }

  async deleteMessage(id, everyone) {
    const m = await D.getMsg(id);
    if (!m) return;
    const ch = D.getChat(m.chatId);
    if (everyone && m.from === S.me.id && ch) {
      await D.patchMsg(id, (x) => { x.deleted = true; x.text = ''; x.reactions = {}; x.replyTo = null; if (x.file) x.file = { ...x.file, thumb: null, state: 'deleted' }; });
      if (m.file) { transfer.cancel(m.file.tid); transfer.drop(m.file.tid); }
      for (const to of this.targets(ch)) this.deliver(to, { t: 'del', id, g: ch.type === 'group' ? ch.gid : undefined }, `${to}|del|${id}`);
      this.refreshLast(id);
    } else {
      if (m.file) transfer.drop(m.file.tid);
      await D.deleteMsgLocal(m);
      if (ch?.last?.id === id) await this.rebuildLast(ch);
    }
  }

  async rebuildLast(ch) {
    const [m] = await db.msgPage(ch.id, null, 1);
    ch.last = m ? { id: m.id, ts: m.ts, from: m.from, text: D.preview(m), kind: m.kind } : null;
    await D.saveChat(ch);
  }

  async react(id, emoji) {
    const m = await D.getMsg(id);
    if (!m || m.deleted) return;
    const ch = D.getChat(m.chatId);
    const mine = Object.entries(m.reactions || {}).find(([, v]) => v.includes(S.me.id))?.[0];
    const next = mine === emoji ? null : emoji;
    await D.patchMsg(id, (x) => applyReaction(x, S.me.id, next));
    for (const to of this.targets(ch)) this.deliver(to, { t: 'react', id, e: next, g: ch.type === 'group' ? ch.gid : undefined }, `${to}|react|${id}`);
  }

  typing = throttle((chatId) => {
    if (!S.settings.typing) return;
    const ch = D.getChat(chatId);
    if (!ch || ch.request) return;
    for (const to of this.targets(ch)) net.trySend(to, { t: 'typing', g: ch.type === 'group' ? ch.gid : undefined });
  }, 2500);

  async markRead(chatId) {
    const ch = D.getChat(chatId);
    if (!ch) return;
    if (ch.unread) { ch.unread = 0; await D.saveChat(ch); }
    clearNotification(chatId);
    if (!S.settings.receipts || ch.request) return;
    const msgs = await db.msgPage(chatId, null, 100);
    const byFrom = new Map();
    for (const m of msgs) {
      if (m.from === S.me.id || m.kind === 'system' || m.kind === 'call' || m.rs) continue;
      if (!byFrom.has(m.from)) byFrom.set(m.from, []);
      byFrom.get(m.from).push(m.id);
    }
    for (const [to, ids] of byFrom) {
      await this.sendAck(to, ids, 'r');
      for (const id of ids) D.patchMsg(id, (m) => { m.rs = true; });
    }
  }

  async forward(m, chatIds) {
    const label = D.nameOf(m.from);
    for (const id of chatIds) {
      if (m.file) {
        const blob = await transfer.blob(m.file.tid);
        if (!blob) throw new Error('This file is no longer available to forward.');
        const f = new File([blob], m.file.name, { type: m.file.mime });
        await transfer.sendFile(id, f, { kind: m.kind, dur: m.file.dur, wave: m.file.wave, caption: m.text, fwd: label });
      } else await this.sendText(id, m.text, { fwd: label });
    }
  }

  async sys(ch, text) {
    const m = { id: uid(), chatId: ch.id, from: 'sys', ts: tick(), kind: 'system', text, reactions: {} };
    await D.saveMsg(m);
    await D.touchChat(ch, m);
  }

  async logCall(peerId, { dir, video, dur, result }) {
    const ch = await this.ensureDm(peerId);
    const kind = video ? 'video' : 'voice';
    const text = result === 'missed' ? `Missed ${kind} call` : result === 'declined' ? `Declined ${kind} call` : result === 'failed' ? `${dir === 'out' ? 'Outgoing' : 'Incoming'} ${kind} call failed` : `${dir === 'out' ? 'Outgoing' : 'Incoming'} ${kind} call`;
    const m = { id: uid(), chatId: ch.id, from: dir === 'out' ? S.me.id : peerId, ts: tick(), kind: 'call', text, call: { dir, video: !!video, dur: dur || 0, result }, reactions: {} };
    if (ch.ttl) m.exp = now() + ch.ttl * 1000;
    await D.saveMsg(m);
    await D.touchChat(ch, m, { unread: result === 'missed' ? 1 : 0 });
  }

  /* =============================== outbox =============================== */

  async flushOutbox(to) {
    const items = (await db.byIndex('outbox', 'byTo', to)).sort((a, b) => a.ts - b.ts);
    for (const it of items) {
      if (now() - it.ts > OUTBOX_TTL) { await db.del('outbox', it.key); continue; }
      if (!net.trySend(to, it.payload)) break;
      await db.del('outbox', it.key);
      if (it.payload.t === 'msg') D.patchMsg(it.payload.id, (m) => { if (D.rank(m.status) >= D.rank('sent')) return false; m.status = 'sent'; });
    }
  }

  async retryOutbox() {
    if (!net.online) return;
    let items;
    try { items = await db.all('outbox'); } catch { return; }
    const tos = [...new Set(items.map((i) => i.to))];
    let dialed = 0;
    for (const to of tos) {
      if (net.isOnline(to)) { this.flushOutbox(to); continue; }
      if (D.isBlocked(to) || dialed >= 3) continue;
      dialed++;
      net.connect(to).catch(() => {});
    }
  }

  async outboxCount() { return db.count('outbox'); }

  /* =============================== groups =============================== */

  groupPayload(ch) { return { gid: ch.gid, title: ch.title, admin: ch.admin, members: ch.members, names: ch.names || {}, ver: ch.ver }; }

  pushGroup(ch, toIds, t = 'gupd') {
    for (const to of toIds) if (to !== S.me.id) this.deliver(to, { t, g: this.groupPayload(ch) }, `${to}|g|${ch.gid}`);
  }

  async createGroup(title, memberIds) {
    const ids = [...new Set(memberIds.filter((x) => x !== S.me.id))];
    if (!ids.length) throw new Error('Pick at least one contact.');
    const gid = uid();
    const names = { [S.me.id]: S.me.name };
    for (const id of ids) names[id] = D.nameOf(id);
    const ch = { id: `g:${gid}`, type: 'group', gid, title: clip(title.trim(), 60) || 'New group', members: [S.me.id, ...ids], admin: S.me.id, names, ver: 1, ts: now(), unread: 0, pinned: false, muted: false, created: now(), ttl: S.settings.ttlDefault || 0 };
    await D.saveChat(ch);
    await this.sys(ch, 'You created this group');
    this.pushGroup(ch, ids, 'ginv');
    return ch;
  }

  async onGroup(from, d) {
    const g = d.g;
    if (!g || typeof g.gid !== 'string' || g.gid.length > 80 || !Array.isArray(g.members) || g.members.length > 64 || !g.members.every(validId) || !g.members.includes(g.admin) || !Number.isInteger(g.ver)) return;
    const me = S.me.id;
    const id = `g:${g.gid}`;
    const ex = D.getChat(id);
    const names = {};
    for (const m of g.members) names[m] = clip(g.names?.[m] || '', 40);
    if (!ex) {
      if (!g.members.includes(me) || from !== g.admin || D.isBlocked(from)) return;
      const ch = { id, type: 'group', gid: g.gid, title: clip(g.title, 60) || 'Group', members: g.members, admin: g.admin, names, ver: g.ver, ts: now(), unread: 0, pinned: false, muted: false, request: !D.isContact(from), created: now(), ttl: 0 };
      await D.saveChat(ch);
      const m = { id: uid(), chatId: id, from: 'sys', ts: tick(), kind: 'system', text: `${D.nameOf(from)} added you to the group`, reactions: {} };
      await D.saveMsg(m);
      await D.touchChat(ch, m, { unread: 1 });
      this.notifyIncoming(ch, { ...m, kind: 'text', text: `You were added to “${ch.title}”`, from });
      return;
    }
    if (from !== ex.admin || g.ver <= ex.ver) return;
    if (!g.members.includes(me)) {
      ex.left = true; ex.ver = g.ver; ex.members = g.members;
      await D.saveChat(ex);
      await this.sys(ex, 'You were removed from this group');
      return;
    }
    const added = g.members.filter((x) => !ex.members.includes(x));
    const removed = ex.members.filter((x) => !g.members.includes(x));
    const renamed = clip(g.title, 60) !== ex.title;
    const adminChanged = g.admin !== ex.admin;
    ex.names = { ...ex.names, ...names };
    Object.assign(ex, { title: clip(g.title, 60) || ex.title, members: g.members, admin: g.admin, ver: g.ver, left: false });
    await D.saveChat(ex);
    for (const x of added) await this.sys(ex, `${D.nameOf(x)} joined`);
    for (const x of removed) await this.sys(ex, `${D.nameOf(x)} was removed`);
    if (renamed) await this.sys(ex, `Group renamed to “${ex.title}”`);
    if (adminChanged) await this.sys(ex, `${D.nameOf(g.admin)} is now the admin`);
  }

  async _mutateGroup(ch, fn) {
    if (ch.admin !== S.me.id) throw new Error('Only the admin can change the group.');
    const before = [...ch.members];
    fn(ch);
    ch.ver++;
    await D.saveChat(ch);
    return before;
  }

  async addMembers(ch, ids) {
    const fresh = ids.filter((x) => !ch.members.includes(x) && x !== S.me.id);
    if (!fresh.length) return;
    await this._mutateGroup(ch, (c) => { c.members = [...c.members, ...fresh]; for (const x of fresh) c.names = { ...c.names, [x]: D.nameOf(x) }; });
    for (const x of fresh) await this.sys(ch, `${D.nameOf(x)} joined`);
    this.pushGroup(ch, fresh, 'ginv');
    this.pushGroup(ch, ch.members.filter((x) => !fresh.includes(x)));
  }

  async removeMember(ch, id) {
    const before = await this._mutateGroup(ch, (c) => { c.members = c.members.filter((x) => x !== id); });
    await this.sys(ch, `${D.nameOf(id)} was removed`);
    this.pushGroup(ch, before);
  }

  async renameGroup(ch, title) {
    title = clip(title.trim(), 60);
    if (!title || title === ch.title) return;
    await this._mutateGroup(ch, (c) => { c.title = title; });
    await this.sys(ch, `Group renamed to “${title}”`);
    this.pushGroup(ch, ch.members);
  }

  async leaveGroup(ch) {
    if (ch.left) return;
    const others = ch.members.filter((x) => x !== S.me.id);
    if (ch.admin === S.me.id && others.length) {
      ch.admin = others[0];
      ch.members = others;
      ch.ver++;
      this.pushGroup(ch, others);
      ch.members = [...others, S.me.id];
    } else if (others.length) {
      for (const to of others) this.deliver(to, { t: 'gleave', gid: ch.gid }, `${to}|gl|${ch.gid}`);
    }
    ch.left = true;
    await D.saveChat(ch);
    await this.sys(ch, 'You left the group');
  }

  async onGleave(from, d) {
    const ch = D.getChat(`g:${clip(d.gid, 80)}`);
    if (!ch || !ch.members.includes(from) || ch.left) return;
    ch.members = ch.members.filter((x) => x !== from);
    if (ch.admin === S.me.id) { ch.ver++; await D.saveChat(ch); this.pushGroup(ch, ch.members); }
    else await D.saveChat(ch);
    await this.sys(ch, `${D.nameOf(from)} left`);
  }

  /* =============================== chat settings =============================== */

  async setTtl(ch, sec) {
    ch.ttl = sec;
    await D.saveChat(ch);
    await this.sys(ch, sec ? `Disappearing messages: messages vanish after ${sec < 3600 ? sec / 60 + ' min' : sec < 86400 ? sec / 3600 + ' h' : sec / 86400 + ' d'}` : 'Disappearing messages turned off');
    for (const to of this.targets(ch)) this.deliver(to, { t: 'ttl', ttl: sec, g: ch.type === 'group' ? ch.gid : undefined }, `${to}|ttl|${ch.id}`);
  }

  async onTtl(from, d) {
    const chatId = d.g ? `g:${clip(d.g, 80)}` : from;
    const ch = D.getChat(chatId);
    if (!ch || ch.request) return;
    if (ch.type === 'group' && ch.admin !== from) return;
    if (ch.type === 'dm' && ch.id !== from) return;
    const sec = [0, 300, 3600, 86400, 604800].includes(d.ttl) ? d.ttl : 0;
    if (sec === (ch.ttl || 0)) return;
    ch.ttl = sec;
    await D.saveChat(ch);
    await this.sys(ch, sec ? `${D.nameOf(from)} set messages to disappear after ${sec < 3600 ? sec / 60 + ' min' : sec < 86400 ? sec / 3600 + ' h' : sec / 86400 + ' d'}` : `${D.nameOf(from)} turned off disappearing messages`);
  }

  async sweep() {
    try {
      for (const m of await db.expired(now())) {
        if (m.file) await transfer.drop(m.file.tid);
        await D.deleteMsgLocal(m);
        const ch = D.getChat(m.chatId);
        if (ch?.last?.id === m.id) await this.rebuildLast(ch);
      }
    } catch (e) { console.warn('sweep', e); }
  }

  async setPinned(id, v) { const ch = D.getChat(id); if (ch) { ch.pinned = v; await D.saveChat(ch); } }
  async setMuted(id, v) { const ch = D.getChat(id); if (ch) { ch.muted = v; await D.saveChat(ch); } }

  async clearChat(id) {
    const ch = D.getChat(id);
    if (!ch) return;
    for (const m of await db.msgAll(id)) { if (m.file) await transfer.drop(m.file.tid); await D.deleteMsgLocal(m); }
    ch.last = null; ch.unread = 0;
    await D.saveChat(ch);
  }

  async deleteChat(id) {
    await this.clearChat(id);
    S.chats.delete(id);
    await db.del('chats', id);
    bus.emit('chats', id);
  }
}

function applyReaction(m, who, emoji) {
  m.reactions = m.reactions || {};
  for (const [e, list] of Object.entries(m.reactions)) {
    const next = list.filter((x) => x !== who);
    if (next.length) m.reactions[e] = next; else delete m.reactions[e];
  }
  if (emoji) m.reactions[emoji] = [...(m.reactions[emoji] || []), who];
}

export const chat = new ChatService();
