// File transfer engine (works for files, photos, videos and voice notes).
//
// Protocol over the authenticated PeerJS data link:
//   foffer  -> faccept{from} | freject
//   fc{i,crc,d} ...          (64 KiB chunks, CRC32 each, ordered + reliable channel)
//   fack{n}  every 8 chunks  (sliding window of 64 chunks = 4 MiB in flight)
//   fend     -> fdone        (receiver reassembles, verifies size, stores)
//   fcancel  either side
// The receiver persists 1 MiB groups in IndexedDB, so an interrupted transfer
// resumes from the last stored group when the link comes back.

import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { Emitter, uid, now, tick, crc32, toU8, safeName, throttle, b64 } from './util.js';
import { S, bus } from './state.js';
import * as D from './data.js';
import * as db from './db.js';
import { net } from './net.js';
import { isNative } from './notify.js';

export const CHUNK = 65536;
const GROUP = 16;
const WINDOW = 64;
const ACK_EVERY = 8;
const KEEP_MAX = 32 * 1024 * 1024;
export const MAX_SIZE = 4 * 1024 * 1024 * 1024;
const KINDS = new Set(['file', 'image', 'video', 'voice']);

export const kindOf = (mime = '') => (mime.startsWith('image/') && !mime.includes('svg') ? 'image' : mime.startsWith('video/') ? 'video' : 'file');

export async function makeThumb(file) {
  try {
    const bmp = await createImageBitmap(file);
    const sc = Math.min(1, 240 / Math.max(bmp.width, bmp.height));
    const w = Math.max(1, Math.round(bmp.width * sc)), h = Math.max(1, Math.round(bmp.height * sc));
    const cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    cv.getContext('2d').drawImage(bmp, 0, 0, w, h);
    const out = { thumb: cv.toDataURL('image/jpeg', 0.6), w: bmp.width, h: bmp.height };
    bmp.close?.();
    return out;
  } catch { return null; }
}

const validThumb = (t) => (typeof t === 'string' && t.startsWith('data:image/jpeg;base64,') && t.length < 70000 ? t : null);
const int = (v, lo, hi) => (Number.isInteger(v) && v >= lo && v <= hi ? v : null);

class Transfers extends Emitter {
  constructor() {
    super();
    this.sessions = new Map(); // `${tid}|${peer}` -> session
    this.files = new Map();    // tid -> File/Blob kept for outgoing
    this.urls = new Map();     // tid -> object URL
    this.hooks = { resolveChat: () => null, targets: () => [], incoming: async () => {} };
    this.changed = throttle(() => this.emit('progress'), 120);
  }

  async init() {
    net.on('down', (id) => this.onDown(id));
    net.on('link', (link) => this.onLink(link.id));
    const recs = await db.all('transfers');
    for (const r of recs) {
      if (r.dir !== 'in') continue;
      this.sessions.set(r.key, { ...r, buf: [], bufN: 0, flushed: r.persisted, next: r.persisted, samples: [], speed: 0, state: r.state === 'offered' ? 'offered' : 'paused', _q: Promise.resolve(), _fl: Promise.resolve() });
    }
  }

  /* ----------------------------- outgoing ----------------------------- */

  async sendFile(chatOrId, file, o = {}) {
    const ch = typeof chatOrId === 'string' ? D.getChat(chatOrId) : chatOrId;
    if (!ch || ch.left) throw new Error('Chat unavailable');
    if (file.size > MAX_SIZE) throw new Error('File too large (max 4 GB)');
    const tid = uid();
    const kind = o.kind || kindOf(file.type);
    let thumb = null, w, h;
    if (kind === 'image') { const t = await makeThumb(file); if (t) ({ thumb, w, h } = t); }
    const meta = { tid, name: safeName(o.name || file.name), size: file.size, mime: file.type || 'application/octet-stream', thumb, w, h, dur: o.dur || 0, wave: o.wave || null, state: 'sending' };
    const m = { id: tid, chatId: ch.id, from: S.me.id, ts: tick(), kind, text: o.caption || '', file: meta, reactions: {}, status: 'sending', acks: {} };
    if (o.fwd) m.fwd = o.fwd;
    if (ch.ttl) m.exp = now() + ch.ttl * 1000;
    this.files.set(tid, file);
    if (file.size <= KEEP_MAX) await db.put('blobs', file, tid);
    await D.saveMsg(m);
    await D.touchChat(ch, m);
    for (const to of this.hooks.targets(ch)) this._startOut(ch, m, to);
    return m;
  }

  _startOut(ch, m, to) {
    const s = { key: `${m.id}|${to}`, tid: m.id, peer: to, dir: 'out', chatId: ch.id, g: ch.type === 'group' ? ch.gid : undefined, name: m.file.name, size: m.file.size, mime: m.file.mime, total: Math.ceil(m.file.size / CHUNK), state: 'offering', next: 0, acked: 0, run: 0, samples: [], speed: 0 };
    this.sessions.set(s.key, s);
    this._offer(s, m, false);
    return s;
  }

  async _offer(s, m, resume) {
    m = m || (await D.getMsg(s.tid));
    if (!m) return;
    const f = m.file;
    try {
      await net.send(s.peer, { t: 'foffer', tid: s.tid, ts: m.ts, g: s.g, name: f.name, size: f.size, mime: f.mime, kind: m.kind, thumb: f.thumb, w: f.w, h: f.h, dur: f.dur, wave: f.wave, cap: m.text, fw: m.fwd, total: s.total, chunk: CHUNK, resume: !!resume });
      if (s.state === 'paused') s.state = 'offering';
    } catch {
      if (s.state === 'offering' || s.state === 'sending') s.state = 'paused';
    }
    this.emit('progress');
  }

  async _onAccept(from, d) {
    const s = this.sessions.get(`${d.tid}|${from}`);
    if (!s || s.dir !== 'out' || s.state === 'cancelled' || s.state === 'done') return;
    const start = int(d.from, 0, s.total) ?? 0;
    s.state = 'sending';
    s.next = s.acked = start;
    s.sentAll = false;
    const run = ++s.run;
    this.emit('progress');
    this._pump(s, run);
  }

  async _pump(s, run) {
    const file = this.files.get(s.tid) || (await db.get('blobs', s.tid));
    if (!file) { net.trySend(s.peer, { t: 'fcancel', tid: s.tid }); s.state = 'failed'; await this._updateOutMsg(s.tid); return; }
    const live = () => s.run === run && s.state === 'sending';
    try {
      for (let i = s.next; i < s.total; i++) {
        if (!live()) return;
        while (i - s.acked >= WINDOW) { await this._waitAck(s); if (!live()) return; }
        const buf = await file.slice(i * CHUNK, Math.min(file.size, (i + 1) * CHUNK)).arrayBuffer();
        await net.drain(s.peer);
        if (!live()) return;
        if (!net.trySend(s.peer, { t: 'fc', tid: s.tid, i, crc: crc32(new Uint8Array(buf)), d: buf })) throw new Error('no-connection');
        s.next = i + 1;
      }
      if (!live()) return;
      s.sentAll = true;
      if (!net.trySend(s.peer, { t: 'fend', tid: s.tid, total: s.total })) throw new Error('no-connection');
    } catch (e) {
      if (live()) { s.state = 'paused'; net.log('W', 'transfer paused', s.tid, e.message); this.emit('progress'); }
    }
  }

  async _waitAck(s) {
    const before = s.acked;
    await new Promise((res) => { s._wake = res; s._wt = setTimeout(res, 30000); });
    clearTimeout(s._wt);
    if (s.acked === before && s.state === 'sending') throw new Error('ack-timeout');
  }

  _onAck(from, d) {
    const s = this.sessions.get(`${d.tid}|${from}`);
    if (!s || s.dir !== 'out') return;
    const n = int(d.n, 0, s.total);
    if (n == null) return;
    s.acked = Math.max(s.acked, n);
    this._speed(s, s.acked * CHUNK);
    s._wake?.();
    this.changed();
  }

  async _onDone(from, d) {
    const s = this.sessions.get(`${d.tid}|${from}`);
    if (!s || s.dir !== 'out') return;
    s.state = d.ok === false ? 'failed' : 'done';
    s.acked = s.total;
    s._wake?.();
    await this._updateOutMsg(s.tid);
    this.emit('progress');
  }

  /** Derive the persisted message state from all recipient sessions. */
  async _updateOutMsg(tid) {
    const ss = [...this.sessions.values()].filter((x) => x.tid === tid && x.dir === 'out');
    if (!ss.length) return;
    const active = ss.some((x) => ['offering', 'sending', 'paused'].includes(x.state));
    const done = ss.filter((x) => x.state === 'done').length;
    let state = 'sending';
    if (!active) {
      if (done > 0) state = 'sent';
      else if (ss.every((x) => x.state === 'rejected')) state = 'rejected';
      else if (ss.every((x) => x.state === 'cancelled')) state = 'cancelled';
      else state = 'failed';
    }
    await D.patchMsg(tid, (m) => {
      if (!m.file) return false;
      m.file.state = state;
      if (done === ss.length && D.rank(m.status) < D.rank('delivered')) m.status = 'delivered';
      else if (done > 0 && D.rank(m.status) < D.rank('sent')) m.status = 'sent';
      else if (state === 'failed') m.status = 'failed';
    });
  }

  /* ----------------------------- incoming ----------------------------- */

  async onData(from, d) {
    switch (d.t) {
      case 'foffer': return this._onOffer(from, d);
      case 'faccept': return this._onAccept(from, d);
      case 'freject': return this._onReject(from, d);
      case 'fc': { const s = this.sessions.get(`${d.tid}|${from}`); if (s?.dir === 'in') this._enqueue(s, () => this._onChunk(s, d)); return; }
      case 'fend': { const s = this.sessions.get(`${d.tid}|${from}`); if (s?.dir === 'in') this._enqueue(s, () => this._onEnd(s)); return; }
      case 'fack': return this._onAck(from, d);
      case 'fdone': return this._onDone(from, d);
      case 'fcancel': return this._onCancel(from, d);
    }
  }

  _enqueue(s, fn) {
    s._q = (s._q || Promise.resolve()).then(fn).catch((e) => net.log('E', 'transfer queue', e?.message || e));
  }

  async _onOffer(from, d) {
    if (typeof d.tid !== 'string' || d.tid.length > 80) return;
    const size = int(d.size, 0, MAX_SIZE);
    if (size == null || d.chunk !== CHUNK || d.total !== Math.ceil(size / CHUNK)) { net.trySend(from, { t: 'freject', tid: d.tid }); return; }
    const ch = this.hooks.resolveChat(from, d.g);
    if (!ch) { net.trySend(from, { t: 'freject', tid: d.tid }); return; }
    const key = `${d.tid}|${from}`;
    let s = this.sessions.get(key);
    const prev = await D.getMsg(d.tid);
    if (prev) {
      if (prev.from !== from || !prev.file) return; // id collision / hijack attempt
      if (prev.file.state === 'done') { net.trySend(from, { t: 'fdone', tid: d.tid, ok: true }); return; }
      if (prev.file.state === 'rejected' || prev.file.state === 'cancelled') { net.trySend(from, { t: 'freject', tid: d.tid }); return; }
      if (!s) s = this._newIn(from, ch, d, size, prev.file.state === 'receiving' ? 'paused' : 'offered');
      if (s.state === 'paused' || (s.state === 'receiving')) await this.accept(key); // resume
      return;
    }
    const kind = KINDS.has(d.kind) ? d.kind : 'file';
    const m = {
      id: d.tid, chatId: ch.id, from, ts: Math.min(Number(d.ts) || now(), now()), rts: now(), kind,
      text: String(d.cap || '').slice(0, 2000), reactions: {}, status: 'received',
      file: { tid: d.tid, name: safeName(d.name), size, mime: String(d.mime || 'application/octet-stream').slice(0, 100), thumb: validThumb(d.thumb), w: int(d.w, 1, 100000) || undefined, h: int(d.h, 1, 100000) || undefined, dur: Number(d.dur) > 0 && Number(d.dur) < 86400 ? Number(d.dur) : 0, wave: Array.isArray(d.wave) ? d.wave.slice(0, 64).map((n) => Math.max(0, Math.min(1, Number(n) || 0))) : null, state: 'offered' },
    };
    if (typeof d.fw === 'string') m.fwd = d.fw.slice(0, 60);
    if (ch.ttl) m.exp = now() + ch.ttl * 1000;
    await D.saveMsg(m);
    s = this._newIn(from, ch, d, size, 'offered');
    await db.put('transfers', this._rec(s));
    await this.hooks.incoming(ch, m);
    if (this.shouldAuto(from, m, ch)) await this.accept(key);
  }

  _newIn(from, ch, d, size, state) {
    const s = { key: `${d.tid}|${from}`, tid: d.tid, peer: from, dir: 'in', chatId: ch.id, name: safeName(d.name), size, mime: String(d.mime || '').slice(0, 100), total: Math.ceil(size / CHUNK), state, next: 0, persisted: 0, flushed: 0, buf: [], bufN: 0, samples: [], speed: 0, _q: Promise.resolve(), _fl: Promise.resolve() };
    this.sessions.set(s.key, s);
    return s;
  }

  _rec(s) { return { key: s.key, tid: s.tid, peer: s.peer, dir: 'in', chatId: s.chatId, name: s.name, size: s.size, mime: s.mime, total: s.total, persisted: s.persisted, state: s.state }; }

  shouldAuto(from, m, ch) {
    if (ch.request || !D.isContact(from)) return false;
    const f = m.file, mb = (S.settings.autoAcceptMB || 0) * 1024 * 1024;
    if (m.kind === 'voice' && f.size <= 10 * 1024 * 1024) return true;
    if (m.kind === 'image' && S.settings.autoAcceptImages && f.size <= 20 * 1024 * 1024) return true;
    return mb > 0 && f.size <= mb;
  }

  async accept(key) {
    const s = this.sessions.get(key);
    if (!s || s.dir !== 'in' || s.state === 'done') return;
    await s._fl; // make sure `persisted` is final
    s.state = 'receiving';
    s.next = s.persisted;
    s.flushed = s.persisted;
    s.buf = []; s.bufN = 0;
    s.samples = [];
    await db.put('transfers', this._rec(s));
    await D.patchMsg(s.tid, (m) => { if (!m.file || m.file.state === 'receiving') return false; m.file.state = 'receiving'; });
    if (!net.trySend(s.peer, { t: 'faccept', tid: s.tid, from: s.persisted })) s.state = 'paused';
    this.emit('progress');
  }

  async reject(key) {
    const s = this.sessions.get(key);
    if (!s || s.dir !== 'in') return;
    net.trySend(s.peer, { t: 'freject', tid: s.tid });
    await this._closeIn(s, 'rejected');
  }

  async _closeIn(s, state) {
    s.state = state;
    s.buf = [];
    await db.delChunks(s.tid);
    await db.del('transfers', s.key);
    await D.patchMsg(s.tid, (m) => { if (!m.file) return false; m.file.state = state; });
    this.emit('progress');
  }

  async _onChunk(s, d) {
    if (s.state !== 'receiving') return;
    let u8 = toU8(d.d);
    if (!u8 && d.d instanceof Blob) u8 = new Uint8Array(await d.d.arrayBuffer());
    if (!u8) return;
    if (d.i < s.next) return;                       // duplicate
    if (d.i !== s.next) return this._abortIn(s, 'sequence error');
    const expected = d.i < s.total - 1 ? CHUNK : s.size - (s.total - 1) * CHUNK;
    if (u8.length !== expected || crc32(u8) !== d.crc) return this._abortIn(s, 'corrupt chunk');
    s.buf.push(u8);
    s.next++;
    this._speed(s, s.next * CHUNK);
    if (s.next % GROUP === 0 || s.next === s.total) this._flush(s);
    if (s.next % ACK_EVERY === 0 || s.next === s.total) net.trySend(s.peer, { t: 'fack', tid: s.tid, n: s.next });
    this.changed();
  }

  _flush(s) {
    const parts = s.buf.splice(0);
    if (!parts.length) return;
    const start = s.flushed;
    s.flushed += parts.length;
    s._fl = s._fl.then(async () => {
      await db.put('chunks', new Blob(parts), `${s.tid}:${Math.floor(start / GROUP)}`);
      s.persisted = Math.max(s.persisted, start + parts.length);
      await db.put('transfers', this._rec(s));
    }).catch((e) => net.log('E', 'flush failed', e?.message || e));
  }

  async _onEnd(s) {
    if (s.state !== 'receiving') return;
    if (s.next !== s.total) return this._abortIn(s, 'incomplete');
    this._flush(s);
    await s._fl;
    const parts = [];
    for (let k = 0; k < Math.ceil(s.total / GROUP); k++) {
      const b = await db.get('chunks', `${s.tid}:${k}`);
      if (!b) return this._abortIn(s, 'missing data');
      parts.push(b);
    }
    const blob = new Blob(parts, { type: s.mime || 'application/octet-stream' });
    if (blob.size !== s.size) return this._abortIn(s, 'size mismatch');
    await db.put('blobs', blob, s.tid);
    await db.delChunks(s.tid);
    await db.del('transfers', s.key);
    s.state = 'done';
    await D.patchMsg(s.tid, (m) => { if (!m.file) return false; m.file.state = 'done'; });
    net.trySend(s.peer, { t: 'fdone', tid: s.tid, ok: true });
    this.emit('progress');
    bus.emit('file-received', s.tid);
  }

  async _abortIn(s, why) {
    net.log('E', 'transfer aborted', s.tid, why);
    net.trySend(s.peer, { t: 'fdone', tid: s.tid, ok: false });
    await this._closeIn(s, 'failed');
  }

  async _onReject(from, d) {
    const s = this.sessions.get(`${d.tid}|${from}`);
    if (!s || s.dir !== 'out') return;
    s.state = 'rejected'; s.run++; s._wake?.();
    await this._updateOutMsg(s.tid);
    this.emit('progress');
  }

  async _onCancel(from, d) {
    const s = this.sessions.get(`${d.tid}|${from}`);
    if (!s) return;
    if (s.dir === 'in') { if (s.state !== 'done') await this._closeIn(s, 'cancelled'); return; }
    s.state = 'cancelled'; s.run++; s._wake?.();
    await this._updateOutMsg(s.tid);
    this.emit('progress');
  }

  /** User-initiated cancel (either direction). */
  async cancel(tid) {
    for (const s of [...this.sessions.values()].filter((x) => x.tid === tid)) {
      if (['done', 'rejected', 'cancelled', 'failed'].includes(s.state)) continue;
      net.trySend(s.peer, { t: 'fcancel', tid });
      if (s.dir === 'in') await this._closeIn(s, 'cancelled');
      else { s.state = 'cancelled'; s.run++; s._wake?.(); }
    }
    await this._updateOutMsg(tid);
    this.emit('progress');
  }

  /** Retry a stalled/failed outgoing transfer. */
  async retry(msgId) {
    const m = await D.getMsg(msgId);
    if (!m?.file || m.from !== S.me.id) return false;
    const ch = D.getChat(m.chatId);
    const file = this.files.get(msgId) || (await db.get('blobs', msgId));
    if (!ch || !file) return false;
    this.files.set(msgId, file);
    await D.patchMsg(msgId, (x) => { x.file.state = 'sending'; if (x.status === 'failed') x.status = 'sending'; });
    for (const to of this.hooks.targets(ch)) {
      const old = this.sessions.get(`${msgId}|${to}`);
      if (old?.state === 'done') continue;
      if (old) { old.run++; this.sessions.delete(old.key); }
      this._startOut(ch, m, to);
    }
    return true;
  }

  /* ----------------------------- link events ----------------------------- */

  onDown(id) {
    for (const s of this.sessions.values()) {
      if (s.peer !== id) continue;
      if (s.dir === 'out' && (s.state === 'sending' || s.state === 'offering')) { s.state = 'paused'; s.run++; s._wake?.(); }
      if (s.dir === 'in' && s.state === 'receiving') { s.state = 'paused'; s.buf = []; }
    }
    this.emit('progress');
  }

  onLink(id) {
    for (const s of this.sessions.values()) {
      if (s.peer === id && s.dir === 'out' && (s.state === 'paused' || s.state === 'offering')) this._offer(s, null, true);
    }
  }

  /* ----------------------------- progress ----------------------------- */

  _speed(s, bytes) {
    const t = now();
    s.samples.push([t, bytes]);
    while (s.samples.length > 2 && t - s.samples[0][0] > 4000) s.samples.shift();
    const a = s.samples[0], b = s.samples[s.samples.length - 1];
    s.speed = b[0] - a[0] > 300 ? Math.max(0, ((b[1] - a[1]) / (b[0] - a[0])) * 1000) : s.speed;
  }

  /** Aggregate view of a file's live transfer state (null when no live session). */
  progress(tid) {
    const ss = [...this.sessions.values()].filter((x) => x.tid === tid);
    if (!ss.length) return null;
    const size = ss[0].size;
    const outs = ss.filter((x) => x.dir === 'out');
    let state, bytes, speed = 0;
    if (outs.length) {
      const order = ['sending', 'paused', 'offering', 'done', 'rejected', 'cancelled', 'failed'];
      state = ss.map((x) => x.state).sort((a, b) => order.indexOf(a) - order.indexOf(b))[0];
      bytes = Math.min(size, outs.reduce((n, x) => n + x.acked * CHUNK, 0) / outs.length);
      speed = outs.reduce((n, x) => n + (x.state === 'sending' ? x.speed : 0), 0);
    } else {
      const s = ss[0];
      state = s.state;
      bytes = Math.min(size, s.next * CHUNK);
      speed = s.state === 'receiving' ? s.speed : 0;
    }
    return { state, bytes, size, speed, eta: speed > 1 ? (size - bytes) / speed : Infinity, peers: ss.length };
  }

  activeSessions() {
    return [...this.sessions.values()].filter((s) => ['sending', 'receiving', 'paused', 'offering'].includes(s.state));
  }

  /* ----------------------------- storage ----------------------------- */

  async blob(tid) { return this.files.get(tid) || (await db.get('blobs', tid)) || null; }

  async url(tid) {
    let u = this.urls.get(tid);
    if (u) return u;
    const b = await this.blob(tid);
    if (!b) return null;
    u = URL.createObjectURL(b);
    this.urls.set(tid, u);
    return u;
  }

  async has(tid) { return !!(await this.blob(tid)); }

  async drop(tid) {
    const u = this.urls.get(tid);
    if (u) URL.revokeObjectURL(u);
    this.urls.delete(tid);
    this.files.delete(tid);
    await db.del('blobs', tid).catch(() => {});
    await db.delChunks(tid).catch(() => {});
    for (const [k, s] of [...this.sessions]) if (s.tid === tid) { s.run++; s._wake?.(); this.sessions.delete(k); await db.del('transfers', k).catch(() => {}); }
  }

  async _writeNative(blob, name, directory, folder) {
    const path = `${folder ? folder + '/' : ''}${Date.now()}_${safeName(name)}`;
    const SLICE = 3 * 1024 * 1024;
    let first = true;
    for (let off = 0; off < Math.max(1, blob.size); off += SLICE) {
      const data = b64(new Uint8Array(await blob.slice(off, off + SLICE).arrayBuffer()));
      if (first) { await Filesystem.writeFile({ path, data, directory, recursive: true }); first = false; }
      else await Filesystem.appendFile({ path, data, directory });
    }
    return Filesystem.getUri({ path, directory });
  }

  /** Save to the device's Documents/PeerLink folder (falls back to the share sheet). */
  async saveToDevice(m) {
    const blob = await this.blob(m.file.tid);
    if (!blob) throw new Error('File not available');
    if (!isNative()) { this._download(blob, m.file.name); return 'downloaded'; }
    try {
      await this._writeNative(blob, m.file.name, Directory.Documents, 'PeerLink');
      return 'saved';
    } catch (e) {
      net.log('W', 'save failed, using share sheet', e?.message || e);
      await this.share(m);
      return 'shared';
    }
  }

  async share(m) {
    const blob = await this.blob(m.file.tid);
    if (!blob) throw new Error('File not available');
    if (!isNative()) {
      const f = new File([blob], m.file.name, { type: m.file.mime });
      if (navigator.canShare?.({ files: [f] })) await navigator.share({ files: [f], title: m.file.name });
      else this._download(blob, m.file.name);
      return;
    }
    const { uri } = await this._writeNative(blob, m.file.name, Directory.Cache, 'share');
    await Share.share({ title: m.file.name, url: uri, dialogTitle: 'Open or share file' });
  }

  _download(blob, name) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
  }
}

export const transfer = new Transfers();
