import { createRequire } from 'module';
import http from 'http';
import fs from 'fs';
import path from 'path';
const require = createRequire('/home/claude/.npm-global/lib/node_modules/playwright/package.json');
const { chromium } = require('playwright');
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname));
const dist = path.join(root, 'dist');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
const server = http.createServer((q, r) => {
  const p = path.join(dist, decodeURIComponent(new URL(q.url, 'http://x').pathname).replace(/^\/$/, '/index.html'));
  fs.readFile(p, (e, d) => { if (e) { r.writeHead(404); r.end(); } else { r.writeHead(200, { 'content-type': mime[path.extname(p)] || 'application/octet-stream' }); r.end(d); } });
}).listen(0);
const port = server.address().port;
const shots = path.join(root, 'shots'); fs.mkdirSync(shots, { recursive: true });

let failures = 0;
const ok = (c, m) => { if (c) console.log('  ✓', m); else { failures++; console.log('  ✗ FAIL:', m); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const until = async (fn, ms = 8000, what = '') => { const t = Date.now(); for (;;) { try { const v = await fn(); if (v) return v; } catch {} if (Date.now() - t > ms) throw new Error('timeout: ' + what); await sleep(80); } };

const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream', '--disable-features=WebRtcHideLocalIpsWithMdns', '--no-sandbox', '--autoplay-policy=no-user-gesture-required'] });
const ctx = await browser.newContext({ viewport: { width: 390, height: 800 }, deviceScaleFactor: 2, permissions: ['camera', 'microphone', 'clipboard-read', 'clipboard-write'] });
const errors = [];
async function device(name, id) {
  const page = await ctx.newPage();
  page.on('pageerror', (e) => { errors.push(`${name}: ${e.message}`); console.log(`[${name} pageerror]`, e.message); });
  page.on('console', (m) => { if (m.type() === 'error') { errors.push(`${name}: ${m.text()}`); console.log(`[${name} console.error]`, m.text().slice(0, 300)); } });
  await page.goto(`http://localhost:${port}/index.html?p=${name}&debug`);
  await page.waitForSelector('.onboard');
  await page.fill('.onboard input[placeholder="Your name"]', name[0].toUpperCase() + name.slice(1));
  await page.fill('.onboard .id-row input', id);
  await page.click('.onboard .btn.primary');
  await page.waitForSelector('.tabbar');
  await until(() => page.evaluate(() => window.__pl.net.state === 'online'), 8000, `${name} online`);
  return page;
}
const ev = (p, fn, arg) => p.evaluate(fn, arg);

console.log('\n# Onboarding & connectivity');
const A = await device('alice', 'alice-test-1');
const B = await device('bob', 'bob-test-22');
const C = await device('carol', 'carol-test-3');
ok(true, 'three devices onboarded and connected to mock signaling');
await A.screenshot({ path: path.join(shots, '01-chats-empty.png') });

console.log('\n# Add contact via UI + first message');
await A.click('.tabbtn[aria-label="Contacts"]');
await A.click('.fab[aria-label="Add contact"]');
await A.fill('.sheet input[placeholder^="e.g."]', 'bob-test-22');
await A.fill('.sheet input[placeholder="Name (optional)"]', 'Bob');
await A.click('.sheet .btn.primary.wide');
await A.waitForSelector('.page[data-page="chat"]');
ok(true, 'chat opened after adding contact');
await until(() => ev(A, () => window.__pl.net.isOnline('bob-test-22')), 8000, 'A↔B link');
ok(true, 'authenticated P2P link established (signed handshake)');
await A.fill('.composer textarea', 'Hello Bob 👋 emoji ✓');
await A.click('.send-btn');
await until(() => ev(B, () => window.__pl.D.getChat('alice-test-1')?.last?.text?.includes('Hello Bob')), 8000, 'B got msg');
ok(true, 'B received message (as a request from unknown sender)');
ok(await ev(B, () => window.__pl.D.getChat('alice-test-1').request === true), 'unknown sender flagged as message request');
ok(await ev(B, () => window.__pl.D.getChat('alice-test-1').unread === 1), 'unread counter incremented');
await until(async () => (await ev(A, async () => (await window.__pl.db.msgAll('bob-test-22')).find((m) => m.kind === 'text')?.status)) === 'delivered', 6000, 'delivered');
ok(true, 'A sees "delivered" ack');

console.log('\n# B accepts request, opens chat, replies, read receipts, typing');
await B.click('.crow');
await B.waitForSelector('.page[data-page="chat"] .banner.warn');
await B.click('.banner.warn .btn.primary');
await B.waitForSelector('.banner.warn', { state: 'detached' });
await B.fill('.composer textarea', 'Hi Alice!');
await until(() => ev(A, () => (window.__pl.S.typing.get('bob-test-22')?.size || 0) > 0), 4000, 'typing').then(() => ok(true, 'A sees typing indicator from B')).catch(() => ok(false, 'typing indicator'));
await B.click('.send-btn');
await until(async () => (await ev(A, async () => (await window.__pl.db.msgAll('bob-test-22')).find((m) => m.kind === 'text' && m.from === window.__pl.S.me.id)?.status)) === 'read', 6000, 'read');
ok(true, 'A sees "read" receipt after B opened the chat');
await A.screenshot({ path: path.join(shots, '02-chat.png') });

console.log('\n# Reactions, reply, edit, delete');
const firstId = await ev(A, async () => (await window.__pl.db.msgAll('bob-test-22')).find((m) => m.kind === 'text' && m.from === window.__pl.S.me.id).id);
await ev(A, (id) => window.__pl.chat.react(id, '❤️'), firstId);
await until(async () => (await ev(B, async (id) => (await window.__pl.D.getMsg(id))?.reactions?.['❤️']?.length, firstId)) === 1, 5000, 'reaction');
ok(true, 'reaction synced to B');
await ev(A, (id) => window.__pl.chat.editMessage(id, 'Hello Bob (edited)'), firstId);
await until(async () => (await ev(B, async (id) => (await window.__pl.D.getMsg(id))?.text, firstId)) === 'Hello Bob (edited)', 5000, 'edit');
ok(true, 'edit synced to B');
await ev(A, async () => { const m = (await window.__pl.db.msgAll('bob-test-22')).find((x) => x.from === 'bob-test-22'); await window.__pl.chat.sendText('bob-test-22', 'reply!', { replyTo: m }); });
await until(async () => (await ev(B, async () => (await window.__pl.db.msgAll('alice-test-1')).some((m) => m.replyTo && m.text === 'reply!'))), 5000, 'reply');
ok(true, 'reply with quote delivered');
await ev(A, (id) => window.__pl.chat.deleteMessage(id, true), firstId);
await until(async () => (await ev(B, async (id) => (await window.__pl.D.getMsg(id))?.deleted, firstId)) === true, 5000, 'del');
ok(true, 'delete-for-everyone synced');

console.log('\n# File transfer (small, auto-accept) + integrity');
const mk = (size) => `(() => { const b = new Uint8Array(${size}); let x = 12345; for (let i = 0; i < b.length; i++) { x = (x * 1103515245 + 12345) & 0x7fffffff; b[i] = x >> 16; } return b; })()`;
const sha = `async (blob) => [...new Uint8Array(await crypto.subtle.digest('SHA-256', await blob.arrayBuffer()))].map((n) => n.toString(16).padStart(2, '0')).join('')`;
const sent = await ev(A, async ([mkSrc, shaSrc]) => {
  const bytes = eval(mkSrc); const f = new File([bytes], 'test-data.bin', { type: 'application/octet-stream' });
  const m = await window.__pl.transfer.sendFile('bob-test-22', f);
  return { id: m.id, hash: await eval(shaSrc)(f) };
}, [mk(3 * 1024 * 1024 + 123), sha]);
await until(async () => (await ev(B, async (id) => (await window.__pl.D.getMsg(id))?.file?.state, sent.id)) === 'done', 15000, 'file done');
const rhash = await ev(B, async ([id, shaSrc]) => eval(shaSrc)(await window.__pl.transfer.blob(id)), [sent.id, sha]);
ok(rhash === sent.hash, `3 MB file received intact (sha256 match)`);
await until(async () => (await ev(A, async (id) => (await window.__pl.D.getMsg(id))?.file?.state, sent.id)) === 'sent', 5000, 'sender state');
ok(true, 'sender marked file as sent after receiver confirmation');

console.log('\n# Large file, manual accept, link drop → auto resume');
await ev(B, () => window.__pl.S.settings.autoAcceptMB = 1); // force manual accept for >1MB
const big = await ev(A, async ([mkSrc, shaSrc]) => {
  const bytes = eval(mkSrc); const f = new File([bytes], 'big-video.mp4', { type: 'video/mp4' });
  const m = await window.__pl.transfer.sendFile('bob-test-22', f);
  return { id: m.id, hash: await eval(shaSrc)(f) };
}, [mk(24 * 1024 * 1024 + 77), sha]);
await until(async () => (await ev(B, async (id) => window.__pl.transfer.progress(id)?.state, big.id)) === 'offered', 8000, 'offered');
ok(true, 'large file waits for manual acceptance');
await ev(B, () => { // deterministic network drop after 40 chunks (2.5 MB)
  const t = window.__pl.transfer, orig = t._onChunk.bind(t);
  t._onChunk = async (s, d) => { await orig(s, d); if (s.next === 40 && !window.__dropped) { window.__dropped = true; window.__pl.net.closeLink(s.peer); } };
});
await ev(B, (id) => window.__pl.transfer.accept(`${id}|alice-test-1`), big.id);
await until(() => ev(B, () => window.__dropped === true), 15000, 'dropped');
await until(async () => (await ev(B, async (id) => window.__pl.transfer.progress(id)?.state, big.id)) === 'paused', 5000, 'paused');
await B.screenshot({ path: path.join(shots, '03-transfer-paused.png') });
ok(true, 'transfer paused when the link dropped');
await ev(A, () => window.__pl.net.connect('bob-test-22'));      // link returns
await until(async () => (await ev(B, async (id) => (await window.__pl.D.getMsg(id))?.file?.state, big.id)) === 'done', 40000, 'resumed done');
const bhash = await ev(B, async ([id, shaSrc]) => eval(shaSrc)(await window.__pl.transfer.blob(id)), [big.id, sha]);
ok(bhash === big.hash, '24 MB file resumed after drop and verified (sha256 match)');
await ev(B, () => window.__pl.S.settings.autoAcceptMB = 25);

console.log('\n# Reject path');
await ev(B, () => window.__pl.S.settings.autoAcceptMB = 0);
const rj = await ev(A, async () => { const f = new File([new Uint8Array(70000)], 'nope.txt', { type: 'text/plain' }); return (await window.__pl.transfer.sendFile('bob-test-22', f)).id; });
await until(async () => (await ev(B, async (id) => window.__pl.transfer.progress(id)?.state, rj)) === 'offered', 6000, 'offered2');
await ev(B, (id) => window.__pl.transfer.reject(`${id}|alice-test-1`), rj);
await until(async () => (await ev(A, async (id) => (await window.__pl.D.getMsg(id))?.file?.state, rj)) === 'rejected', 6000, 'rejected');
ok(true, 'sender notified of declined file');
await ev(B, () => window.__pl.S.settings.autoAcceptMB = 25);

console.log('\n# Offline outbox: message to an offline peer is queued then delivered');
await ev(A, () => window.__pl.D.saveContact({ id: 'carol-test-3', name: 'Carol', alias: '', emoji: '', color: '', fp: null, addedAt: Date.now(), blocked: false }));
await ev(A, () => window.__pl.chat.ensureDm('carol-test-3'));
await C.evaluate(() => window.__pl.net.stop());                 // carol goes offline
await sleep(300);
const q = await ev(A, async () => (await window.__pl.chat.sendText('carol-test-3', 'while you were away')).id);
await until(async () => (await ev(A, async (id) => (await window.__pl.D.getMsg(id))?.status, q)) === 'queued', 6000, 'queued');
ok(true, 'message to offline contact is queued');
await C.evaluate(() => window.__pl.net.start());
await until(() => ev(C, () => window.__pl.net.state === 'online'), 6000, 'carol back');
await ev(A, () => window.__pl.chat.retryOutbox());
await until(async () => (await ev(C, async () => (await window.__pl.db.msgAll('alice-test-1')).some((m) => m.text === 'while you were away'))), 12000, 'carol got queued');
ok(true, 'queued message delivered when contact returned');

console.log('\n# Groups');
await ev(B, () => window.__pl.chat.addContact('carol-test-3', 'Carol'));
await ev(C, () => window.__pl.chat.addContact('alice-test-1', 'Alice'));
await ev(C, () => window.__pl.chat.addContact('bob-test-22', 'Bob'));
const gid = await ev(A, async () => (await window.__pl.chat.createGroup('Trip crew', ['bob-test-22', 'carol-test-3'])).id);
await until(async () => (await ev(B, (g) => !!window.__pl.D.getChat(g), gid)) && (await ev(C, (g) => !!window.__pl.D.getChat(g), gid)), 10000, 'group invite');
ok(true, 'group invitation reached both members');
await ev(B, async (g) => { await window.__pl.chat.sendText(g, 'group hello from bob'); }, gid);
await until(async () => (await ev(A, async (g) => (await window.__pl.db.msgAll(g)).some((m) => m.text === 'group hello from bob'), gid)) && (await ev(C, async (g) => (await window.__pl.db.msgAll(g)).some((m) => m.text === 'group hello from bob'), gid)), 12000, 'group fanout');
ok(true, 'group message fanned out to all members (mesh)');
await ev(A, async (g) => { await window.__pl.chat.renameGroup(window.__pl.D.getChat(g), 'Renamed crew'); }, gid);
await until(async () => (await ev(C, (g) => window.__pl.D.getChat(g).title, gid)) === 'Renamed crew', 8000, 'rename');
ok(true, 'admin rename propagated');
await ev(C, async (g) => { await window.__pl.chat.leaveGroup(window.__pl.D.getChat(g)); }, gid);
await until(async () => (await ev(A, (g) => window.__pl.D.getChat(g).members.length, gid)) === 2, 8000, 'leave');
ok(true, 'member leave processed by admin');

console.log('\n# Disappearing messages');
await ev(A, async () => { await window.__pl.chat.setTtl(window.__pl.D.getChat('bob-test-22'), 300); });
await until(async () => (await ev(B, () => window.__pl.D.getChat('alice-test-1').ttl)) === 300, 6000, 'ttl');
ok(true, 'timer setting synced');

console.log('\n# Voice note');
await ev(A, async () => {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  const rec = new MediaRecorder(stream); const ch = []; rec.ondataavailable = (e) => ch.push(e.data);
  rec.start(100); await new Promise((r) => setTimeout(r, 1500)); await new Promise((r) => { rec.onstop = r; rec.stop(); });
  stream.getTracks().forEach((t) => t.stop());
  const f = new File([new Blob(ch, { type: rec.mimeType })], 'voice.webm', { type: rec.mimeType });
  await window.__pl.transfer.sendFile('bob-test-22', f, { kind: 'voice', dur: 2, wave: Array.from({ length: 40 }, (_, i) => (i % 7) / 7) });
});
await until(async () => (await ev(B, async () => (await window.__pl.db.msgAll('alice-test-1')).some((m) => m.kind === 'voice' && m.file.state === 'done'))), 10000, 'voice');
ok(true, 'voice note auto-downloaded on B');

console.log('\n# Calls');
await ev(A, () => window.__pl.calls.start('bob-test-22', true));
await until(() => ev(B, () => window.__pl.calls.cur?.state === 'ringing'), 8000, 'ringing');
ok(true, 'B rings on incoming video call');
await B.waitForSelector('.call-screen .cbtn.green');
await B.screenshot({ path: path.join(shots, '04-incoming-call.png') });
await B.click('.call-screen .cbtn.green');
await until(async () => (await ev(A, () => window.__pl.calls.cur?.state)) === 'active' && (await ev(B, () => window.__pl.calls.cur?.state)) === 'active', 15000, 'call active');
ok(true, 'call connected on both sides (real WebRTC media)');
await sleep(1200);
await A.screenshot({ path: path.join(shots, '05-call-active.png') });
await ev(A, () => window.__pl.calls.toggleMute());
ok(await ev(A, () => window.__pl.calls.cur.muted === true), 'mute toggles');
await ev(A, () => window.__pl.calls.hangup());
await until(async () => !(await ev(B, () => window.__pl.calls.cur)), 6000, 'call ended B');
ok(true, 'hang-up ended the call on both sides');
await until(async () => (await ev(A, async () => (await window.__pl.db.msgAll('bob-test-22')).some((m) => m.kind === 'call'))), 3000, 'call log');
ok(true, 'call logged in chat history');
await ev(B, () => window.__pl.calls.start('alice-test-1', false)); await until(() => ev(A, () => window.__pl.calls.cur?.state === 'ringing'), 8000, 'ringing2');
await ev(A, () => window.__pl.calls.decline());
await until(async () => !(await ev(B, () => window.__pl.calls.cur)), 6000, 'declined');
ok(true, 'declined call handled');

console.log('\n# Key pinning / impersonation warning');
await ev(A, async () => { const c = window.__pl.D.getContact('bob-test-22'); c.fp = 'deadbeef'.repeat(5); await window.__pl.D.saveContact(c); window.__pl.net.closeLink('bob-test-22'); });
await sleep(300);
await ev(A, () => window.__pl.net.connect('bob-test-22'));
await until(async () => !!(await ev(A, () => window.__pl.D.getContact('bob-test-22').keyChanged)), 6000, 'keyChanged');
ok(true, 'changed identity key is flagged (TOFU mismatch)');

console.log('\n# UI screens render without errors');
for (const [tab, file] of [['Chats', '10-chats'], ['Transfers', '11-transfers'], ['Contacts', '12-contacts'], ['Settings', '13-settings']]) {
  await A.evaluate(() => { while (document.querySelector('#pages .page')) document.querySelector('#pages .page').remove(); });
  await A.click(`.tabbtn[aria-label="${tab}"]`);
  await sleep(350);
  await A.screenshot({ path: path.join(shots, `${file}.png`) });
}
await A.evaluate(() => window.__pl.S.settings.theme = 'dark');
await A.evaluate(() => document.documentElement.dataset.theme = 'dark');
await A.click('.tabbtn[aria-label="Chats"]'); await sleep(200);
await A.screenshot({ path: path.join(shots, '14-chats-dark.png') });
await A.click('.crow'); await sleep(500);
await A.screenshot({ path: path.join(shots, '15-chat-dark.png') });

console.log('\n# Summary');
const bad = errors.filter((e) => !/ResizeObserver|favicon/.test(e));
ok(bad.length === 0, `no uncaught page errors (${bad.length})`);
if (bad.length) console.log(bad.slice(0, 8).join('\n'));
console.log(failures ? `\n${failures} FAILED` : '\nALL PASSED');
await browser.close(); server.close();
process.exit(failures ? 1 : 0);
