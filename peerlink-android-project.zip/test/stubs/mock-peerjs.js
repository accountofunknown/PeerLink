// Test double for PeerJS: same public surface, signaling over BroadcastChannel,
// real RTCPeerConnection for media calls. Only used by the local e2e test.
const bc = new BroadcastChannel('mock-peerjs');
const peers = new Map();
let seq = 0;
const nid = () => `${Date.now().toString(36)}-${(seq++).toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

class Em {
  constructor() { this._h = {}; }
  on(t, f) { (this._h[t] ||= []).push(f); return this; }
  emit(t, ...a) { for (const f of [...(this._h[t] || [])]) { try { f(...a); } catch (e) { console.error('mock emit', t, e); } } }
}

class Conn extends Em {
  constructor(peer, remote, cid, outgoing, opts = {}) {
    super();
    Object.assign(this, { _peer: peer, peer: remote, cid, open: false, metadata: opts.metadata, serialization: opts.serialization, type: 'data', bufferSize: 0, dataChannel: { bufferedAmount: 0 } });
    this.outgoing = outgoing;
  }
  send(d) {
    if (!this.open) throw new Error('not open');
    bc.postMessage({ k: 'data', cid: this.cid, to: this.peer, data: d });
  }
  close() {
    if (this._closed) return;
    this._closed = true; this.open = false;
    bc.postMessage({ k: 'close', cid: this.cid, to: this.peer });
    this.emit('close');
  }
}

class Media extends Em {
  constructor(peer, remote, cid, meta) { super(); Object.assign(this, { _peer: peer, peer: remote, cid, metadata: meta, type: 'media', open: false }); this.pending = []; }
  _pc() {
    const pc = (this.peerConnection = new RTCPeerConnection({ iceServers: [] }));
    pc.onicecandidate = (e) => { if (e.candidate) bc.postMessage({ k: 'ice', cid: this.cid, to: this.peer, cand: e.candidate.toJSON() }); };
    pc.ontrack = (e) => { this.open = true; this.emit('stream', e.streams[0]); };
    pc.oniceconnectionstatechange = () => this.emit('iceStateChanged', pc.iceConnectionState);
    return pc;
  }
  async _offer(stream) {
    const pc = this._pc();
    stream.getTracks().forEach((t) => pc.addTrack(t, stream));
    await pc.setLocalDescription(await pc.createOffer());
    bc.postMessage({ k: 'call', from: this._peer.id, to: this.peer, cid: this.cid, meta: this.metadata, sdp: pc.localDescription.toJSON() });
  }
  async answer(stream) {
    const pc = this._pc();
    await pc.setRemoteDescription(this._offerSdp);
    stream.getTracks().forEach((t) => pc.addTrack(t, stream));
    await pc.setLocalDescription(await pc.createAnswer());
    bc.postMessage({ k: 'answer', cid: this.cid, to: this.peer, sdp: pc.localDescription.toJSON() });
    for (const c of this.pending.splice(0)) pc.addIceCandidate(c).catch(() => {});
  }
  close() {
    if (this._closed) return;
    this._closed = true; this.open = false;
    try { this.peerConnection?.close(); } catch {}
    bc.postMessage({ k: 'cclose', cid: this.cid, to: this.peer });
    this.emit('close');
  }
}

export class Peer extends Em {
  constructor(id, opts = {}) {
    super();
    this.id = id; this.options = opts; this.open = false; this.disconnected = false; this.destroyed = false; this.conns = new Map();
    const nonce = nid(); this._nonce = nonce;
    let taken = false;
    const onwho = (e) => { if (e.data.k === 'here' && e.data.nonce === nonce) taken = true; };
    bc.addEventListener('message', onwho);
    bc.postMessage({ k: 'who', id, nonce });
    setTimeout(() => {
      bc.removeEventListener('message', onwho);
      if (this.destroyed) return;
      if (taken) { this._err('unavailable-id', `ID \`${id}\` is taken`); return; }
      this._register();
    }, 120);
    this._handler = (e) => this._onmsg(e.data);
    bc.addEventListener('message', this._handler);
  }
  _register() { peers.set(this.id, this); this.open = true; this.emit('open', this.id); }
  _err(type, message) { const e = new Error(message); e.type = type; this.emit('error', e); }
  _onmsg(m) {
    if (this.destroyed) return;
    if (m.k === 'who' && m.id === this.id && this.open) bc.postMessage({ k: 'here', id: this.id, nonce: m.nonce });
    if (!this.open || this.disconnected) return;
    if (m.k === 'conn' && m.to === this.id) {
      const c = new Conn(this, m.from, m.cid, false, { metadata: m.meta, serialization: m.ser });
      this.conns.set(m.cid, c);
      this.emit('connection', c);
      bc.postMessage({ k: 'accept', cid: m.cid, to: m.from });   // dialer opens first (messages are ordered)
      c.open = true;                       // like a real data channel: open fires before any data can arrive
      c.emit('open');
    } else if (m.k === 'accept' && m.to === this.id) {
      const c = this.conns.get(m.cid); if (c) { c.open = true; c._accepted = true; c.emit('open'); }
    } else if (m.k === 'data' && m.to === this.id) {
      this.conns.get(m.cid)?.emit('data', m.data);
    } else if (m.k === 'close' && m.to === this.id) {
      const c = this.conns.get(m.cid); if (c && !c._closed) { c._closed = true; c.open = false; c.emit('close'); }
    } else if (m.k === 'call' && m.to === this.id) {
      const mc = new Media(this, m.from, m.cid, m.meta); mc._offerSdp = m.sdp; this.conns.set(m.cid, mc);
      bc.postMessage({ k: 'ring', cid: m.cid, to: m.from });
      this.emit('call', mc);
    } else if (m.k === 'ring' && m.to === this.id) {
      const c = this.conns.get(m.cid); if (c) c._ringing = true;
    } else if (m.k === 'answer' && m.to === this.id) {
      const c = this.conns.get(m.cid);
      c?.peerConnection?.setRemoteDescription(m.sdp).then(() => { for (const x of c.pending.splice(0)) c.peerConnection.addIceCandidate(x).catch(() => {}); });
    } else if (m.k === 'ice' && m.to === this.id) {
      const c = this.conns.get(m.cid);
      if (!c) return;
      if (c.peerConnection?.remoteDescription) c.peerConnection.addIceCandidate(m.cand).catch(() => {}); else c.pending.push(m.cand);
    } else if (m.k === 'cclose' && m.to === this.id) {
      const c = this.conns.get(m.cid); if (c && !c._closed) { c._closed = true; c.open = false; try { c.peerConnection?.close(); } catch {} c.emit('close'); }
    }
  }
  connect(id, opts = {}) {
    if (this.disconnected) { this._err('disconnected', 'Cannot connect to new Peer after disconnecting from server.'); return undefined; }
    const cid = nid();
    const c = new Conn(this, id, cid, true, opts);
    this.conns.set(cid, c);
    bc.postMessage({ k: 'conn', from: this.id, to: id, cid, meta: opts.metadata, ser: opts.serialization });
    setTimeout(() => { if (!c._accepted && !c._closed) { this._err('peer-unavailable', `Could not connect to peer ${id}`); } }, 500);
    return c;
  }
  call(id, stream, opts = {}) {
    const cid = nid();
    const mc = new Media(this, id, cid, opts.metadata);
    this.conns.set(cid, mc);
    mc._offer(stream);
    setTimeout(() => { if (!mc._ringing && !mc._closed) this._err('peer-unavailable', `Could not connect to peer ${id}`); }, 600);
    return mc;
  }
  disconnect() { this.disconnected = true; this.open = false; peers.delete(this.id); this.emit('disconnected', this.id); }
  reconnect() { this.disconnected = false; this._register(); }
  destroy() {
    if (this.destroyed) return;
    this.destroyed = true; this.open = false; peers.delete(this.id);
    for (const c of this.conns.values()) { try { c.close(); } catch {} }
    bc.removeEventListener('message', this._handler);
    this.emit('close');
  }
}
export default Peer;
