# Test signing key — PUBLIC, NOT FOR PRODUCTION

`peerlink-test.p12` (alias `peerlink-test`, password `peerlink-test`) is committed on purpose.
CI signs **test builds** with it when no release secrets are configured, so each new build can be
installed over the previous one without uninstalling (your chats and identity key survive the update).

Because the key is public, anyone could produce an APK that updates your test install.
Never distribute builds signed with it. For real releases add the repository secrets
`ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`;
the workflow then uses your own key instead.
