// Application bootstrap.

import './styles.css';
import { App as CapApp } from '@capacitor/app';
import { SplashScreen } from '@capacitor/splash-screen';
import { S, bus, loadSettings } from './state.js';
import * as db from './db.js';
import * as K from './crypto.js';
import * as D from './data.js';
import { net } from './net.js';
import { chat } from './chat.js';
import { transfer } from './transfer.js';
import { calls } from './calls.js';
import { applyTheme } from './theme.js';
import { initNotify, askNotifyPermission, unlockAudio, isNative } from './notify.js';
import { buildShell, handleBack } from './ui/shell.js';
import { initCallUI } from './ui/call.js';
import { runOnboarding } from './ui/onboarding.js';
import { showLock } from './ui/lock.js';
import { handleInvite } from './ui/contacts.js';
import { toast } from './ui/dom.js';

const params = new URLSearchParams(location.search);
S.profile = (params.get('p') || '').replace(/[^a-z0-9_-]/gi, '').slice(0, 24);

function showFatal(e) {
  console.error(e);
  const box = document.getElementById('boot-error');
  if (box) { box.hidden = false; box.textContent = `PeerLink failed to start: ${e?.message || e}`; }
  SplashScreen.hide().catch(() => {});
}

async function boot() {
  console.info('PeerLink-boot: start');
  loadSettings();
  applyTheme();
  await db.openDb(`peerlink${S.profile ? `-${S.profile}` : ''}`);
  S.me = await db.get('kv', 'identity');
  await K.ensureKeys();
  await D.loadAll();
  await SplashScreen.hide().catch(() => {});
  if (!S.me) {
    console.info('PeerLink-boot: onboarding');
    S.me = await runOnboarding();
    await db.put('kv', S.me, 'identity');
  }
  if (S.settings.pin) await showLock();

  chat.init();
  await transfer.init();
  calls.init();
  initNotify().then(() => { if (S.settings.notify) askNotifyPermission(); });

  buildShell(document.getElementById('app'));
  initCallUI();
  await net.start();
  console.info('PeerLink-boot: ready');
  chat.retryOutbox();
  wireNative();
  if (params.get('debug') !== null) window.__pl = { S, net, chat, transfer, calls, D, db, bus };
}

let hiddenAt = 0;
function setVisible(v) {
  S.visible = v;
  bus.emit('visible', v);
  if (!v) { hiddenAt = Date.now(); return; }
  net.recover(true);
  chat.retryOutbox();
  const away = (Date.now() - hiddenAt) / 1000;
  if (S.settings.pin && !S.locked && hiddenAt && away >= S.settings.autoLock) showLock();
  hiddenAt = 0;
}

function wireNative() {
  document.addEventListener('visibilitychange', () => setVisible(!document.hidden));
  window.addEventListener('pointerdown', unlockAudio, { once: true, passive: true });
  net.on('state', (s, err) => { bus.emit('net', s); if (s === 'conflict') toast('Your PeerLink ID is already in use on the server. Change it in Settings → Profile.', { ms: 6000 }); if (s === 'error') toast(`Connection error: ${err?.message || err?.type}`, { ms: 6000 }); });
  window.addEventListener('unhandledrejection', (e) => { net.log('E', 'unhandled', e.reason?.message || e.reason); });
  window.addEventListener('error', (e) => { net.log('E', 'error', e.message); });
  if (!isNative()) { window.addEventListener('popstate', () => handleBack()); return; }
  CapApp.addListener('appStateChange', ({ isActive }) => setVisible(isActive));
  CapApp.addListener('backButton', () => { if (!handleBack()) CapApp.minimizeApp(); });
  CapApp.addListener('appUrlOpen', ({ url }) => { if (/^peerlink:/i.test(url)) handleInvite(url); });
  CapApp.getLaunchUrl().then((r) => { if (r?.url && /^peerlink:/i.test(r.url)) setTimeout(() => handleInvite(r.url), 600); }).catch(() => {});
}

boot().catch(showFatal);
