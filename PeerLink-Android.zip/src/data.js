// In-memory caches + persistence for contacts, chats and messages.

import * as db from './db.js';
import { S, bus } from './state.js';

export async function loadAll() {
  const [cs, ch] = await Promise.all([db.all('contacts'), db.all('chats')]);
  S.contacts = new Map(cs.map((c) => [c.id, c]));
  S.chats = new Map(ch.map((c) => [c.id, c]));
}

/* ---------- contacts ---------- */
export const getContact = (id) => S.contacts.get(id);
export async function saveContact(c) {
  S.contacts.set(c.id, c);
  await db.put('contacts', c);
  bus.emit('contacts', c.id);
  return c;
}
export async function removeContact(id) {
  S.contacts.delete(id);
  await db.del('contacts', id);
  bus.emit('contacts', id);
}
export const isContact = (id) => { const c = S.contacts.get(id); return !!c && !c.blocked && !c.implicit; };
export const isBlocked = (id) => !!S.contacts.get(id)?.blocked;

/** Best display name for a peer id. */
export function nameOf(id) {
  if (id === S.me?.id) return 'You';
  const c = S.contacts.get(id);
  if (c && (c.alias || c.name)) return c.alias || c.name;
  for (const ch of S.chats.values()) if (ch.names?.[id]) return ch.names[id];
  return id;
}
export function profileOf(id) {
  const c = S.contacts.get(id);
  return { id, name: nameOf(id), emoji: c?.emoji || '', color: c?.color || '' };
}

/* ---------- chats ---------- */
export const getChat = (id) => S.chats.get(id);
export async function saveChat(c, silent) {
  S.chats.set(c.id, c);
  await db.put('chats', c);
  if (!silent) bus.emit('chats', c.id);
  return c;
}
export function chatTitle(ch) {
  return ch.type === 'group' ? ch.title || 'Group' : nameOf(ch.id);
}
export function chatList() {
  return [...S.chats.values()].sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || (b.ts || 0) - (a.ts || 0));
}
export function totalUnread() {
  let n = 0;
  for (const c of S.chats.values()) if (!c.muted) n += c.unread || 0;
  return n;
}

/* ---------- messages ---------- */
const queues = new Map();
/** Serialise read-modify-write per key to avoid lost updates. */
export function serial(key, fn) {
  const prev = queues.get(key) || Promise.resolve();
  const next = prev.then(fn, fn);
  const tail = next.catch(() => {});
  queues.set(key, tail);
  tail.then(() => { if (queues.get(key) === tail) queues.delete(key); });
  return next;
}

export async function saveMsg(m, op = 'add') {
  if (m.file) m.fts = m.fts || m.ts;
  await db.put('messages', m);
  bus.emit('msg', m.chatId, m, op);
}
export const getMsg = (id) => db.get('messages', id);

export function patchMsg(id, fn) {
  return serial(`m:${id}`, async () => {
    const m = await getMsg(id);
    if (!m) return null;
    if (fn(m) === false) return m;
    await saveMsg(m, 'upd');
    return m;
  });
}

export async function deleteMsgLocal(m) {
  await db.del('messages', m.id);
  bus.emit('msg', m.chatId, m, 'del');
}

export const RANK = { failed: -1, queued: 0, sending: 1, sent: 2, received: 2, delivered: 3, read: 4 };
export const rank = (s) => RANK[s] ?? 0;

export function preview(m) {
  if (!m) return '';
  if (m.deleted) return 'Message deleted';
  switch (m.kind) {
    case 'image': return '📷 Photo';
    case 'video': return '🎞 Video';
    case 'voice': return '🎤 Voice message';
    case 'file': return `📎 ${m.file?.name || 'File'}`;
    case 'call': return m.text || 'Call';
    default: return m.text || '';
  }
}

export async function touchChat(ch, m, { unread = 0 } = {}) {
  ch.last = { id: m.id, ts: m.ts, from: m.from, text: preview(m), kind: m.kind };
  ch.ts = Math.max(ch.ts || 0, m.ts);
  if (unread) ch.unread = (ch.unread || 0) + unread;
  await saveChat(ch);
}
