// Promise wrapper around IndexedDB. One database per profile.

let _db = null;

export function openDb(name) {
  return new Promise((resolve, reject) => {
    const rq = indexedDB.open(name, 1);
    rq.onupgradeneeded = () => {
      const d = rq.result;
      d.createObjectStore('kv');
      d.createObjectStore('contacts', { keyPath: 'id' });
      d.createObjectStore('chats', { keyPath: 'id' });
      const m = d.createObjectStore('messages', { keyPath: 'id' });
      m.createIndex('byChat', ['chatId', 'ts', 'id']);
      m.createIndex('byExp', 'exp');
      m.createIndex('byFile', 'fts');
      const o = d.createObjectStore('outbox', { keyPath: 'key' });
      o.createIndex('byTo', 'to');
      d.createObjectStore('blobs');
      d.createObjectStore('chunks');
      d.createObjectStore('transfers', { keyPath: 'key' });
    };
    rq.onsuccess = () => { _db = rq.result; _db.onversionchange = () => _db.close(); resolve(); };
    rq.onerror = () => reject(rq.error);
    rq.onblocked = () => reject(new Error('Database blocked'));
  });
}

const tx = (stores, mode = 'readonly') => _db.transaction(stores, mode);
const req = (r) => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const done = (t) => new Promise((res, rej) => { t.oncomplete = () => res(); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error || new Error('tx aborted')); });

export const get = (s, k) => req(tx(s).objectStore(s).get(k));
export const all = (s) => req(tx(s).objectStore(s).getAll());
export const keys = (s) => req(tx(s).objectStore(s).getAllKeys());
export const count = (s) => req(tx(s).objectStore(s).count());
export async function put(s, v, k) {
  const t = tx(s, 'readwrite');
  if (k === undefined) t.objectStore(s).put(v); else t.objectStore(s).put(v, k);
  await done(t);
}
export async function del(s, k) {
  const t = tx(s, 'readwrite');
  t.objectStore(s).delete(k);
  await done(t);
}
export async function clear(s) {
  const t = tx(s, 'readwrite');
  t.objectStore(s).clear();
  await done(t);
}
export const byIndex = (s, idx, key) => req(tx(s).objectStore(s).index(idx).getAll(key));

/** Newest-first page of a chat, returned oldest-first. `before` = {ts,id} exclusive cursor. */
export function msgPage(chatId, before, limit = 50) {
  return new Promise((res, rej) => {
    const out = [];
    const idx = tx('messages').objectStore('messages').index('byChat');
    const upper = before ? [chatId, before.ts, before.id] : [chatId, Infinity, '\uffff'];
    const range = IDBKeyRange.bound([chatId, 0, ''], upper, false, !!before);
    const rq = idx.openCursor(range, 'prev');
    rq.onsuccess = () => {
      const c = rq.result;
      if (c && out.length < limit) { out.push(c.value); c.continue(); } else res(out.reverse());
    };
    rq.onerror = () => rej(rq.error);
  });
}

export const msgAll = (chatId) => msgPage(chatId, null, Infinity);

/** Most recent messages that carry a file. */
export function recentFiles(limit = 100) {
  return new Promise((res, rej) => {
    const out = [];
    const rq = tx('messages').objectStore('messages').index('byFile').openCursor(null, 'prev');
    rq.onsuccess = () => {
      const c = rq.result;
      if (c && out.length < limit) { out.push(c.value); c.continue(); } else res(out);
    };
    rq.onerror = () => rej(rq.error);
  });
}

export function expired(ts) {
  return new Promise((res, rej) => {
    const rq = tx('messages').objectStore('messages').index('byExp').getAll(IDBKeyRange.upperBound(ts));
    rq.onsuccess = () => res(rq.result);
    rq.onerror = () => rej(rq.error);
  });
}

/** Scan all messages (used for search). */
export function scanMessages(fn, limit = 60) {
  return new Promise((res, rej) => {
    const out = [];
    const rq = tx('messages').objectStore('messages').index('byChat').openCursor(null, 'prev');
    rq.onsuccess = () => {
      const c = rq.result;
      if (!c || out.length >= limit) return res(out);
      if (fn(c.value)) out.push(c.value);
      c.continue();
    };
    rq.onerror = () => rej(rq.error);
  });
}

/** Delete chunk groups of a transfer (keys are `${tid}:${n}`). */
export function delChunks(tid) {
  return new Promise((res, rej) => {
    const t = tx('chunks', 'readwrite');
    const rq = t.objectStore('chunks').openKeyCursor(IDBKeyRange.bound(`${tid}:`, `${tid}:\uffff`));
    rq.onsuccess = () => {
      const c = rq.result;
      if (c) { t.objectStore('chunks').delete(c.primaryKey); c.continue(); }
    };
    t.oncomplete = () => res();
    t.onerror = () => rej(t.error);
  });
}

export async function estimate() {
  try { return (await navigator.storage?.estimate?.()) || {}; } catch { return {}; }
}

export async function wipeAll() {
  for (const s of ['kv', 'contacts', 'chats', 'messages', 'outbox', 'blobs', 'chunks', 'transfers']) await clear(s);
}
