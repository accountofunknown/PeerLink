import { StatusBar, Style } from '@capacitor/status-bar';
import { S } from './state.js';
import { isNative } from './notify.js';

const BG = { dark: '#0b0d17', light: '#f4f5fb' };

function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!m) return [99, 102, 241];
  const n = parseInt(m[1], 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export const isDark = () => S.settings.theme === 'dark' || (S.settings.theme === 'auto' && window.matchMedia?.('(prefers-color-scheme: dark)').matches);

export function applyTheme() {
  const root = document.documentElement;
  const dark = isDark();
  root.dataset.theme = dark ? 'dark' : 'light';
  const [r, g, b] = hexToRgb(S.settings.accent);
  const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  root.style.setProperty('--accent', S.settings.accent);
  root.style.setProperty('--accent-ink', lum > 0.68 ? '#10121f' : '#ffffff');
  root.style.setProperty('--accent-soft', `rgba(${r},${g},${b},${dark ? 0.22 : 0.13})`);
  document.querySelector('meta[name=theme-color]')?.setAttribute('content', BG[dark ? 'dark' : 'light']);
  if (isNative()) {
    StatusBar.setStyle({ style: dark ? Style.Dark : Style.Light }).catch(() => {});
    StatusBar.setBackgroundColor({ color: BG[dark ? 'dark' : 'light'] }).catch(() => {});
    StatusBar.setOverlaysWebView({ overlay: false }).catch(() => {});
  }
}

window.matchMedia?.('(prefers-color-scheme: dark)').addEventListener?.('change', () => { if (S.settings.theme === 'auto') applyTheme(); });
