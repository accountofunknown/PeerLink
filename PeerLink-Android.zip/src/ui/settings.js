// Settings tab and its sub-pages.

import { h, icon, clear, genPeerId, normId, validId, PALETTE, fmtBytes, parseIce, timeAgo } from '../util.js';
import { S, bus, saveSettings } from '../state.js';
import * as D from '../data.js';
import * as db from '../db.js';
import { net } from '../net.js';
import { chat as chatSvc } from '../chat.js';
import { transfer } from '../transfer.js';
import { applyTheme } from '../theme.js';
import { askNotifyPermission, notifyGranted, isNative } from '../notify.js';
import { nav, appbar, avatar, section, listRow, toggle, segmented, toast, confirmDialog, promptDialog, infoDialog, sheet } from './dom.js';
import { netPill } from './tabs.js';
import { pickFiles } from './chat.js';
import { askPin } from './lock.js';
import { runSelfTest, reportText, testIceServers } from '../selftest.js';
import { keepAliveStatus, openBatterySettings } from '../keepalive.js';
import { showMyQR } from './contacts.js';
import { APP } from '../config.js';

export const AVATAR_EMOJI = ['', '😀', '😎', '🤓', '🥳', '🦊', '🐼', '🐯', '🦁', '🐸', '🐙', '🦄', '🐧', '🦉', '🌵', '🍀', '🔥', '⚡', '🌈', '🚀', '🎧', '🎮', '📷', '☕'];

function page(name, title, build) {
  return nav.push(name, (ctx) => {
    const body = h('div', { class: 'scroll pad' });
    ctx.el.append(appbar({ title, onBack: () => nav.pop(ctx) }), body);
    build(body, ctx);
  });
}

/* ------------------------------ root ------------------------------ */
export function settingsTab() {
  const el = h('div', { class: 'tab' });
  const body = h('div', { class: 'scroll pad' });
  el.append(h('header', { class: 'appbar root' }, h('div', { class: 'ab-title' }, h('div', { class: 't big' }, 'Settings'), netPill())), body);
  const paint = () => {
    const me = S.me;
    body.replaceChildren(
      h('button', { class: 'me-card', onclick: openProfile }, avatar(me, 64), h('div', { class: 'me-t' }, h('div', { class: 'n' }, me.name), h('code', {}, me.id), me.bio ? h('div', { class: 'b' }, me.bio) : null), h('span', { class: 'qrbtn', onclick: (e) => { e.stopPropagation(); showMyQR(); } }, icon('qr', 22))),
      section('',
        listRow({ icon: 'user', title: 'Profile', sub: 'Name, avatar, bio and your PeerLink ID', onClick: openProfile }),
        listRow({ icon: 'palette', title: 'Appearance', sub: S.settings.theme === 'auto' ? 'System theme' : S.settings.theme === 'dark' ? 'Dark' : 'Light', onClick: openAppearance }),
        listRow({ icon: 'bell', title: 'Notifications & sounds', onClick: openNotifications }),
        listRow({ icon: 'lock', title: 'Privacy & security', sub: S.settings.pin ? 'App lock on' : 'App lock off', onClick: openPrivacy }),
        listRow({ icon: 'download', title: 'File transfers', sub: S.settings.autoAcceptMB ? `Auto-accept up to ${S.settings.autoAcceptMB} MB` : 'Always ask', onClick: openTransfers })),
      section('',
        listRow({ icon: 'globe', title: 'Network & servers', sub: S.settings.server.mode === 'cloud' ? 'PeerJS Cloud (default)' : S.settings.server.host, onClick: openNetwork }),
        listRow({ icon: 'activity', title: 'Connection diagnostics', sub: 'Status, peers, logs', onClick: openDiagnostics }),
        listRow({ icon: 'database', title: 'Data & storage', sub: 'Backup, restore, clear', onClick: openData })),
      section('', listRow({ icon: 'info', title: 'About PeerLink', sub: `Version ${APP.version}`, onClick: openAbout })));
  };
  bus.on('settings', paint); bus.on('profile', paint);
  paint();
  return el;
}
bus.on('open-diagnostics', (opts) => openDiagnostics(opts));

/* ------------------------------ profile ------------------------------ */
function openProfile() {
  page('profile', 'Profile', (body) => {
    const draft = { name: S.me.name, bio: S.me.bio || '', emoji: S.me.emoji || '', color: S.me.color || '' };
    const preview = h('div', { class: 'center' });
    const paintPrev = () => preview.replaceChildren(avatar({ id: S.me.id, ...draft }, 96));
    const name = h('input', { type: 'text', value: draft.name, maxlength: 40, placeholder: 'Your name' });
    const bio = h('input', { type: 'text', value: draft.bio, maxlength: 120, placeholder: 'A short bio (optional)' });
    name.oninput = () => { draft.name = name.value; paintPrev(); };
    bio.oninput = () => { draft.bio = bio.value; };
    const emojis = h('div', { class: 'emoji-pick' }, AVATAR_EMOJI.map((e) => h('button', { class: draft.emoji === e ? 'on' : '', onclick: (ev) => { draft.emoji = e; [...emojis.children].forEach((c) => c.classList.remove('on')); ev.currentTarget.classList.add('on'); paintPrev(); } }, e || 'Aa')));
    const colors = h('div', { class: 'swatches' }, [''].concat(PALETTE).map((c) => h('button', { class: draft.color === c ? 'on' : '', style: { background: c || 'var(--surface3)' }, 'aria-label': c || 'Automatic', onclick: (ev) => { draft.color = c; [...colors.children].forEach((x) => x.classList.remove('on')); ev.currentTarget.classList.add('on'); paintPrev(); } })));
    paintPrev();
    body.append(preview,
      h('label', { class: 'field-label' }, 'Display name'), name,
      h('label', { class: 'field-label' }, 'Bio'), bio,
      h('label', { class: 'field-label' }, 'Avatar'), emojis,
      h('label', { class: 'field-label' }, 'Colour'), colors,
      h('div', { class: 'sheet-foot' }, h('button', { class: 'btn primary wide', onclick: async () => {
        const n = draft.name.trim();
        if (!n) { toast('Enter a name'); return; }
        S.me = { ...S.me, name: n, bio: draft.bio.trim(), emoji: draft.emoji, color: draft.color };
        await db.put('kv', S.me, 'identity');
        chatSvc.broadcastProfile();
        bus.emit('profile');
        toast('Profile saved');
      } }, 'Save profile')),
      section('PeerLink ID',
        listRow({ icon: 'key', title: S.me.id, sub: 'Share this with friends so they can add you', onClick: () => { navigator.clipboard?.writeText(S.me.id); toast('ID copied'); } }),
        listRow({ icon: 'refresh', title: 'Change my ID', sub: 'Your contacts will have to add your new ID', onClick: changeId })));
  });
}

async function changeId() {
  const v = await promptDialog({ title: 'Change PeerLink ID', label: 'Letters, numbers, “-” and “_” (4–48 chars)', value: S.me.id, ok: 'Change', maxlength: 48, validate: (x) => (validId(normId(x)) ? null : 'Invalid ID') });
  if (!v) return;
  const id = normId(v);
  if (id === S.me.id) return;
  if (!(await confirmDialog({ title: 'Change ID?', text: 'Existing contacts will no longer reach you until they add the new ID. Chats stay on this device.', ok: 'Change ID', danger: true }))) return;
  S.me = { ...S.me, id };
  await db.put('kv', S.me, 'identity');
  bus.emit('profile');
  await net.restart();
  toast('ID changed');
}

/* ------------------------------ appearance ------------------------------ */
function openAppearance() {
  page('appearance', 'Appearance', (body) => {
    body.append(
      section('Theme', h('div', { class: 'lrow col' }, segmented([['auto', 'Auto'], ['light', 'Light'], ['dark', 'Dark']], S.settings.theme, (v) => { saveSettings({ theme: v }); applyTheme(); }))),
      section('Accent colour', h('div', { class: 'lrow col' }, h('div', { class: 'swatches big' }, PALETTE.map((c) => h('button', { class: S.settings.accent === c ? 'on' : '', style: { background: c }, 'aria-label': c, onclick: (ev) => { saveSettings({ accent: c }); applyTheme(); [...ev.currentTarget.parentNode.children].forEach((x) => x.classList.remove('on')); ev.currentTarget.classList.add('on'); } })))),
      ),
      section('Chat', listRow({ icon: 'send', title: 'Enter key sends message', right: toggle(S.settings.enterSend, (v) => saveSettings({ enterSend: v })) })));
  });
}

/* ------------------------------ notifications ------------------------------ */
function openNotifications() {
  page('notifications', 'Notifications & sounds', (body) => {
    const perm = h('div');
    const paintPerm = () => perm.replaceChildren(listRow({ icon: 'bell', title: 'System permission', sub: notifyGranted() ? 'Allowed' : 'Not allowed yet', right: notifyGranted() ? icon('check', 20) : h('button', { class: 'btn sm primary', onclick: async () => { await askNotifyPermission(); paintPerm(); } }, 'Allow') }));
    paintPerm();
    const t = (key, title, sub, ic) => listRow({ icon: ic, title, sub, right: toggle(S.settings[key], (v) => saveSettings({ [key]: v })) });
    const bg = h('div');
    const paintBg = async () => {
      const st = await keepAliveStatus();
      bg.replaceChildren(section('Background connection',
        listRow({ icon: 'wifi', title: 'Stay connected in background', sub: isNative() ? 'Shows a quiet “connected” notification so messages and calls can arrive while the screen is off' : 'Android app only', right: toggle(S.settings.keepAlive, (v) => { saveSettings({ keepAlive: v }); setTimeout(paintBg, 600); }) }),
        isNative() ? listRow({ icon: 'activity', title: 'Battery: unrestricted', sub: st ? (st.ignoringBatteryOptimizations ? 'Allowed — Android will not put PeerLink to sleep' : 'Restricted — Android may disconnect PeerLink when the screen is off') : 'Unknown', right: st && !st.ignoringBatteryOptimizations ? h('button', { class: 'btn sm primary', onclick: openBatterySettings }, 'Allow') : (st ? icon('check', 20) : null) }) : null));
    };
    paintBg();
    body.append(bg, section('', perm,
      t('notify', 'Message notifications', 'Shown while the app is open in the background', 'bell'),
      t('preview', 'Show message preview', 'Display text in notifications', 'eye'),
      t('sound', 'Sounds', 'Message and call tones', 'bell'),
      t('haptics', 'Vibration', 'Haptic feedback and ringing', 'activity')),
      h('p', { class: 'note' }, 'PeerLink is a peer-to-peer app: there is no push server. You receive messages while the app is running (foreground or recently backgrounded). Messages sent while you are away are delivered the next time both of you are online.'));
  });
}

/* ------------------------------ privacy ------------------------------ */
function openPrivacy() {
  page('privacy', 'Privacy & security', (body, ctx) => {
    const render = () => {
      body.replaceChildren(
        section('App lock',
          listRow({ icon: 'lock', title: S.settings.pin ? 'PIN lock is on' : 'Set a PIN', sub: S.settings.pin ? 'Required when you open the app' : 'Protect the app with a 4–6 digit PIN', onClick: async () => {
            if (S.settings.pin) { const ok = await askPin({ title: 'Enter current PIN', verify: S.settings.pin }); if (ok == null) return; saveSettings({ pin: null }); toast('PIN removed'); }
            else { const p = await askPin({ title: 'Choose a PIN', confirm: true }); if (p == null) return; const { makePin } = await import('../crypto.js'); saveSettings({ pin: await makePin(p) }); toast('PIN set'); }
            render();
          } }),
          S.settings.pin ? h('div', { class: 'lrow col' }, h('div', { class: 'lr-t' }, 'Lock after'), segmented([[0, 'Instantly'], [30, '30 s'], [60, '1 min'], [300, '5 min']], S.settings.autoLock, (v) => saveSettings({ autoLock: Number(v) }))) : null),
        section('Messaging',
          listRow({ icon: 'checks', title: 'Read receipts', sub: 'Let others see when you read their messages', right: toggle(S.settings.receipts, (v) => saveSettings({ receipts: v })) }),
          listRow({ icon: 'edit', title: 'Typing indicators', right: toggle(S.settings.typing, (v) => saveSettings({ typing: v })) }),
          listRow({ icon: 'phone', title: 'Calls from non-contacts', sub: 'Otherwise unknown callers are rejected silently', right: toggle(S.settings.callsFromUnknown, (v) => saveSettings({ callsFromUnknown: v })) }),
          listRow({ icon: 'clock', title: 'Default disappearing timer', sub: 'For new chats', onClick: () => { const s = sheet('Default timer', [[0, 'Off'], [3600, '1 hour'], [86400, '24 hours'], [604800, '7 days']].map(([v, l]) => h('button', { class: `row-btn${S.settings.ttlDefault === v ? ' sel' : ''}`, onclick: () => { saveSettings({ ttlDefault: v }); s.close(); } }, icon('clock', 22), h('span', {}, l)))); } })),
        section('Blocked',
          ...(([...S.contacts.values()].filter((c) => c.blocked).map((c) => listRow({ title: D.nameOf(c.id), sub: c.id, right: h('button', { class: 'btn sm', onclick: async () => { await chatSvc.setBlocked(c.id, false); render(); } }, 'Unblock') }))).concat([[...S.contacts.values()].some((c) => c.blocked) ? null : h('div', { class: 'lrow' }, h('div', { class: 'lr-s' }, 'No blocked contacts'))]))),
        h('p', { class: 'note' }, 'Everything is end-to-end encrypted by WebRTC (DTLS). Each device also holds a signing key; contacts pin it on first contact and warn you if it ever changes.'));
    };
    render();
  });
}

/* ------------------------------ transfers ------------------------------ */
function openTransfers() {
  page('xfer-settings', 'File transfers', (body) => {
    body.append(
      section('Auto-accept from contacts',
        h('div', { class: 'lrow col' }, h('div', { class: 'lr-s' }, 'Files up to this size download automatically. Voice notes and small images are always accepted from contacts.'),
          segmented([[0, 'Ask'], [5, '5 MB'], [25, '25 MB'], [100, '100 MB'], [500, '500 MB']], S.settings.autoAcceptMB, (v) => saveSettings({ autoAcceptMB: Number(v) }))),
        listRow({ icon: 'image', title: 'Auto-accept images', right: toggle(S.settings.autoAcceptImages, (v) => saveSettings({ autoAcceptImages: v })) })),
      h('p', { class: 'note' }, 'Transfers use 64 KB chunks with per-chunk CRC checks, a sliding window for flow control, and resume from the last stored 1 MB block if the connection drops. Files from people who are not your contacts always need your approval.'));
  });
}

/* ------------------------------ network ------------------------------ */
function openNetwork() {
  page('network', 'Network & servers', (body, ctx) => {
    const sv = { ...S.settings.server };
    const ice = { ...S.settings.ice };
    const custom = h('div', { class: sv.mode === 'custom' ? '' : 'hidden' });
    const inp = (obj, key, ph, attrs = {}) => h('input', { type: 'text', value: obj[key] ?? '', placeholder: ph, autocapitalize: 'none', autocomplete: 'off', spellcheck: 'false', oninput: (e) => { obj[key] = e.target.value; }, ...attrs });
    const secure = h('div', { class: 'lrow' }, h('div', { class: 'lr-main' }, h('div', { class: 'lr-t' }, 'Use TLS (wss / https)'), h('div', { class: 'lr-s' }, 'Required for servers on the internet')), toggle(sv.secure, (v) => { sv.secure = v; }));
    custom.append(h('label', { class: 'field-label' }, 'Host'), inp(sv, 'host', 'peer.example.com'), h('label', { class: 'field-label' }, 'Port'), inp(sv, 'port', '443', { inputmode: 'numeric' }), h('label', { class: 'field-label' }, 'Path'), inp(sv, 'path', '/'), h('label', { class: 'field-label' }, 'Key'), inp(sv, 'key', 'peerjs'), secure);

    // ---- ICE (STUN/TURN)
    const iceText = h('textarea', { rows: 4, placeholder: 'stun:stun.example.com:3478\nturn:turn.example.com:3478,username,password', spellcheck: 'false', autocapitalize: 'none', oninput: (e) => { ice.servers = e.target.value; ice.mode = 'custom'; } });
    iceText.value = ice.servers || '';
    const tUrl = h('input', { type: 'text', placeholder: 'turn:turn.example.com:3478', autocapitalize: 'none', autocomplete: 'off', spellcheck: 'false' });
    const tUser = h('input', { type: 'text', placeholder: 'Username', autocapitalize: 'none', autocomplete: 'off' });
    const tPass = h('input', { type: 'text', placeholder: 'Password / credential', autocapitalize: 'none', autocomplete: 'off', spellcheck: 'false' });
    const addTurn = () => {
      const u = tUrl.value.trim();
      if (!/^(turns?|stuns?):/i.test(u)) { toast('URL must start with turn: / turns: / stun:'); return; }
      iceText.value = `${iceText.value.trim() ? iceText.value.trim() + '\n' : ''}${[u, tUser.value.trim(), tPass.value.trim()].filter((x, i) => i === 0 || x).join(',')}`;
      ice.servers = iceText.value; ice.mode = 'custom';
      tUrl.value = tUser.value = tPass.value = '';
      toast('Added — tap “Test servers”, then Save');
    };
    const testBox = h('div', { class: 'st-rows' });
    const testBtn = h('button', { class: 'btn sm primary' }, 'Test servers');
    testBtn.onclick = async () => {
      testBtn.disabled = true; testBox.replaceChildren(h('div', { class: 'lr-s' }, 'Testing each server (up to 8 s)…'));
      const draft = ice.mode === 'custom' ? parseIce(ice.servers) : [];
      const list = draft.length ? draft : net.currentIce();
      let res = await testIceServers(list);
      testBox.replaceChildren(...res.map((r) => h('div', { class: `st-row ${r.ok ? 'ok' : r.kind === 'TURN' ? 'fail' : 'warn'}` }, h('span', { class: 'st-ic' }, r.ok ? '✓' : '✗'), h('div', { class: 'st-t' }, h('b', {}, `${r.kind} · ${r.urls}`), h('div', { class: 'lr-s' }, r.ok ? (r.kind === 'TURN' ? 'relay address obtained — this TURN server works' : 'public address discovered') : `no ${r.kind === 'TURN' ? 'relay' : 'response'}${r.err ? ` (${r.err})` : ''}`)))));
      if (!res.some((r) => r.kind === 'TURN' && r.ok)) testBox.append(h('div', { class: 'banner warn' }, 'No working TURN server. Phones on different networks (mobile data, strict Wi-Fi) will probably not connect. Add one above — see docs/TURN-SETUP.md.'));
      testBtn.disabled = false;
    };
    const fetchIn = inp(ice, 'fetchUrl', 'https://… (JSON iceServers)');

    // ---- share settings between your phones
    const shareRow = h('div', { class: 'btn-row' },
      h('button', { class: 'btn sm', onclick: () => { const code = `peerlink-net:${btoa(unescape(encodeURIComponent(JSON.stringify({ server: sv, ice }))))}`; navigator.clipboard?.writeText(code).then(() => toast('Network settings copied — paste on your other phone')).catch(() => toast('Copy failed')); } }, icon('copy', 16), ' Copy settings'),
      h('button', { class: 'btn sm', onclick: async () => {
        try {
          const t = (await navigator.clipboard.readText()).trim();
          if (!t.startsWith('peerlink-net:')) throw new Error('Clipboard does not contain PeerLink network settings');
          const o = JSON.parse(decodeURIComponent(escape(atob(t.slice(13)))));
          if (!o.server || !o.ice) throw new Error('Invalid settings');
          saveSettings({ server: { ...S.settings.server, ...o.server }, ice: { ...S.settings.ice, ...o.ice } });
          toast('Settings imported — reconnecting…');
          nav.pop(ctx); net.restart();
        } catch (e) { toast(e.message || 'Could not import'); }
      } }, icon('download', 16), ' Paste settings'));

    body.append(
      section('Signaling server', h('div', { class: 'lrow col' }, segmented([['cloud', 'PeerJS Cloud'], ['custom', 'Custom server']], sv.mode, (v) => { sv.mode = v; custom.classList.toggle('hidden', v !== 'custom'); })), custom),
      section('NAT traversal (STUN / TURN)',
        h('div', { class: 'lrow col' },
          h('div', { class: 'banner warn' }, 'Connections across different networks (mobile data, strict Wi-Fi) need a working TURN server. PeerJS’s free default TURN may be down — run “Test servers”.'),
          h('label', { class: 'field-label' }, 'Quick add a TURN / STUN server'), tUrl, tUser, tPass,
          h('div', { class: 'btn-row' }, h('button', { class: 'btn sm', onclick: addTurn }, icon('plus', 16), ' Add to list')),
          h('label', { class: 'field-label' }, 'Server list (one per line: url[,username,credential])'), iceText,
          h('label', { class: 'field-label' }, 'Or load servers from a URL (credentials provider)'), fetchIn,
          h('div', { class: 'btn-row' }, testBtn), testBox),
        listRow({ icon: 'shield', title: 'Relay only (hide my IP)', sub: 'Forces TURN; slower but peers never see your address', right: toggle(ice.relayOnly, (v) => { ice.relayOnly = v; }) })),
      section('Share between your phones', h('div', { class: 'lrow col' }, h('div', { class: 'lr-s' }, 'Copy these settings and paste them on your other phone so both use the same TURN server.'), shareRow)),
      h('div', { class: 'sheet-foot' }, h('button', { class: 'btn primary wide', onclick: async () => {
        if (sv.mode === 'custom' && !sv.host.trim()) { toast('Enter a server host'); return; }
        if (ice.fetchUrl && !/^https?:\/\//i.test(ice.fetchUrl.trim())) { toast('The URL must start with https://'); return; }
        ice.fetchUrl = (ice.fetchUrl || '').trim();
        if (ice.mode === 'custom' && !parseIce(ice.servers).length && !ice.fetchUrl) ice.mode = 'default';
        saveSettings({ server: { ...sv, host: sv.host.trim(), port: Number(sv.port) || 443 }, ice });
        toast('Reconnecting…');
        await net.restart();
      } }, 'Save & reconnect')),
      h('p', { class: 'note' }, 'The signaling server only introduces peers; messages and files never pass through it. You can host your own with “npx peerjs --port 9000”. Servers on the internet must use TLS because the app is served over HTTPS.'));
  });
}

/* ------------------------------ diagnostics ------------------------------ */
export function openDiagnostics(opts = {}) {
  if (nav.stack.some((p) => p.name === 'diag')) return;
  page('diag', 'Connection diagnostics', (body, ctx) => {
    const top = h('div'); const peers = h('div'); const logBox = h('pre', { class: 'logs' });
    const paint = () => {
      const st = S.settings;
      top.replaceChildren(section('Status',
        h('div', { class: 'lrow' }, h('div', { class: 'lr-main' }, h('div', { class: 'lr-t' }, 'Signaling'), h('div', { class: 'lr-s' }, `${S.netState}${net.error ? ` — ${net.error.message || net.error.type}` : ''}`)), h('button', { class: 'btn sm', onclick: () => { toast('Reconnecting…'); net.restart(); } }, 'Reconnect')),
        listRow({ title: 'My ID', sub: S.me.id }),
        listRow({ title: 'Server', sub: st.server.mode === 'cloud' ? '0.peerjs.com (PeerJS Cloud)' : `${st.server.secure ? 'wss' : 'ws'}://${st.server.host}:${st.server.port}${st.server.path}` }),
        listRow({ title: 'ICE', sub: `${st.ice.mode === 'custom' ? 'Custom servers' : 'PeerJS default STUN/TURN'}${st.ice.relayOnly ? ' · relay only' : ''}` }),
        listRow({ title: 'Outbox', sub: 'Messages waiting to be delivered', right: h('b', { id: 'ob-count' }, '…') })));
      chatSvc.outboxCount().then((n) => { const e = top.querySelector('#ob-count'); if (e) e.textContent = String(n); });
      const links = [...net.links.values()].filter((l) => l.ok);
      peers.replaceChildren(section(`Connected peers (${links.length})`, ...(links.length ? links.map((l) => listRow({ title: D.nameOf(l.id), sub: `${l.route === 'relay' ? 'relayed' : l.route === 'direct' ? 'direct' : '…'} · ${l.rtt != null ? l.rtt + ' ms' : '– ms'} · up ${timeAgo(l.since)}`, right: h('button', { class: 'btn sm', onclick: () => net.closeLink(l.id) }, 'Close') })) : [h('div', { class: 'lrow' }, h('div', { class: 'lr-s' }, 'No active peer connections'))])));
      logBox.textContent = net.logs.slice(-80).join('\n');
      logBox.scrollTop = logBox.scrollHeight;
    };
    // ---- self-test
    const stBox = h('div', { class: 'st-rows' });
    const stAdvice = h('div', { class: 'st-advice' });
    let last = null, running = false;
    const runBtn = h('button', { class: 'btn primary sm' }, 'Run test');
    const copyBtn = h('button', { class: 'btn sm hidden' }, 'Copy report');
    const paintST = (results) => stBox.replaceChildren(...results.map((r) => h('div', { class: `st-row ${r.state}` }, h('span', { class: 'st-ic' }, r.state === 'ok' ? '✓' : r.state === 'fail' ? '✗' : r.state === 'warn' ? '!' : '…'), h('div', { class: 'st-t' }, h('b', {}, r.name), h('div', { class: 'lr-s' }, r.detail || 'running…')))));
    const start = async () => {
      if (running) return; running = true; runBtn.disabled = true; stAdvice.replaceChildren(); copyBtn.classList.add('hidden');
      const res = await runSelfTest(paintST);
      last = res; running = false; runBtn.disabled = false; runBtn.textContent = 'Run again';
      stAdvice.replaceChildren(...res.advice.map((a) => h('div', { class: 'banner' }, a)));
      copyBtn.classList.remove('hidden');
    };
    runBtn.onclick = start;
    copyBtn.onclick = () => { navigator.clipboard?.writeText(reportText(last.results, last.advice)); toast('Report copied'); };
    body.append(section('Connection self-test',
      h('div', { class: 'lrow col' }, h('div', { class: 'lr-s' }, 'Checks this phone’s WebView, storage, keys, the signaling server, NAT traversal, WebRTC, and a full PeerJS round trip using two temporary peers. Takes up to ~60 s.'),
        h('div', { class: 'btn-row' }, runBtn, copyBtn), stBox, stAdvice)));
    if (opts.run) setTimeout(start, 250);
    body.append(top, peers, section('Log',
      h('div', { class: 'lrow col' }, logBox, h('div', { class: 'btn-row' }, h('button', { class: 'btn sm', onclick: () => { navigator.clipboard?.writeText(net.logs.join('\n')); toast('Log copied'); } }, 'Copy log'), h('button', { class: 'btn sm', onclick: () => { net.logs.length = 0; paint(); } }, 'Clear'), h('label', { class: 'inline' }, 'Verbose PeerJS logging ', toggle(S.settings.debug, (v) => { saveSettings({ debug: v }); toast('Applies after reconnect'); }))))));
    paint();
    const iv = setInterval(paint, 2000);
    ctx.cleanup.push(() => clearInterval(iv));
    ctx.on('net', paint);
  });
}

/* ------------------------------ data ------------------------------ */
function openData() {
  page('data', 'Data & storage', (body) => {
    const usage = h('div', { class: 'lr-s' }, 'Calculating…');
    db.estimate().then((e) => { usage.textContent = e.usage != null ? `${fmtBytes(e.usage)} used${e.quota ? ` of ${fmtBytes(e.quota)}` : ''}` : 'Unknown'; });
    body.append(
      section('Storage', h('div', { class: 'lrow' }, h('div', { class: 'lr-main' }, h('div', { class: 'lr-t' }, 'On this device'), usage))),
      section('Backup',
        listRow({ icon: 'upload', title: 'Export backup', sub: 'Contacts, chats and messages (not files or keys)', onClick: exportBackup }),
        listRow({ icon: 'download', title: 'Import backup', sub: 'Merge a previously exported file', onClick: importBackup })),
      section('Danger zone', listRow({ icon: 'trash', title: 'Erase all data', sub: 'Deletes your identity, chats and files from this device', danger: true, onClick: wipe })));
  });
}

async function exportBackup() {
  const messages = await db.all('messages');
  const data = { app: 'peerlink', v: 1, at: Date.now(), me: { id: S.me.id, name: S.me.name, emoji: S.me.emoji, color: S.me.color, bio: S.me.bio }, contacts: [...S.contacts.values()].map(({ keyChanged, ...c }) => c), chats: [...S.chats.values()], messages: messages.map((m) => (m.file ? { ...m, file: { ...m.file, thumb: m.file.thumb } } : m)) };
  const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
  const tid = `export-${Date.now()}`;
  transfer.files.set(tid, blob);
  try { const r = await transfer.saveToDevice({ file: { tid, name: `peerlink-backup-${new Date().toISOString().slice(0, 10)}.json`, mime: 'application/json' } }); toast(r === 'saved' ? 'Saved to Documents/PeerLink' : r === 'downloaded' ? 'Backup downloaded' : 'Choose where to save'); }
  catch (e) { toast(e.message || 'Export failed'); }
  transfer.files.delete(tid);
}

async function importBackup() {
  const [file] = await pickFiles({ accept: 'application/json,.json', multiple: false });
  if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    if (data.app !== 'peerlink' || !Array.isArray(data.messages)) throw new Error('Not a PeerLink backup');
    let n = 0;
    for (const c of data.contacts || []) if (!S.contacts.has(c.id) && validId(c.id)) await D.saveContact({ ...c, keyChanged: null });
    for (const ch of data.chats || []) if (!S.chats.has(ch.id)) await D.saveChat(ch);
    for (const m of data.messages) if (m?.id && m.chatId && !(await D.getMsg(m.id))) { if (m.file && m.file.state !== 'deleted') m.file = { ...m.file, state: m.file.state === 'sent' || m.file.state === 'done' ? 'gone' : m.file.state }; await db.put('messages', m); n++; }
    bus.emit('chats');
    toast(`Imported ${n} messages`);
  } catch (e) { toast(e.message || 'Import failed'); }
}

async function wipe() {
  if (!(await confirmDialog({ title: 'Erase everything?', text: 'This permanently deletes your identity, contacts, messages and files from this device. It cannot be undone.', ok: 'Erase', danger: true }))) return;
  net.stop();
  await db.wipeAll();
  try { localStorage.removeItem(`peerlink:${S.profile || 'main'}:settings`); } catch { /* */ }
  location.reload();
}

/* ------------------------------ about ------------------------------ */
function openAbout() {
  page('about', 'About', (body) => {
    body.append(h('div', { class: 'hero-card' }, h('div', { class: 'logo' }, icon('link', 40)), h('h2', {}, 'PeerLink'), h('div', { class: 'pill' }, `Version ${APP.version}`),
      h('p', { class: 'bio' }, 'Serverless messenger, calls and file transfer. Built with PeerJS (WebRTC) and Capacitor.')),
      section('Features',
        h('div', { class: 'lrow col' }, h('ul', { class: 'feat' }, ['Direct P2P messaging with delivery and read receipts', 'Voice and video calls', 'Resumable file transfer (up to 1 GB per file)', 'Voice notes, photos, videos and files', 'Mesh group chats', 'Reactions, replies, edits, forwarding', 'Disappearing messages', 'Signed identities with key-change warnings and safety numbers', 'QR / link contact invites', 'App lock, custom signaling and TURN servers'].map((t) => h('li', {}, t))))));
  });
}
