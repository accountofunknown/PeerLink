// App shell: tabs, bottom navigation, in-app banners and Android back button logic.

import { h, icon, clear } from '../util.js';
import { S, bus } from '../state.js';
import * as D from '../data.js';
import { nav, closeTopLayer, hasLayer, toast } from './dom.js';
import { chatsTab, transfersTab, contactsTab } from './tabs.js';
import { settingsTab } from './settings.js';
import { openChat } from './chat.js';

const TABS = [['chats', 'Chats', 'chat'], ['transfers', 'Transfers', 'swap'], ['contacts', 'Contacts', 'users'], ['settings', 'Settings', 'settings']];
let current = 'chats';
let views = {}, buttons = {};

export function buildShell(root) {
  clear(root);
  views = { chats: chatsTab(), transfers: transfersTab(), contacts: contactsTab(), settings: settingsTab() };
  const stage = h('div', { class: 'stage' });
  for (const [k] of TABS) { views[k].classList.add('hidden'); stage.appendChild(views[k]); }
  const bar = h('nav', { class: 'tabbar', role: 'tablist' });
  for (const [k, label, ic] of TABS) {
    const b = h('button', { class: 'tabbtn', role: 'tab', 'aria-label': label, onclick: () => setTab(k) }, h('span', { class: 'pill-ic' }, icon(ic, 24), h('i', { class: 'nbadge hidden' })), h('span', { class: 'lbl' }, label));
    buttons[k] = b; bar.appendChild(b);
  }
  root.append(stage, bar, h('div', { id: 'pages' }), h('div', { id: 'banners-in' }));
  setTab('chats');
  const paintBadges = () => {
    const n = D.totalUnread();
    const b = buttons.chats.querySelector('.nbadge');
    b.classList.toggle('hidden', !n);
    b.textContent = n > 99 ? '99+' : n;
    document.title = n ? `(${n}) PeerLink` : 'PeerLink';
  };
  bus.on('chats', paintBadges);
  paintBadges();
  bus.on('banner', showBanner);
  bus.on('open-chat', (id) => { nav.popAll(); openChat(id); });
}

export function setTab(k) {
  if (!views[k]) return;
  current = k;
  for (const [key] of TABS) {
    views[key].classList.toggle('hidden', key !== k);
    buttons[key].classList.toggle('on', key === k);
    buttons[key].setAttribute('aria-selected', String(key === k));
  }
  bus.emit('tab', k);
}
export const currentTab = () => current;

function showBanner({ chatId, title, body }) {
  if (S.active === chatId) return;
  const box = document.getElementById('banners-in');
  if (!box) return;
  const el = h('button', { class: 'inbanner', onclick: () => { el.remove(); nav.popAll(); openChat(chatId); } }, h('b', {}, title), h('span', {}, body));
  box.appendChild(el);
  setTimeout(() => el.remove(), 4200);
  while (box.children.length > 2) box.firstChild.remove();
}

/** Returns true if the back press was consumed. */
export function handleBack() {
  if (S.locked) return true;
  if (closeTopLayer()) return true;
  if (nav.depth) { nav.pop(); return true; }
  if (current !== 'chats') { setTab('chats'); return true; }
  return false;
}
