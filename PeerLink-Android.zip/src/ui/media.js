// Voice recorder, QR code generation / scanning, voice-note player and media viewer.

import qrcode from 'qrcode-generator';
import { h, icon } from '../util.js';
import { transfer } from '../transfer.js';
import { sheet, toast } from './dom.js';

/* ---------------------------- voice recording ---------------------------- */
export async function startRecording(onLevel) {
  if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') throw new Error('Recording is not supported on this device.');
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); }
  catch { throw new Error('Microphone permission was denied.'); }
  const mime = ['audio/webm;codecs=opus', 'audio/ogg;codecs=opus', 'audio/webm', 'audio/mp4'].find((t) => MediaRecorder.isTypeSupported?.(t)) || '';
  const rec = new MediaRecorder(stream, mime ? { mimeType: mime, audioBitsPerSecond: 32000 } : undefined);
  const chunks = [];
  rec.ondataavailable = (e) => { if (e.data?.size) chunks.push(e.data); };
  const t0 = Date.now();
  const peaks = [];
  let ac, an, buf, raf, lastSample = 0;
  try {
    ac = new (window.AudioContext || window.webkitAudioContext)();
    const src = ac.createMediaStreamSource(stream);
    an = ac.createAnalyser(); an.fftSize = 512;
    src.connect(an);
    buf = new Uint8Array(an.fftSize);
    const loop = (t) => {
      an.getByteTimeDomainData(buf);
      let max = 0;
      for (let i = 0; i < buf.length; i++) max = Math.max(max, Math.abs(buf[i] - 128));
      const lvl = Math.min(1, max / 90);
      onLevel?.(lvl);
      if (t - lastSample > 120) { peaks.push(lvl); lastSample = t; }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
  } catch { /* waveform is optional */ }
  rec.start(250);
  const cleanup = () => { cancelAnimationFrame(raf); stream.getTracks().forEach((t) => t.stop()); ac?.close?.().catch(() => {}); };
  return {
    get elapsed() { return (Date.now() - t0) / 1000; },
    cancel() { try { rec.stop(); } catch { /* */ } cleanup(); },
    stop() {
      return new Promise((resolve) => {
        rec.onstop = () => {
          cleanup();
          const type = rec.mimeType || mime || 'audio/webm';
          const blob = new Blob(chunks, { type });
          const n = 40, wave = [];
          for (let i = 0; i < n; i++) {
            const a = Math.floor((i * peaks.length) / n), b = Math.max(a + 1, Math.floor(((i + 1) * peaks.length) / n));
            wave.push(Math.round(Math.max(...peaks.slice(a, b), 0.05) * 100) / 100);
          }
          resolve({ blob, dur: (Date.now() - t0) / 1000, wave, mime: type });
        };
        try { rec.stop(); } catch { resolve(null); }
      });
    },
  };
}

/* ---------------------------- QR ---------------------------- */
export function qrSvg(text, px = 240) {
  const qr = qrcode(0, 'M');
  qr.addData(text);
  qr.make();
  const n = qr.getModuleCount(), q = 3;
  let d = '';
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (qr.isDark(r, c)) d += `M${c + q},${r + q}h1v1h-1z`;
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', `0 0 ${n + q * 2} ${n + q * 2}`);
  svg.setAttribute('width', px); svg.setAttribute('height', px);
  svg.setAttribute('shape-rendering', 'crispEdges');
  svg.classList.add('qr');
  const bg = document.createElementNS(ns, 'rect');
  bg.setAttribute('width', '100%'); bg.setAttribute('height', '100%'); bg.setAttribute('fill', '#fff');
  const path = document.createElementNS(ns, 'path');
  path.setAttribute('d', d); path.setAttribute('fill', '#000');
  svg.append(bg, path);
  return svg;
}

/** Opens the camera and resolves with the first QR payload found (or null if cancelled). */
export function scanQR() {
  return new Promise((resolve) => {
    let stream, stopped = false, raf, finished = false;
    const video = h('video', { playsinline: true, muted: true, autoplay: true });
    video.muted = true;
    const canvas = document.createElement('canvas');
    const status = h('div', { class: 'scan-status' }, 'Point the camera at a PeerLink QR code');
    const finish = (val) => {
      if (finished) return; finished = true; stopped = true;
      cancelAnimationFrame(raf);
      stream?.getTracks().forEach((t) => t.stop());
      s.close(); resolve(val);
    };
    const s = sheet('Scan QR code', [h('div', { class: 'scanner' }, video, h('div', { class: 'scan-frame' }), status), h('div', { class: 'sheet-foot' }, h('button', { class: 'btn text', onclick: () => finish(null) }, 'Cancel'))], { onClose: () => finish(null), tall: true });
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
      } catch { status.textContent = 'Camera permission denied.'; return; }
      video.srcObject = stream;
      try { await video.play(); } catch { /* autoplay */ }
      const detector = 'BarcodeDetector' in window ? new window.BarcodeDetector({ formats: ['qr_code'] }) : null;
      let jsQR = null;
      if (!detector) { try { jsQR = (await import('jsqr')).default; } catch { status.textContent = 'QR scanning is unavailable.'; return; } }
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      let busy = false, last = 0;
      const tick = async (t) => {
        if (stopped) return;
        raf = requestAnimationFrame(tick);
        if (busy || t - last < 120 || video.readyState < 2 || !video.videoWidth) return;
        busy = true; last = t;
        try {
          if (detector) {
            const r = await detector.detect(video);
            if (r[0]?.rawValue) finish(r[0].rawValue);
          } else {
            const w = Math.min(640, video.videoWidth), hh = Math.round((w * video.videoHeight) / video.videoWidth);
            canvas.width = w; canvas.height = hh;
            ctx.drawImage(video, 0, 0, w, hh);
            const img = ctx.getImageData(0, 0, w, hh);
            const code = jsQR(img.data, w, hh, { inversionAttempts: 'dontInvert' });
            if (code?.data) finish(code.data);
          }
        } catch { /* keep scanning */ }
        busy = false;
      };
      raf = requestAnimationFrame(tick);
    })();
  });
}

/* ---------------------------- voice-note player ---------------------------- */
const audio = new Audio();
audio.preload = 'auto';
export const player = { id: null, rate: 1, listeners: new Set() };
const notify = () => player.listeners.forEach((f) => f());
audio.addEventListener('timeupdate', notify);
audio.addEventListener('ended', () => { player.id = null; notify(); });
audio.addEventListener('pause', notify);
audio.addEventListener('play', notify);

export async function togglePlay(m) {
  const tid = m.file.tid;
  if (player.id === tid && !audio.paused) { audio.pause(); return; }
  if (player.id !== tid) {
    const url = await transfer.url(tid);
    if (!url) { toast('Voice message not available'); return; }
    audio.src = url;
    player.id = tid;
  }
  audio.playbackRate = player.rate;
  try { await audio.play(); } catch { toast('Cannot play this audio'); }
}
export function cycleRate() { player.rate = player.rate === 1 ? 1.5 : player.rate === 1.5 ? 2 : 1; audio.playbackRate = player.rate; notify(); }
export const playerState = (tid) => ({ playing: player.id === tid && !audio.paused, pos: player.id === tid ? audio.currentTime : 0, dur: player.id === tid && isFinite(audio.duration) ? audio.duration : 0 });
export function seek(tid, frac) { if (player.id === tid && isFinite(audio.duration)) audio.currentTime = frac * audio.duration; }
export function stopAudio() { audio.pause(); player.id = null; notify(); }

export function voiceWidget(m, mine) {
  const f = m.file;
  const bars = f.wave?.length ? f.wave : Array.from({ length: 40 }, (_, i) => 0.25 + 0.2 * Math.abs(Math.sin(i * 0.7)));
  const playBtn = h('button', { class: 'vplay', 'aria-label': 'Play' }, icon('play', 20));
  const wave = h('div', { class: 'vwave' }, bars.map((v) => h('i', { style: { height: `${Math.max(12, v * 100)}%` } })));
  const time = h('span', { class: 'vtime' }, '');
  const rate = h('button', { class: 'vrate' }, '1×');
  const paint = () => {
    const st = playerState(f.tid);
    const frac = st.dur ? st.pos / st.dur : 0;
    [...wave.children].forEach((b, i) => b.classList.toggle('on', i / bars.length < frac));
    playBtn.replaceChildren(icon(st.playing ? 'pause' : 'play', 20));
    const total = f.dur || st.dur || 0;
    const sec = st.playing || st.pos ? st.pos : total;
    time.textContent = `${Math.floor(sec / 60)}:${String(Math.floor(sec % 60)).padStart(2, '0')}`;
    rate.textContent = `${player.rate}×`;
    rate.style.display = st.playing ? '' : 'none';
  };
  playBtn.onclick = () => togglePlay(m);
  rate.onclick = cycleRate;
  wave.onclick = (e) => { const r = wave.getBoundingClientRect(); seek(f.tid, (e.clientX - r.left) / r.width); };
  player.listeners.add(paint);
  const el = h('div', { class: `voice${mine ? ' mine' : ''}` }, playBtn, h('div', { class: 'vmid' }, wave, time), rate);
  el._cleanup = () => player.listeners.delete(paint);
  paint();
  return el;
}

/* ---------------------------- viewer ---------------------------- */
export async function openViewer(m, { onSave, onShare } = {}) {
  const url = await transfer.url(m.file.tid);
  if (!url) { toast('File not available'); return; }
  const media = m.kind === 'video'
    ? h('video', { src: url, controls: true, autoplay: true, playsinline: true, class: 'viewer-media' })
    : h('img', { src: url, class: 'viewer-media', alt: m.file.name });
  let scale = 1;
  if (m.kind === 'image') media.addEventListener('dblclick', () => { scale = scale === 1 ? 2.5 : 1; media.style.transform = `scale(${scale})`; });
  const s = sheet(null, [h('div', { class: 'viewer' },
    h('div', { class: 'viewer-bar' }, h('button', { class: 'icon-btn', onclick: () => s.close() }, icon('x')), h('span', { class: 'vt' }, m.file.name),
      onSave ? h('button', { class: 'icon-btn', onclick: onSave }, icon('download')) : null,
      onShare ? h('button', { class: 'icon-btn', onclick: onShare }, icon('share')) : null),
    h('div', { class: 'viewer-stage' }, media))], { tall: true });
  s.el.classList.add('viewer-sheet');
}
