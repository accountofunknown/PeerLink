// Root tab screens: Chats, Transfers, Contacts.

import { h, icon, clear, fmtShort, fmtBytes, fmtSpeed, fmtEta, debounce, timeAgo } from '../util.js';
import { S, bus } from '../state.js';
import * as D from '../data.js';
import * as db from '../db.js';
import { net } from '../net.js';
import { chat as chatSvc } from '../chat.js';
import { transfer } from '../transfer.js';
import { iconBtn, chatAvatar, peerAvatar, emptyState, actionSheet, pickContacts, toast, sheet } from './dom.js';
import { openChat, pickFiles, sendPickedFiles } from './chat.js';
import { newChatFlow, addContactSheet, showMyQR, openContactInfo } from './contacts.js';

const NET_TEXT = { idle: 'Starting…', connecting: 'Connecting…', online: 'Connected', reconnecting: 'Reconnecting…', offline: 'No internet', conflict: 'ID in use', error: 'Connection error' };

export function netPill() {
  const el = h('button', { class: 'netpill', onclick: () => bus.emit('open-diagnostics') });
  const paint = () => {
    el.className = `netpill ${S.netState}`;
    el.replaceChildren(h('i'), NET_TEXT[S.netState] || S.netState);
  };
  net.on('state', paint);
  paint();
  return el;
}

function header(title, ...actions) {
  return h('header', { class: 'appbar root' }, h('div', { class: 'ab-title' }, h('div', { class: 't big' }, title), netPill()), h('div', { class: 'ab-actions' }, actions));
}

/* ------------------------------ chats ------------------------------ */
export function chatsTab() {
  const el = h('div', { class: 'tab' });
  const list = h('div', { class: 'list' });
  const input = h('input', { type: 'search', placeholder: 'Search chats and messages', autocomplete: 'off' });
  const search = h('div', { class: 'search-box' }, icon('search', 18), input);
  const fab = h('button', { class: 'fab', 'aria-label': 'New chat', onclick: newChatFlow }, icon('plus', 26));
  el.append(header('Chats', iconBtn('qr', 'My QR code', showMyQR)), search, h('div', { class: 'scroll' }, list), fab);

  let q = '', hits = [];
  const row = (ch) => {
    const typing = [...(S.typing.get(ch.id)?.values() || [])].some((x) => x > Date.now());
    const last = ch.last;
    const prefix = ch.type === 'group' && last && last.from !== 'sys' ? `${last.from === S.me.id ? 'You' : D.nameOf(last.from)}: ` : last?.from === S.me.id ? '' : '';
    return h('button', { class: `crow${ch.unread ? ' unread' : ''}`, onclick: () => openChat(ch.id) },
      chatAvatar(ch, 52),
      h('div', { class: 'cmain' },
        h('div', { class: 'ctop' }, h('span', { class: 'cname' }, D.chatTitle(ch), ch.request ? h('em', { class: 'req' }, 'request') : null), h('span', { class: 'ctime' }, fmtShort(ch.ts))),
        h('div', { class: 'cbot' },
          h('span', { class: `cprev${typing ? ' typing' : ''}` }, typing ? 'typing…' : ch.draft ? h('span', {}, h('b', { class: 'draft' }, 'Draft: '), ch.draft) : (last ? `${prefix}${last.text}` : 'No messages yet')),
          ch.muted ? icon('bell-off', 15) : null, ch.pinned ? icon('pin', 15) : null,
          ch.unread ? h('span', { class: 'badge-n' }, ch.unread > 99 ? '99+' : ch.unread) : null)));
  };
  const paint = () => {
    clear(list);
    if (q.length >= 2) {
      const chats = D.chatList().filter((c) => D.chatTitle(c).toLowerCase().includes(q.toLowerCase()));
      chats.forEach((c) => list.appendChild(row(c)));
      if (hits.length) list.appendChild(h('div', { class: 'list-h' }, 'Messages'));
      for (const m of hits) {
        const ch = D.getChat(m.chatId);
        if (!ch) continue;
        list.appendChild(h('button', { class: 'crow', onclick: () => openChat(ch.id) }, chatAvatar(ch, 44), h('div', { class: 'cmain' }, h('div', { class: 'ctop' }, h('span', { class: 'cname' }, D.chatTitle(ch)), h('span', { class: 'ctime' }, fmtShort(m.ts))), h('div', { class: 'cbot' }, h('span', { class: 'cprev' }, m.text || m.file?.name)))));
      }
      if (!chats.length && !hits.length) list.appendChild(emptyState('search', 'No results'));
      return;
    }
    const chats = D.chatList();
    if (!chats.length) {
      list.appendChild(emptyState('chat', 'No conversations yet', 'Add a friend by their PeerLink ID or QR code to start chatting — directly, device to device.',
        h('div', { class: 'btn-row center' }, h('button', { class: 'btn primary', onclick: () => addContactSheet() }, icon('user-plus', 18), ' Add contact'), h('button', { class: 'btn', onclick: showMyQR }, icon('qr', 18), ' My QR'))));
      return;
    }
    chats.forEach((c) => list.appendChild(row(c)));
  };
  const schedule = debounce(paint, 60);
  input.addEventListener('input', debounce(async () => {
    q = input.value.trim();
    hits = q.length >= 2 ? await db.scanMessages((m) => !m.deleted && m.kind !== 'system' && (m.text || m.file?.name || '').toLowerCase().includes(q.toLowerCase()), 25) : [];
    paint();
  }, 250));
  bus.on('chats', schedule); bus.on('presence', schedule); bus.on('typing', schedule); bus.on('contacts', schedule);
  paint();
  return el;
}

/* ------------------------------ transfers ------------------------------ */
export function transfersTab() {
  const el = h('div', { class: 'tab' });
  const body = h('div', { class: 'scroll pad' });
  const send = async () => {
    const chats = [...S.contacts.values()].filter((c) => !c.blocked && !c.implicit);
    if (!chats.length) { toast('Add a contact first'); addContactSheet(); return; }
    pickContacts({ title: 'Send files to…', multi: false, includeGroups: true, onDone: async ([id]) => {
      if (!id.startsWith('g:')) await chatSvc.ensureDm(id);
      const files = await pickFiles({ accept: '*/*' });
      if (files.length) { toast(`Sending ${files.length} file${files.length > 1 ? 's' : ''}…`); sendPickedFiles(id, files); }
    } });
  };
  el.append(header('Transfers', iconBtn('upload', 'Send files', send)), body);
  let history = [];
  const loadHistory = async () => { history = await db.recentFiles(60); paint(); };

  const sessionCard = (s) => {
    const p = transfer.progress(s.tid);
    if (!p) return null;
    const pct = Math.round((p.bytes / Math.max(1, p.size)) * 100);
    const who = D.nameOf(s.peer);
    return h('div', { class: 'tcard' },
      h('div', { class: 'tc-ic' }, icon(s.dir === 'out' ? 'upload' : 'download', 22)),
      h('div', { class: 'tc-main' },
        h('div', { class: 'tc-n' }, s.name),
        h('div', { class: 'tc-s' }, `${s.dir === 'out' ? 'To' : 'From'} ${who} · ${p.state === 'paused' ? (p.userPaused ? 'paused' : 'paused — will resume') : p.state === 'queued' ? 'queued' : p.state === 'offered' ? 'waiting for you' : p.state === 'offering' ? 'waiting for them' : `${pct}%`}${p.speed > 1 ? ` · ${fmtSpeed(p.speed)}` : ''}${isFinite(p.eta) && p.eta > 0 ? ` · ${fmtEta(p.eta)}` : ''}`),
        h('div', { class: 'bar' }, h('i', { style: { width: `${pct}%` } }))),
      p.state === 'offered' ? h('button', { class: 'btn primary sm', onclick: () => transfer.accept(s.key) }, 'Accept') : null,
      p.state === 'paused' && p.userPaused && p.pausedBy !== 'peer' ? h('button', { class: 'icon-btn', 'aria-label': 'Resume', onclick: () => transfer.resume(s.tid) }, icon('play', 20)) : null,
      ['sending', 'receiving', 'queued'].includes(p.state) ? h('button', { class: 'icon-btn', 'aria-label': 'Pause', onclick: () => transfer.pause(s.tid) }, icon('pause', 20)) : null,
      h('button', { class: 'icon-btn', 'aria-label': 'Cancel', onclick: () => (p.state === 'offered' ? transfer.reject(s.key) : transfer.cancel(s.tid)) }, icon('x', 20)));
  };

  const histRow = (m) => {
    const mine = m.from === S.me.id;
    const st = m.file.state;
    const label = st === 'done' ? 'Received' : st === 'sent' ? 'Sent' : st === 'deleted' ? 'Deleted' : st[0].toUpperCase() + st.slice(1);
    const peerName = D.chatTitle(D.getChat(m.chatId) || { id: m.chatId, type: 'dm' });
    return h('button', { class: 'tcard hist', onclick: () => openChat(m.chatId) },
      h('div', { class: 'tc-ic soft' }, icon(m.kind === 'image' ? 'image' : m.kind === 'voice' ? 'mic' : m.kind === 'video' ? 'video' : 'file', 22)),
      h('div', { class: 'tc-main' }, h('div', { class: 'tc-n' }, m.file.name), h('div', { class: 'tc-s' }, `${label} · ${fmtBytes(m.file.size)} · ${mine ? 'to' : 'from'} ${peerName} · ${fmtShort(m.ts)}`)),
      icon('chevron', 18));
  };

  const paint = () => {
    clear(body);
    const live = transfer.activeSessions().filter((s) => transfer.progress(s.tid));
    const seen = new Set();
    const cards = live.filter((s) => { const k = s.key; if (seen.has(k)) return false; seen.add(k); return true; }).map(sessionCard).filter(Boolean);
    body.appendChild(h('div', { class: 'xfer-hero' },
      h('div', {}, h('b', {}, 'Direct file transfer'), h('p', {}, 'Files go straight from device to device over WebRTC — no server stores them. Transfers pause and resume automatically if the connection drops.')),
      h('button', { class: 'btn primary', onclick: send }, icon('upload', 18), ' Send files')));
    if (cards.length) { body.appendChild(h('h4', { class: 'list-h' }, 'In progress')); cards.forEach((c) => body.appendChild(c)); }
    body.appendChild(h('h4', { class: 'list-h' }, 'Recent'));
    const rows = history.filter((m) => m.file && !(transfer.progress(m.file.tid) && ['sending', 'receiving', 'paused', 'offering', 'offered'].includes(transfer.progress(m.file.tid).state)));
    if (!rows.length) body.appendChild(emptyState('swap', 'No transfers yet', 'Photos, videos, voice notes and files you send or receive appear here.'));
    rows.forEach((m) => body.appendChild(histRow(m)));
  };
  transfer.on('progress', debounce(() => { if (el.isConnected && el.offsetParent) { paint(); } }, 250));
  bus.on('msg', debounce((cid, m) => { if (m?.file) loadHistory(); }, 400));
  bus.on('tab', (t) => { if (t === 'transfers') loadHistory(); });
  loadHistory();
  return el;
}

/* ------------------------------ contacts ------------------------------ */
export function contactsTab() {
  const el = h('div', { class: 'tab' });
  const list = h('div', { class: 'list' });
  const refresh = h('button', { class: 'icon-btn', 'aria-label': 'Check who is online' });
  refresh.appendChild(icon('refresh', 22));
  refresh.onclick = async () => { refresh.classList.add('spin'); await chatSvc.probeAll(); refresh.classList.remove('spin'); toast(`${net.onlineIds().filter((id) => D.isContact(id)).length} online`); };
  const fab = h('button', { class: 'fab', 'aria-label': 'Add contact', onclick: () => addContactSheet() }, icon('user-plus', 24));
  el.append(header('Contacts', refresh, iconBtn('qr', 'My QR code', showMyQR)), h('div', { class: 'scroll' }, list), fab);
  const paint = () => {
    clear(list);
    const cs = [...S.contacts.values()].filter((c) => !c.implicit).sort((a, b) => (net.isOnline(b.id) ? 1 : 0) - (net.isOnline(a.id) ? 1 : 0) || D.nameOf(a.id).localeCompare(D.nameOf(b.id)));
    if (!cs.length) { list.appendChild(emptyState('users', 'No contacts', 'Share your ID or QR code, or add a friend with theirs.', h('button', { class: 'btn primary', onclick: () => addContactSheet() }, icon('user-plus', 18), ' Add contact'))); return; }
    for (const c of cs) {
      const on = net.isOnline(c.id);
      list.appendChild(h('div', { class: 'crow static' },
        h('button', { class: 'crow-hit', onclick: async () => { await chatSvc.ensureDm(c.id); openChat(c.id); } },
          peerAvatar(c.id, 48, true),
          h('div', { class: 'cmain' }, h('div', { class: 'ctop' }, h('span', { class: 'cname' }, D.nameOf(c.id), c.verified ? h('span', { class: 'vfy' }, icon('shield', 14)) : null, c.blocked ? h('em', { class: 'req' }, 'blocked') : null)), h('div', { class: 'cbot' }, h('span', { class: `cprev${on ? ' on' : ''}` }, on ? 'online' : c.lastSeen ? `last seen ${timeAgo(c.lastSeen)}` : c.id)))),
        h('button', { class: 'icon-btn', 'aria-label': 'Info', onclick: () => openContactInfo(c.id) }, icon('info', 20))));
    }
  };
  const schedule = debounce(paint, 60);
  bus.on('contacts', schedule); bus.on('presence', schedule);
  paint();
  return el;
}
