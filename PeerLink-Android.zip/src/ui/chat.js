// The conversation screen.

import { h, icon, linkify, fmtClock, fmtDay, fmtBytes, fmtSpeed, fmtEta, fmtDur, fmtTtl, timeAgo, debounce, clear, colorFor } from '../util.js';
import { S, bus } from '../state.js';
import * as D from '../data.js';
import * as db from '../db.js';
import { net } from '../net.js';
import { chat as chatSvc } from '../chat.js';
import { transfer, compressImage } from '../transfer.js';
import { calls } from '../calls.js';
import { nav, iconBtn, chatAvatar, avatar, actionSheet, sheet, toast, confirmDialog, infoDialog, listRow, emptyState, pickContacts, toggle } from './dom.js';
import { startRecording, voiceWidget, openViewer } from './media.js';
import { haptic } from '../notify.js';

const EMOJI = '😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 😎 🤩 🥳 😏 😌 😴 🤔 🤨 😐 😶 🙄 😬 😮 😲 😳 🥺 😢 😭 😤 😡 🤯 😱 😰 🤗 🤭 🤫 🙏 👍 👎 👏 🙌 👌 ✌️ 🤞 🤝 💪 👀 🔥 ✨ 🎉 💯 ❤️ 🧡 💛 💚 💙 💜 🖤 💔 ⭐ ✅ ❌ ⚡ 🚀 🎵 🍕 ☕ 🍻 🌈 🌞 🌙 🐶 🐱 🦊 🐼'.split(' ');
const QUICK = ['👍', '❤️', '😂', '😮', '😢', '🙏'];

export function openChat(chatId) {
  const existing = nav.stack.find((p) => p.name === 'chat' && p.chatId === chatId);
  if (existing) return;
  nav.push('chat', (ctx) => { ctx.chatId = chatId; buildChat(ctx, chatId); });
}

export function pickFiles({ accept = '*/*', capture, multiple = true } = {}) {
  return new Promise((resolve) => {
    const input = h('input', { type: 'file', accept, multiple: multiple && !capture, style: 'position:fixed;left:-9999px;opacity:0' });
    if (capture) input.setAttribute('capture', capture);
    let done = false;
    const finish = (files) => { if (done) return; done = true; input.remove(); resolve(files); };
    input.addEventListener('change', () => finish([...input.files]));
    input.addEventListener('cancel', () => finish([]));
    document.body.appendChild(input);
    input.click();
    setTimeout(() => window.addEventListener('focus', () => setTimeout(() => finish([...(input.files || [])]), 800), { once: true }), 500);
  });
}

export async function sendPickedFiles(chatId, files) {
  for (const f of files) {
    try { await transfer.sendFile(chatId, f); }
    catch (e) { toast(e.message || 'Could not send file'); }
  }
}

function buildChat(ctx, chatId) {
  let ch = D.getChat(chatId);
  if (!ch) { chatSvc.ensureDm(chatId).then((c) => { ch = c; }); ch = { id: chatId, type: 'dm', request: !D.isContact(chatId) }; }
  const isGroup = () => ch.type === 'group';
  const prevActive = S.active;
  S.active = chatId;
  ctx.cleanup.push(() => { S.active = prevActive === chatId ? null : prevActive; stopTimers(); });

  const cache = new Map();      // id -> message
  const rows = new Map();       // id -> element
  let oldest = null, hasMore = true, loading = false;
  let replyTo = null, editing = null, recorder = null, recTimer = null;
  let lastDay = '', lastMsg = null;

  /* ------------------------------- header ------------------------------- */
  const subEl = h('div', { class: 's' });
  const titleEl = h('div', { class: 't' });
  const avWrap = h('div', { class: 'ab-av' });
  const headTap = h('button', { class: 'ab-head', onclick: openInfo }, avWrap, h('div', { class: 'ab-title' }, titleEl, subEl));
  const callBtns = h('span', { class: 'row-gap' });
  const paintHeader = () => {
    ch = D.getChat(chatId) || ch;
    titleEl.textContent = D.chatTitle(ch);
    avWrap.replaceChildren(chatAvatar(ch, 38));
    const typers = [...(S.typing.get(chatId)?.entries() || [])].filter(([, exp]) => exp > Date.now()).map(([id]) => D.nameOf(id));
    if (typers.length) { subEl.textContent = isGroup() ? `${typers.join(', ')} typing…` : 'typing…'; subEl.className = 's typing'; }
    else if (isGroup()) { subEl.className = 's'; subEl.textContent = ch.left ? 'You left this group' : `${ch.members.length} members${ch.ttl ? ` · ⏱ ${fmtTtl(ch.ttl)}` : ''}`; }
    else {
      const p = S.presence.get(chatId); const l = net.link(chatId);
      subEl.className = `s${p?.online ? ' on' : ''}`;
      if (p?.online) subEl.textContent = `online · ${l?.route === 'relay' ? 'relayed' : 'direct'}${l?.rtt != null ? ` · ${l.rtt} ms` : ''}${ch.ttl ? ` · ⏱ ${fmtTtl(ch.ttl)}` : ''}`;
      else { const c = D.getContact(chatId); subEl.textContent = c?.lastSeen ? `last seen ${timeAgo(c.lastSeen)}` : (net.online ? 'offline' : 'you are offline'); }
    }
    callBtns.replaceChildren(...(!isGroup() && !ch.request ? [iconBtn('phone', 'Voice call', () => startCall(false)), iconBtn('video', 'Video call', () => startCall(true))] : []));
  };
  const startCall = async (video) => { try { await calls.start(chatId, video); } catch (e) { toast(e.message); } };
  const header = h('header', { class: 'appbar' }, iconBtn('back', 'Back', () => nav.pop(ctx)), headTap, callBtns, iconBtn('more', 'More', openMenu));

  /* ------------------------------- banners ------------------------------- */
  const banner = h('div', { class: 'banners' });
  const paintBanner = () => {
    clear(banner);
    ch = D.getChat(chatId) || ch;
    const c = D.getContact(chatId);
    if (ch.request) {
      banner.appendChild(h('div', { class: 'banner warn' },
        h('div', {}, h('b', {}, isGroup() ? 'Group invitation' : 'Message request'), h('div', { class: 'small' }, isGroup() ? 'Someone you do not know added you.' : `${chatId} is not in your contacts. Files will not download automatically.`)),
        h('div', { class: 'row-gap' },
          h('button', { class: 'btn primary sm', onclick: async () => { await chatSvc.acceptRequest(chatId); paintBanner(); } }, 'Accept'),
          h('button', { class: 'btn danger sm', onclick: async () => { if (isGroup()) { await chatSvc.leaveGroup(ch); await chatSvc.deleteChat(chatId); } else { await chatSvc.setBlocked(chatId, true); await chatSvc.deleteChat(chatId); } nav.pop(ctx); } }, isGroup() ? 'Decline' : 'Block'))));
    }
    if (!isGroup() && c?.keyChanged) {
      banner.appendChild(h('div', { class: 'banner danger' },
        h('div', {}, h('b', {}, c.keyChanged.unexpected ? 'Wrong identity answered' : 'Security identity changed'), h('div', { class: 'small' }, c.keyChanged.unexpected ? `This ID did not answer with the key from the QR code / introduction. Do not trust it unless you can verify ${D.nameOf(chatId)} in person.` : `${D.nameOf(chatId)} is using a different key than before. Verify with them before trusting.`)),
        h('button', { class: 'btn sm', onclick: async () => { await chatSvc.trustKey(chatId); paintBanner(); } }, c.keyChanged.unexpected ? 'Trust anyway' : 'Trust new key')));
    }
    if (ch.left) banner.appendChild(h('div', { class: 'banner' }, 'You are no longer a member of this group.'));
    if (S.netState !== 'online' && S.netState !== 'idle') {
      const txt = { connecting: 'Connecting to the server…', reconnecting: 'Reconnecting to the server…', offline: 'No internet connection', conflict: 'Your ID is in use on the server', error: 'Cannot reach the server' }[S.netState] || S.netState;
      banner.appendChild(h('div', { class: 'banner warn' }, h('div', {}, h('b', {}, txt), h('div', { class: 'small' }, 'Messages are saved and sent automatically when you are connected.')),
        h('button', { class: 'btn sm', onclick: () => bus.emit('open-diagnostics', { run: true }) }, 'Diagnose')));
    }
  };

  /* ------------------------------- messages ------------------------------- */
  const list = h('div', { class: 'msgs' });
  const scroller = h('div', { class: 'msgs-wrap', onscroll: () => { onScroll(); } }, list);
  const jump = h('button', { class: 'jump hidden', onclick: () => { scrollBottom(true); } }, icon('download', 18), h('span', {}, 'New'));
  const atBottom = () => scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight < 90;
  const scrollBottom = (smooth) => { scroller.scrollTo({ top: scroller.scrollHeight, behavior: smooth ? 'smooth' : 'auto' }); jump.classList.add('hidden'); };

  async function onScroll() {
    if (atBottom()) jump.classList.add('hidden');
    if (scroller.scrollTop < 120 && hasMore && !loading) loadMore();
  }
  async function loadMore() {
    if (!oldest) return;
    loading = true;
    const page = await db.msgPage(chatId, { ts: oldest.ts, id: oldest.id }, 40);
    if (page.length < 40) hasMore = false;
    if (page.length) {
      const prevH = scroller.scrollHeight;
      renderAll([...page, ...[...cache.values()].sort(cmp)], true);
      scroller.scrollTop += scroller.scrollHeight - prevH;
    }
    loading = false;
  }
  const cmp = (a, b) => a.ts - b.ts || (a.id < b.id ? -1 : 1);

  function renderAll(msgs, keepScroll) {
    rows.forEach((el) => el._cleanup?.());
    clear(list); rows.clear(); cache.clear(); lastDay = ''; lastMsg = null;
    msgs.sort(cmp);
    oldest = msgs[0] || null;
    for (const m of msgs) appendRow(m);
    if (!msgs.length) list.appendChild(h('div', { class: 'chat-empty' }, isGroup() ? 'No messages yet. Say hi to the group!' : 'No messages yet. Messages are sent directly peer-to-peer and end-to-end encrypted by WebRTC.'));
    if (!keepScroll) scrollBottom(false);
  }

  function appendRow(m) {
    cache.set(m.id, m);
    list.querySelector('.chat-empty')?.remove();
    const day = new Date(m.ts).toDateString();
    if (day !== lastDay) { list.appendChild(h('div', { class: 'day' }, h('span', {}, fmtDay(m.ts)))); lastDay = day; }
    const el = bubble(m, lastMsg);
    rows.set(m.id, el);
    list.appendChild(el);
    lastMsg = m;
  }

  function onMsgEvent(cid, m, op) {
    if (cid !== chatId) return;
    if (op === 'add') {
      if (cache.has(m.id)) return;
      const stick = atBottom() || m.from === S.me.id;
      if (!lastMsg || m.ts >= lastMsg.ts) appendRow(m); else renderAll([...cache.values(), m], true);
      if (stick) scrollBottom(true); else jump.classList.remove('hidden');
      if (m.from !== S.me.id && S.visible && !S.locked) chatSvc.markRead(chatId);
    } else if (op === 'upd') {
      const old = rows.get(m.id);
      cache.set(m.id, m);
      if (old) { const prev = [...cache.values()].filter((x) => x.ts < m.ts).sort(cmp).pop(); const el = bubble(m, prev || null); old._cleanup?.(); old.replaceWith(el); rows.set(m.id, el); }
    } else if (op === 'del') {
      const old = rows.get(m.id);
      old?._cleanup?.(); old?.remove(); rows.delete(m.id); cache.delete(m.id);
      if (!cache.size) renderAll([], true);
    }
  }

  /* --------------------------- bubble rendering --------------------------- */
  function pressable(el, onLong) {
    let t = null, sx = 0, sy = 0;
    const cancel = () => { clearTimeout(t); t = null; };
    el.addEventListener('pointerdown', (e) => { sx = e.clientX; sy = e.clientY; cancel(); t = setTimeout(() => { t = null; haptic('medium'); onLong(); }, 420); });
    el.addEventListener('pointermove', (e) => { if (t && Math.hypot(e.clientX - sx, e.clientY - sy) > 10) cancel(); });
    for (const ev of ['pointerup', 'pointercancel', 'pointerleave']) el.addEventListener(ev, cancel);
    el.addEventListener('contextmenu', (e) => { e.preventDefault(); cancel(); onLong(); });
  }

  function statusIcon(m) {
    if (m.from !== S.me.id) return null;
    const s = m.status;
    if (s === 'read') return h('span', { class: 'tick read', title: 'Read' }, icon('checks', 16));
    if (s === 'delivered') return h('span', { class: 'tick', title: 'Delivered' }, icon('checks', 16));
    if (s === 'sent') return h('span', { class: 'tick', title: 'Sent' }, icon('check', 16));
    if (s === 'failed') return h('span', { class: 'tick bad', title: 'Failed - tap to retry', onclick: (e) => { e.stopPropagation(); chatSvc.retryMessage(m.id); } }, icon('alert', 16));
    if (s === 'queued') return h('span', { class: 'tick bad', title: 'Not delivered yet - tap for details', onclick: (e) => { e.stopPropagation(); explainDelivery(m); } }, icon('clock', 14));
    return h('span', { class: 'tick', title: 'Sending' }, icon('clock', 14));
  }

  function bubble(m, prev) {
    const mine = m.from === S.me.id;
    if (m.kind === 'system') return h('div', { class: 'sys', dataset: { id: m.id } }, h('span', {}, m.text));
    if (m.kind === 'call') {
      const miss = m.call?.result === 'missed' || m.call?.result === 'declined' || m.call?.result === 'failed';
      return h('div', { class: `sys call${miss ? ' miss' : ''}`, dataset: { id: m.id } }, h('span', {}, icon(m.call?.video ? 'video' : 'phone', 14), ` ${m.text}`, m.call?.dur ? ` · ${fmtDur(m.call.dur)}` : '', ` · ${fmtClock(m.ts)}`));
    }
    const wrap = h('div', { class: `row ${mine ? 'out' : 'in'}${prev && prev.from === m.from && prev.kind !== 'system' && m.ts - prev.ts < 180000 ? ' cont' : ''}`, dataset: { id: m.id } });
    const b = h('div', { class: `bubble${m.file?.thumb && m.kind === 'image' && !m.text ? ' media-only' : ''}` });
    if (isGroup() && !mine && !(prev && prev.from === m.from && prev.kind !== 'system')) b.appendChild(h('div', { class: 'sender', style: { color: colorFor(m.from) } }, D.nameOf(m.from)));
    if (m.fwd && !m.deleted) b.appendChild(h('div', { class: 'fwd' }, icon('forward', 13), ` Forwarded from ${m.fwd}`));
    if (m.replyTo && !m.deleted) {
      b.appendChild(h('div', { class: 'quote', onclick: (e) => { e.stopPropagation(); jumpTo(m.replyTo.id); } },
        h('b', {}, m.replyTo.from === S.me.id ? 'You' : D.nameOf(m.replyTo.from)), h('span', {}, m.replyTo.text || '…')));
    }
    if (m.deleted) b.appendChild(h('div', { class: 'deleted' }, icon('block', 14), mine ? ' You deleted this message' : ' This message was deleted'));
    else {
      if (m.file) { const fc = fileCard(m, mine); b.appendChild(fc); if (fc._cleanup) wrap._cleanup = fc._cleanup; }
      if (m.kind === 'poll') b.appendChild(pollCard(m));
      if (m.kind === 'contact') b.appendChild(contactCard(m));
      if (m.text) b.appendChild(h('div', { class: 'text' }, linkify(m.text)));
    }
    const meta = h('div', { class: 'meta' }, m.starred ? h('span', { class: 'tk star' }, icon('star', 11)) : null, m.edited ? h('i', {}, 'edited') : null, ch.ttl && m.exp ? h('span', { class: 'tk' }, icon('clock', 11)) : null, h('span', {}, fmtClock(m.ts)), statusIcon(m));
    b.appendChild(meta);
    if (m.reactions && Object.keys(m.reactions).length) {
      b.appendChild(h('div', { class: 'reacts' }, Object.entries(m.reactions).map(([e, who]) => h('button', { class: `react${who.includes(S.me.id) ? ' me' : ''}`, onclick: (ev) => { ev.stopPropagation(); chatSvc.react(m.id, e); } }, e, who.length > 1 ? h('small', {}, who.length) : null))));
    }
    pressable(b, () => msgMenu(m));
    wrap.appendChild(b);
    return wrap;
  }

  function explainDelivery(m) {
    const who = isGroup() ? 'the group members' : D.nameOf(chatId);
    const reason = m.err || (isGroup() ? null : net.lastFail.get(chatId)?.type);
    let title = 'Waiting to deliver', text;
    if (S.netState !== 'online') {
      title = 'You are not connected';
      text = `PeerLink is not connected to the signaling server (status: ${S.netState}). Your message is saved and will be sent automatically once you are back online.`;
    } else if (reason === 'peer-unavailable') {
      text = `${who} is not connected to the PeerJS server right now. PeerLink is peer-to-peer: the other phone must have PeerLink open (or running in the background) at the same time. The message is saved and is sent automatically the moment they appear.`;
    } else if (reason === 'timeout' || reason === 'closed') {
      title = 'Could not connect directly';
      text = `${who} is online, but a direct connection could not be established (firewall / NAT / mobile data). Run the connection test on both phones, and add a TURN server in Settings → Network if it reports TURN as unreachable.`;
    } else {
      text = `The message is queued. It is retried every 20 seconds while PeerLink is open. Reason: ${reason || 'unknown'}.`;
    }
    const s = sheet(title, [
      h('p', { class: 'sheet-note' }, text),
      h('div', { class: 'btn-row' },
        h('button', { class: 'btn', onclick: () => { s.close(); chatSvc.retryOutbox(); toast('Retrying…'); } }, icon('refresh', 18), ' Retry now'),
        h('button', { class: 'btn primary', onclick: () => { s.close(); bus.emit('open-diagnostics', { run: true }); } }, icon('activity', 18), ' Run test')),
    ]);
  }

  function pollCard(m) {
    const votes = m.votes || {};
    const total = new Set(Object.values(votes).flat()).size;
    const mine = new Set(Object.entries(votes).filter(([, l]) => l.includes(S.me.id)).map(([k]) => k));
    return h('div', { class: 'poll' },
      h('div', { class: 'poll-q' }, icon('poll', 16), ` ${m.poll.q}`),
      h('div', { class: 'poll-note' }, m.poll.multi ? 'Select one or more' : 'Select one'),
      m.poll.o.map((o) => {
        const n = (votes[o.id] || []).length;
        return h('button', { class: `poll-opt${mine.has(o.id) ? ' on' : ''}`, 'aria-pressed': String(mine.has(o.id)), onclick: (e) => {
          e.stopPropagation();
          const sel = new Set(mine);
          if (m.poll.multi) { if (sel.has(o.id)) sel.delete(o.id); else sel.add(o.id); }
          else if (sel.has(o.id)) sel.clear(); else { sel.clear(); sel.add(o.id); }
          haptic('light'); chatSvc.vote(m.id, [...sel]);
        } }, h('i', { class: 'poll-fill', style: { width: `${total ? Math.round((n / total) * 100) : 0}%` } }), h('span', { class: 'poll-t' }, o.t), h('span', { class: 'poll-n' }, String(n)));
      }),
      h('div', { class: 'poll-total' }, `${total} vote${total === 1 ? '' : 's'}`));
  }

  function contactCard(m) {
    const c = m.contact;
    const known = D.isContact(c.id);
    return h('div', { class: 'ccard' }, avatar({ id: c.id, name: c.name || c.id }, 40),
      h('div', { class: 'cc-t' }, h('b', {}, c.name || c.id), h('div', { class: 'small' }, c.id)),
      c.id === S.me.id ? null : h('button', { class: 'btn sm primary', onclick: async (e) => {
        e.stopPropagation();
        if (known) { nav.popAll(); openChat(c.id); return; }
        const mod = await import('./contacts.js');
        mod.addContactSheet({ id: c.id, name: c.name, fp: c.fp, via: 'intro' });
      } }, known ? 'Message' : 'Add'));
  }

  async function jumpTo(id) {
    let el = rows.get(id);
    if (!el) { renderAll(await db.msgAll(chatId), true); hasMore = false; el = rows.get(id); }
    if (!el) { toast('Original message not found'); return; }
    el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    el.classList.add('flash');
    setTimeout(() => el.classList.remove('flash'), 1400);
  }

  /* ------------------------------- file cards ------------------------------- */
  function fileView(m, mine) {
    const f = m.file;
    if (f.state === 'deleted') return { s: 'deleted' };
    const p = transfer.progress(f.tid);
    if (mine) {
      if (p && ['sending', 'queued', 'offering', 'paused'].includes(p.state)) return { s: p.state, p };
      if (f.state === 'sending') return { s: 'stalled' };
      return { s: f.state === 'sent' ? 'sent' : f.state, p };
    }
    if (p && ['offered', 'receiving', 'paused'].includes(p.state)) return { s: p.state, p };
    if (f.state === 'receiving') return { s: 'stalled' };
    return { s: f.state, p };
  }

  function fileCard(m, mine) {
    const f = m.file;
    const card = h('div', { class: `fcard k-${m.kind}`, dataset: { tid: f.tid } });
    let loadedUrl = false;
    const paint = () => {
      const { s, p } = fileView(m, mine);
      clear(card);
      card.dataset.state = s;
      const pct = p ? Math.round((p.bytes / Math.max(1, p.size)) * 100) : 0;
      const live = s === 'sending' || s === 'receiving';
      const statusText = {
        offering: 'Waiting for contact…', offered: 'Wants to send you this file', queued: 'Queued — starts when the previous file finishes', paused: p?.userPaused ? `Paused${p.pausedBy === 'peer' ? ' by the other side' : ''}` : 'Paused – will resume when online',
        stalled: 'Interrupted', rejected: 'Declined', cancelled: 'Cancelled', failed: 'Failed', deleted: 'File deleted',
        sent: 'Sent', done: fmtBytes(f.size),
      }[s];
      const prog = live && p
        ? h('div', { class: 'prog' }, h('div', { class: 'bar' }, h('i', { style: { width: `${pct}%` } })), h('div', { class: 'pt' }, `${pct}% · ${fmtBytes(p.bytes)} / ${fmtBytes(p.size)}`, p.speed > 1 ? ` · ${fmtSpeed(p.speed)}` : '', p.eta && isFinite(p.eta) ? ` · ${fmtEta(p.eta)}` : ''))
        : null;
      const actions = [];
      if (s === 'offered') actions.push(h('button', { class: 'btn primary sm', onclick: () => transfer.accept(`${f.tid}|${m.from}`) }, 'Accept'), h('button', { class: 'btn sm', onclick: () => transfer.reject(`${f.tid}|${m.from}`) }, 'Decline'));
      if (s === 'paused' && p?.userPaused && p.pausedBy !== 'peer') actions.push(h('button', { class: 'btn primary sm', onclick: () => transfer.resume(f.tid) }, icon('play', 14), ' Resume'));
      else if (live || s === 'queued') actions.push(h('button', { class: 'btn sm', onclick: () => transfer.pause(f.tid) }, icon('pause', 14), ' Pause'));
      if (live || s === 'paused' || s === 'offering' || s === 'queued') actions.push(h('button', { class: 'btn sm', onclick: () => transfer.cancel(f.tid) }, 'Cancel'));
      if (mine && (s === 'stalled' || s === 'failed' || s === 'cancelled' || s === 'rejected')) actions.push(h('button', { class: 'btn primary sm', onclick: async () => { if (!(await transfer.retry(m.id))) toast('File is no longer available to resend'); } }, 'Retry'));
      if (!mine && (s === 'stalled')) actions.push(h('button', { class: 'btn sm', onclick: () => transfer.cancel(f.tid) }, 'Discard'));

      const available = s === 'done' || (mine && ['sent', 'sending', 'offering', 'paused', 'stalled', 'failed', 'cancelled', 'rejected'].includes(s));

      if (m.kind === 'voice' && available && (s === 'done' || s === 'sent')) {
        const vw = voiceWidget(m, mine);
        card._cleanup = vw._cleanup;
        card.appendChild(vw);
        return;
      }
      if (m.kind === 'image' || (m.kind === 'video' && f.thumb)) {
        const img = h('img', { class: 'thumb', alt: f.name, src: f.thumb || '', style: f.w && f.h ? { aspectRatio: `${f.w} / ${f.h}` } : {} });
        const box = h('div', { class: 'imgbox' }, img);
        if ((s === 'done' || s === 'sent') && !loadedUrl) {
          loadedUrl = true;
          transfer.url(f.tid).then((u) => { if (u && m.kind === 'image') img.src = u; });
          box.onclick = () => openViewer(m, { onSave: () => saveFile(m), onShare: () => transfer.share(m).catch((e) => toast(e.message)) });
        }
        if (live) box.appendChild(h('div', { class: 'ring' }, h('span', {}, `${pct}%`)));
        if (s === 'offered' || s === 'paused' || s === 'stalled' || s === 'offering') box.appendChild(h('div', { class: 'veil' }, statusText));
        card.appendChild(box);
        if (prog) card.appendChild(prog);
        if (actions.length) card.appendChild(h('div', { class: 'acts' }, actions));
        return;
      }
      const ic = m.kind === 'video' ? 'video' : m.kind === 'voice' ? 'mic' : 'file';
      const head = h('div', { class: 'fhead' },
        h('div', { class: 'fic' }, icon(ic, 24)),
        h('div', { class: 'fmeta' }, h('div', { class: 'fname' }, f.name), h('div', { class: 'fsub' }, live ? `${fmtBytes(f.size)}` : `${statusText}${s !== 'done' && s !== 'sent' && s !== 'offered' ? ` · ${fmtBytes(f.size)}` : ''}${s === 'offered' ? ` · ${fmtBytes(f.size)}` : ''}`)));
      card.appendChild(head);
      if (prog) card.appendChild(prog);
      if (s === 'done' || (mine && (s === 'sent'))) {
        const row = [];
        if (m.kind === 'video') row.push(h('button', { class: 'btn primary sm', onclick: () => openViewer(m, { onSave: () => saveFile(m), onShare: () => transfer.share(m).catch((e) => toast(e.message)) }) }, 'Play'));
        row.push(h('button', { class: 'btn sm', onclick: () => saveFile(m) }, 'Save'), h('button', { class: 'btn sm', onclick: () => transfer.share(m).catch((e) => toast(e.message)) }, 'Open / Share'));
        card.appendChild(h('div', { class: 'acts' }, row));
      }
      if (actions.length) card.appendChild(h('div', { class: 'acts' }, actions));
    };
    paint();
    const off = transfer.on('progress', () => { if (card.isConnected) paint(); });
    const prevClean = card._cleanup;
    card._cleanup = () => { off(); prevClean?.(); };
    return card;
  }

  async function saveFile(m) {
    try {
      const r = await transfer.saveToDevice(m);
      toast(r === 'saved' ? 'Saved to Documents/PeerLink' : r === 'downloaded' ? 'Download started' : 'Choose where to save');
    } catch (e) { toast(e.message || 'Could not save file'); }
  }

  /* ------------------------------- message menu ------------------------------- */
  function msgMenu(m) {
    if (m.kind === 'system' || m.kind === 'call') return;
    const mine = m.from === S.me.id;
    const quick = h('div', { class: 'quick' }, QUICK.map((e) => h('button', { onclick: () => { s.close(); chatSvc.react(m.id, e); haptic('light'); } }, e)),
      h('button', { onclick: () => { s.close(); emojiPickerFor((e) => chatSvc.react(m.id, e)); } }, icon('plus', 20)));
    const items = [];
    if (!m.deleted) {
      if (!ch.left) items.push({ icon: 'reply', label: 'Reply', onClick: () => setReply(m) });
      if (m.text) items.push({ icon: 'copy', label: 'Copy text', onClick: () => { navigator.clipboard?.writeText(m.text).then(() => toast('Copied')).catch(() => toast('Copy failed')); } });
      if (mine && m.kind === 'text' && !ch.left) items.push({ icon: 'edit', label: 'Edit', onClick: () => startEdit(m) });
      if (m.file && (m.file.state === 'done' || (mine && m.file.state === 'sent'))) items.push({ icon: 'download', label: 'Save to device', onClick: () => saveFile(m) });
      items.push({ icon: 'star', label: m.starred ? 'Remove star' : 'Star', onClick: () => chatSvc.toggleStar(m.id) });
      if (['text', 'image', 'video', 'voice', 'file'].includes(m.kind)) items.push({ icon: 'forward', label: 'Forward', onClick: () => forwardMsg(m) });
      items.push({ icon: 'info', label: 'Message info', onClick: () => msgInfo(m) });
    }
    items.push({ icon: 'trash', label: 'Delete for me', danger: true, onClick: () => chatSvc.deleteMessage(m.id, false) });
    if (mine && !m.deleted && !ch.left) items.push({ icon: 'trash', label: 'Delete for everyone', danger: true, onClick: async () => { if (await confirmDialog({ title: 'Delete for everyone?', text: 'The message will be removed from all devices that receive it.', ok: 'Delete', danger: true })) chatSvc.deleteMessage(m.id, true); } });
    const s = sheet(null, [m.deleted ? null : quick, ...items.map((it) => h('button', { class: `row-btn${it.danger ? ' danger' : ''}`, onclick: () => { s.close(); setTimeout(it.onClick, 30); } }, icon(it.icon, 22), h('span', {}, it.label)))]);
  }

  function emojiPickerFor(cb) {
    const s = sheet('Pick an emoji', h('div', { class: 'emoji-grid' }, EMOJI.map((e) => h('button', { onclick: () => { s.close(); cb(e); } }, e))));
  }

  function forwardMsg(m) {
    pickContacts({ title: 'Forward to…', includeGroups: true, onDone: async (ids) => {
      try {
        const targets = [];
        for (const id of ids) { if (!id.startsWith('g:')) await chatSvc.ensureDm(id); targets.push(id); }
        await chatSvc.forward(m, targets);
        toast(`Forwarded to ${targets.length} chat${targets.length > 1 ? 's' : ''}`);
      } catch (e) { toast(e.message); }
    } });
  }

  function msgInfo(m) {
    const mine = m.from === S.me.id;
    const rows = [h('div', { class: 'kv' }, h('span', {}, 'Sent'), h('b', {}, new Date(m.ts).toLocaleString()))];
    if (!mine && m.rts) rows.push(h('div', { class: 'kv' }, h('span', {}, 'Received'), h('b', {}, new Date(m.rts).toLocaleString())));
    if (m.edited) rows.push(h('div', { class: 'kv' }, h('span', {}, 'Edited'), h('b', {}, new Date(m.edited).toLocaleString())));
    if (m.exp) rows.push(h('div', { class: 'kv' }, h('span', {}, 'Disappears'), h('b', {}, new Date(m.exp).toLocaleString())));
    if (m.file) rows.push(h('div', { class: 'kv' }, h('span', {}, 'File'), h('b', {}, `${m.file.name} · ${fmtBytes(m.file.size)}`)));
    if (mine) {
      if (isGroup()) for (const id of ch.members.filter((x) => x !== S.me.id)) rows.push(h('div', { class: 'kv' }, h('span', {}, D.nameOf(id)), h('b', {}, m.acks?.[id] || (m.status === 'queued' ? 'waiting' : 'sent'))));
      else rows.push(h('div', { class: 'kv' }, h('span', {}, 'Status'), h('b', {}, m.status)));
    }
    infoDialog('Message info', rows);
  }

  /* ------------------------------- composer ------------------------------- */
  const ta = h('textarea', { rows: 1, placeholder: 'Message', enterkeyhint: S.settings.enterSend ? 'send' : 'enter', maxlength: 20000, 'aria-label': 'Message' });
  const sendBtn = h('button', { class: 'send-btn', 'aria-label': 'Send', onclick: onSendOrMic }, icon('mic', 22));
  const replyBar = h('div', { class: 'replybar hidden' });
  const recBar = h('div', { class: 'recbar hidden' });
  const inputRow = h('div', { class: 'composer-row' },
    iconBtn('smile', 'Emoji', () => emojiPickerFor((e) => insertAtCursor(e))),
    ta, iconBtn('clip', 'Attach', attachMenu), sendBtn);
  const composer = h('footer', { class: 'composer' }, replyBar, recBar, inputRow);
  const saveDraft = debounce(() => { const c = D.getChat(chatId); if (c) { c.draft = ta.value; D.saveChat(c, true); } }, 600);

  function insertAtCursor(t) {
    const a = ta.selectionStart ?? ta.value.length, b = ta.selectionEnd ?? ta.value.length;
    ta.value = ta.value.slice(0, a) + t + ta.value.slice(b);
    ta.selectionStart = ta.selectionEnd = a + t.length;
    ta.focus(); autosize();
  }
  function autosize() {
    ta.style.height = 'auto';
    ta.style.height = `${Math.min(140, ta.scrollHeight)}px`;
    const has = ta.value.trim().length > 0 || !!editing;
    sendBtn.replaceChildren(icon(has ? 'send' : 'mic', 22));
    sendBtn.classList.toggle('has', has);
    if (ta.value && !editing) { chatSvc.typing(chatId); }
    saveDraft();
  }
  ta.addEventListener('input', autosize);
  ta.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && S.settings.enterSend) { e.preventDefault(); onSendOrMic(); } });

  function setReply(m) { replyTo = m; editing = null; paintReply(); ta.focus(); }
  function startEdit(m) { editing = m; replyTo = null; ta.value = m.text; paintReply(); autosize(); ta.focus(); }
  function paintReply() {
    clear(replyBar);
    if (!replyTo && !editing) { replyBar.classList.add('hidden'); return; }
    const m = editing || replyTo;
    replyBar.classList.remove('hidden');
    replyBar.append(icon(editing ? 'edit' : 'reply', 18), h('div', { class: 'rb-t' }, h('b', {}, editing ? 'Edit message' : `Reply to ${m.from === S.me.id ? 'yourself' : D.nameOf(m.from)}`), h('span', {}, D.preview(m).slice(0, 100))),
      h('button', { class: 'icon-btn', onclick: () => { replyTo = null; if (editing) { editing = null; ta.value = ''; autosize(); } paintReply(); } }, icon('x', 18)));
  }

  async function onSendOrMic() {
    if (ch.left) { toast('You left this group'); return; }
    const text = ta.value.trim();
    if (editing) { const m = editing; editing = null; ta.value = ''; paintReply(); autosize(); await chatSvc.editMessage(m.id, text); return; }
    if (text) {
      const rt = replyTo; replyTo = null; paintReply();
      ta.value = ''; autosize(); haptic('light');
      await chatSvc.sendText(chatId, text, { replyTo: rt });
      const c = D.getChat(chatId); if (c?.draft) { c.draft = ''; D.saveChat(c, true); }
      return;
    }
    if (recorder) { await finishRecording(true); return; }
    beginRecording();
  }

  async function beginRecording() {
    try {
      const bars = h('div', { class: 'rec-bars' });
      const time = h('span', { class: 'rec-time' }, '0:00');
      recBar.classList.remove('hidden'); inputRow.classList.add('hidden');
      clear(recBar);
      recBar.append(h('button', { class: 'icon-btn danger', 'aria-label': 'Cancel recording', onclick: () => finishRecording(false) }, icon('trash', 22)), h('span', { class: 'rec-dot' }), time, bars, h('button', { class: 'send-btn has', 'aria-label': 'Send voice message', onclick: () => finishRecording(true) }, icon('send', 22)));
      const lv = [];
      recorder = await startRecording((l) => { lv.push(l); if (lv.length > 36) lv.shift(); bars.replaceChildren(...lv.map((v) => h('i', { style: { height: `${Math.max(10, v * 100)}%` } }))); });
      recTimer = setInterval(() => { const s = Math.floor(recorder?.elapsed || 0); time.textContent = fmtDur(s); if (s >= 600) finishRecording(true); }, 250);
      haptic('medium');
    } catch (e) { recBar.classList.add('hidden'); inputRow.classList.remove('hidden'); recorder = null; toast(e.message); }
  }
  async function finishRecording(send) {
    const r = recorder; recorder = null; clearInterval(recTimer);
    recBar.classList.add('hidden'); inputRow.classList.remove('hidden');
    if (!r) return;
    if (!send) { r.cancel(); return; }
    const res = await r.stop();
    if (!res || res.dur < 0.6 || !res.blob.size) { toast('Hold a little longer to record'); return; }
    const ext = res.mime.includes('ogg') ? 'ogg' : res.mime.includes('mp4') ? 'm4a' : 'webm';
    const file = new File([res.blob], `voice-${Date.now()}.${ext}`, { type: res.mime });
    try { await transfer.sendFile(chatId, file, { kind: 'voice', dur: Math.round(res.dur), wave: res.wave }); }
    catch (e) { toast(e.message); }
  }
  function stopTimers() { clearInterval(recTimer); recorder?.cancel(); recorder = null; }

  async function sendCompressed(capture) {
    const files = await pickFiles({ accept: 'image/*', capture: capture ? 'environment' : undefined });
    for (const f of files) { try { await transfer.sendFile(chatId, await compressImage(f)); } catch (e) { toast(e.message); } }
  }

  function createPoll() {
    const q = h('input', { type: 'text', placeholder: 'Ask a question', maxlength: 200 });
    const list = h('div', { class: 'poll-opts' });
    const inputs = [];
    const addOpt = () => { if (inputs.length >= 6) return; const i = h('input', { type: 'text', placeholder: `Option ${inputs.length + 1}`, maxlength: 100 }); inputs.push(i); list.appendChild(i); };
    addOpt(); addOpt();
    let multi = false;
    const s = sheet('New poll', [
      q, list,
      h('button', { class: 'btn sm', onclick: addOpt }, icon('plus', 16), ' Add option'),
      h('div', { class: 'lrow' }, h('div', { class: 'lr-main' }, h('div', { class: 'lr-t' }, 'Allow multiple answers')), toggle(false, (v) => { multi = v; })),
      h('div', { class: 'sheet-foot' }, h('button', { class: 'btn primary wide', onclick: async () => {
        const opts = inputs.map((i) => i.value.trim()).filter(Boolean);
        if (!q.value.trim() || opts.length < 2) { toast('Enter a question and at least two options'); return; }
        s.close(); await chatSvc.sendPoll(chatId, q.value.trim(), opts, multi);
      } }, 'Send poll')),
    ], { tall: true });
    setTimeout(() => q.focus(), 100);
  }

  function attachMenu() {
    if (ch.left) return;
    actionSheet('Send', [
      { icon: 'image', label: 'Photos (compressed, no location data)', onClick: () => sendCompressed(false) },
      { icon: 'camera', label: 'Take a photo', onClick: () => sendCompressed(true) },
      { icon: 'folder', label: 'Photos & videos (original quality)', onClick: async () => sendPickedFiles(chatId, await pickFiles({ accept: 'image/*,video/*' })) },
      { icon: 'video', label: 'Record a video', onClick: async () => sendPickedFiles(chatId, await pickFiles({ accept: 'video/*', capture: 'environment' })) },
      { icon: 'file', label: 'Any file', onClick: async () => sendPickedFiles(chatId, await pickFiles({ accept: '*/*' })) },
      { icon: 'user', label: 'Contact', onClick: () => pickContacts({ title: 'Share a contact', multi: false, exclude: [chatId], onDone: ([id]) => chatSvc.sendContact(chatId, id) }) },
      { icon: 'poll', label: 'Poll', onClick: createPoll },
    ]);
  }

  /* ------------------------------- menus & info ------------------------------- */
  function openMenu() {
    const items = [
      { icon: 'search', label: 'Search in chat', onClick: searchChat },
      { icon: 'folder', label: 'Media & files', onClick: showMedia },
      { icon: 'star', label: 'Starred messages', onClick: showStarred },
      { icon: ch.muted ? 'bell' : 'bell-off', label: ch.muted ? 'Unmute notifications' : 'Mute notifications', onClick: () => chatSvc.setMuted(chatId, !ch.muted) },
      { icon: 'pin', label: ch.pinned ? 'Unpin chat' : 'Pin chat', onClick: () => chatSvc.setPinned(chatId, !ch.pinned) },
      !ch.request && !ch.left ? { icon: 'clock', label: 'Disappearing messages', hint: ch.ttl ? fmtTtl(ch.ttl) : 'Off', onClick: ttlMenu } : null,
      { icon: 'info', label: isGroup() ? 'Group info' : 'Contact info', onClick: openInfo },
      { icon: 'trash', label: 'Clear chat', danger: true, onClick: async () => { if (await confirmDialog({ title: 'Clear this chat?', text: 'All messages and files in this chat are deleted from this device.', ok: 'Clear', danger: true })) { await chatSvc.clearChat(chatId); renderAll([], false); } } },
    ];
    actionSheet(null, items);
  }

  function ttlMenu() {
    const opts = [[0, 'Off'], [300, '5 minutes'], [3600, '1 hour'], [86400, '24 hours'], [604800, '7 days']];
    if (isGroup() && ch.admin !== S.me.id) { toast('Only the group admin can change this'); return; }
    const s = sheet('Disappearing messages', [h('p', { class: 'sheet-note' }, 'New messages are deleted from both devices after the chosen time. This setting applies to messages sent after it is changed.'), ...opts.map(([v, l]) => h('button', { class: `row-btn${(ch.ttl || 0) === v ? ' sel' : ''}`, onclick: () => { s.close(); chatSvc.setTtl(ch, v); } }, icon('clock', 22), h('span', {}, l), (ch.ttl || 0) === v ? icon('check', 20) : null))]);
  }

  async function showMedia() {
    const msgs = (await db.msgAll(chatId)).filter((m) => m.file && !m.deleted).reverse();
    const body = msgs.length ? msgs.map((m) => listRow({
      icon: m.kind === 'image' ? 'image' : m.kind === 'voice' ? 'mic' : m.kind === 'video' ? 'video' : 'file',
      title: m.file.name, sub: `${fmtBytes(m.file.size)} · ${new Date(m.ts).toLocaleDateString()}`,
      onClick: () => { s.close(); jumpTo(m.id); },
    })) : emptyState('folder', 'Nothing shared yet');
    const s = sheet('Media & files', body, { tall: true });
  }

  async function showStarred() {
    const msgs = (await db.msgAll(chatId)).filter((m) => m.starred && !m.deleted).reverse();
    const body = msgs.length ? msgs.map((m) => listRow({ icon: 'star', title: D.preview(m) || '…', sub: `${D.nameOf(m.from)} · ${new Date(m.ts).toLocaleString()}`, onClick: () => { s.close(); jumpTo(m.id); } })) : emptyState('star', 'No starred messages', 'Long-press a message and choose Star.');
    const s = sheet('Starred messages', body, { tall: true });
  }

  function searchChat() {
    const input = h('input', { type: 'search', placeholder: 'Search messages', autocomplete: 'off' });
    const results = h('div', { class: 'results' });
    let all = null;
    input.addEventListener('input', debounce(async () => {
      const q = input.value.trim().toLowerCase();
      clear(results);
      if (q.length < 2) return;
      all = all || (await db.msgAll(chatId));
      const hits = all.filter((m) => !m.deleted && ((m.text || '').toLowerCase().includes(q) || (m.file?.name || '').toLowerCase().includes(q))).reverse().slice(0, 50);
      if (!hits.length) results.appendChild(h('p', { class: 'sheet-note' }, 'No matches'));
      for (const m of hits) results.appendChild(listRow({ title: m.text || m.file?.name, sub: `${D.nameOf(m.from)} · ${new Date(m.ts).toLocaleString()}`, onClick: () => { s.close(); jumpTo(m.id); } }));
    }, 200));
    const s = sheet('Search', [h('div', { class: 'search-box' }, icon('search', 18), input), results], { tall: true });
    setTimeout(() => input.focus(), 80);
  }

  async function openInfo() {
    const mod = await import('./contacts.js');
    if (isGroup()) mod.openGroupInfo(chatId); else mod.openContactInfo(chatId);
  }

  /* ------------------------------- wiring ------------------------------- */
  ctx.el.append(header, banner, h('div', { class: 'chat-body' }, scroller, jump), composer);
  paintHeader(); paintBanner();
  if (ch.draft) { ta.value = ch.draft; }
  autosize();

  ctx.on('msg', onMsgEvent);
  ctx.on('presence', (id) => { if (id === chatId) paintHeader(); });
  ctx.on('typing', (id) => { if (id === chatId) paintHeader(); });
  ctx.on('chats', (id) => { if (!id || id === chatId) { if (!D.getChat(chatId) && ch.type) { /* deleted elsewhere */ } paintHeader(); paintBanner(); } });
  ctx.on('contacts', () => { paintHeader(); paintBanner(); });
  ctx.on('net', () => { paintHeader(); paintBanner(); });
  ctx.on('visible', (v) => { if (v) chatSvc.markRead(chatId); });

  db.msgPage(chatId, null, 50).then((msgs) => {
    hasMore = msgs.length >= 50;
    renderAll(msgs, false);
    chatSvc.markRead(chatId);
    requestAnimationFrame(() => scrollBottom(false));
  });
  const pt = setInterval(() => { if (ctx.el.isConnected) paintHeader(); }, 15000);
  ctx.cleanup.push(() => clearInterval(pt), () => rows.forEach((el) => el._cleanup?.()));
}
