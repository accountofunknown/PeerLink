// First-run profile creation.

import { h, icon, genPeerId, normId, validId, PALETTE } from '../util.js';
import { avatar } from './dom.js';
import { AVATAR_EMOJI } from './settings.js';
import { applyTheme } from '../theme.js';

export function runOnboarding() {
  return new Promise((resolve) => {
    applyTheme();
    const draft = { name: '', emoji: '', color: '', id: genPeerId() };
    const preview = h('div', { class: 'center' });
    const paintPrev = () => preview.replaceChildren(avatar({ id: draft.id, name: draft.name || '?', emoji: draft.emoji, color: draft.color }, 92));
    const name = h('input', { type: 'text', placeholder: 'Your name', maxlength: 40, autocomplete: 'off', oninput: (e) => { draft.name = e.target.value; paintPrev(); } });
    const idIn = h('input', { type: 'text', value: draft.id, maxlength: 48, autocapitalize: 'none', autocomplete: 'off', spellcheck: 'false', oninput: (e) => { draft.id = normId(e.target.value); err.textContent = ''; } });
    const err = h('div', { class: 'field-err' });
    const emojis = h('div', { class: 'emoji-pick' }, AVATAR_EMOJI.map((e) => h('button', { class: draft.emoji === e ? 'on' : '', onclick: (ev) => { draft.emoji = e; [...emojis.children].forEach((c) => c.classList.remove('on')); ev.currentTarget.classList.add('on'); paintPrev(); } }, e || 'Aa')));
    const colors = h('div', { class: 'swatches' }, [''].concat(PALETTE).map((c) => h('button', { class: draft.color === c ? 'on' : '', style: { background: c || 'var(--surface3)' }, 'aria-label': c || 'Automatic', onclick: (ev) => { draft.color = c; [...colors.children].forEach((x) => x.classList.remove('on')); ev.currentTarget.classList.add('on'); paintPrev(); } })));
    paintPrev();
    const root = h('div', { class: 'onboard' },
      h('div', { class: 'ob-hero' }, h('div', { class: 'logo' }, icon('link', 44)), h('h1', {}, 'PeerLink'), h('p', {}, 'Private messages, calls and file transfers — straight from your device to your friend’s. No accounts, no phone numbers, no servers storing your data.')),
      h('div', { class: 'ob-card' },
        preview,
        h('label', { class: 'field-label' }, 'What should people call you?'), name,
        h('label', { class: 'field-label' }, 'Avatar'), emojis, colors,
        h('label', { class: 'field-label' }, 'Your PeerLink ID'),
        h('div', { class: 'id-row' }, idIn, h('button', { class: 'icon-btn', 'aria-label': 'Generate another ID', onclick: () => { draft.id = genPeerId(); idIn.value = draft.id; paintPrev(); } }, icon('refresh', 20))),
        h('div', { class: 'small muted' }, 'This is how friends find you. You can change it later in Settings.'), err,
        h('button', { class: 'btn primary wide big', onclick: () => {
          const n = draft.name.trim();
          if (!n) { err.textContent = 'Please enter your name.'; name.focus(); return; }
          if (!validId(draft.id)) { err.textContent = 'ID must be 4–48 characters: letters, numbers, “-” or “_”.'; return; }
          root.remove();
          resolve({ id: draft.id, name: n, emoji: draft.emoji, color: draft.color, bio: '', created: Date.now() });
        } }, 'Get started')));
    document.body.appendChild(root);
  });
}
