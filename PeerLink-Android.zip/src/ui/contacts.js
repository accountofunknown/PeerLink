// Contacts, invitations (QR / link), contact info and group management screens.

import { h, icon, makeInvite, parseInvite, normId, validId, timeAgo, fmtBytes, fmtTtl } from '../util.js';
import { Share } from '@capacitor/share';
import { S, bus } from '../state.js';
import * as D from '../data.js';
import { net } from '../net.js';
import { chat as chatSvc } from '../chat.js';
import { calls } from '../calls.js';
import * as K from '../crypto.js';
import { isNative } from '../notify.js';
import { nav, appbar, iconBtn, sheet, toast, avatar, peerAvatar, chatAvatar, section, listRow, toggle, confirmDialog, promptDialog, pickContacts, actionSheet } from './dom.js';
import { qrSvg, scanQR } from './media.js';
import { openChat } from './chat.js';

/* ------------------------------ invitations ------------------------------ */
export function handleInvite(text) {
  const inv = parseInvite(text);
  if (!inv) { toast('Not a valid PeerLink invite'); return false; }
  if (inv.id === S.me.id) { toast('That is your own ID'); return false; }
  const c = D.getContact(inv.id);
  if (c && !c.blocked && !c.implicit) { openChat(inv.id); return true; }
  addContactSheet(inv);
  return true;
}

export function addContactSheet(prefill) {
  const idIn = h('input', { type: 'text', placeholder: 'e.g. swift-otter-4821', value: prefill?.id || '', autocapitalize: 'none', autocomplete: 'off', spellcheck: 'false', maxlength: 48 });
  const nameIn = h('input', { type: 'text', placeholder: 'Name (optional)', value: prefill?.name || '', maxlength: 40 });
  const err = h('div', { class: 'field-err' });
  const add = async () => {
    err.textContent = '';
    try {
      const c = await chatSvc.addContact(idIn.value, nameIn.value);
      s.close();
      toast(`${D.nameOf(c.id)} added`);
      openChat(c.id);
    } catch (e) { err.textContent = e.message; }
  };
  const fill = (text) => {
    const inv = parseInvite(text);
    if (!inv) { err.textContent = 'That does not look like a PeerLink ID or invite.'; return false; }
    idIn.value = inv.id; if (inv.name && !nameIn.value) nameIn.value = inv.name; err.textContent = '';
    return true;
  };
  const s = sheet('Add contact', [
    h('label', { class: 'field-label' }, 'PeerLink ID'), idIn,
    h('label', { class: 'field-label' }, 'Name'), nameIn, err,
    h('div', { class: 'btn-row' },
      h('button', { class: 'btn', onclick: async () => { const t = await scanQR(); if (t && fill(t)) add(); } }, icon('qr', 18), ' Scan QR'),
      h('button', { class: 'btn', onclick: async () => { try { fill(await navigator.clipboard.readText()); } catch { toast('Clipboard unavailable'); } } }, icon('copy', 18), ' Paste')),
    h('div', { class: 'sheet-foot' }, h('button', { class: 'btn primary wide', onclick: add }, 'Add contact')),
  ]);
  if (!prefill) setTimeout(() => idIn.focus(), 120);
}

export async function shareText(text, title = 'PeerLink') {
  try {
    if (isNative()) await Share.share({ title, text, dialogTitle: 'Share' });
    else if (navigator.share) await navigator.share({ title, text });
    else { await navigator.clipboard.writeText(text); toast('Copied to clipboard'); }
  } catch { /* cancelled */ }
}

export function showMyQR() {
  const invite = makeInvite(S.me.id, S.me.name);
  const copy = async () => { try { await navigator.clipboard.writeText(S.me.id); toast('ID copied'); } catch { toast('Copy failed'); } };
  sheet('My PeerLink ID', [
    h('div', { class: 'qr-card' }, qrSvg(invite, 232), h('div', { class: 'qr-name' }, S.me.name), h('code', { class: 'qr-id' }, S.me.id),
      h('p', { class: 'sheet-note' }, 'Let a friend scan this code in PeerLink → Contacts → Add contact → Scan QR.')),
    h('div', { class: 'btn-row' }, h('button', { class: 'btn', onclick: copy }, icon('copy', 18), ' Copy ID'), h('button', { class: 'btn primary', onclick: () => shareText(`Add me on PeerLink!\n${invite}\nID: ${S.me.id}`) }, icon('share', 18), ' Share invite')),
  ]);
}

/* ------------------------------ new chat / group ------------------------------ */
export function newChatFlow() {
  if (![...S.contacts.values()].some((c) => !c.blocked && !c.implicit)) { addContactSheet(); return; }
  const s = actionSheet('New', [
    { icon: 'chat', label: 'New chat', onClick: () => pickContacts({ title: 'Start a chat', multi: false, onDone: async ([id]) => { await chatSvc.ensureDm(id); openChat(id); } }) },
    { icon: 'users', label: 'New group', onClick: newGroupFlow },
    { icon: 'user-plus', label: 'Add contact', onClick: () => addContactSheet() },
  ]);
  return s;
}

export function newGroupFlow() {
  pickContacts({ title: 'Choose group members', exclude: [], onDone: async (ids) => {
    const name = await promptDialog({ title: 'Group name', placeholder: 'e.g. Weekend trip', ok: 'Create', maxlength: 60, validate: (v) => (v ? null : 'Enter a name') });
    if (!name) return;
    try { const ch = await chatSvc.createGroup(name, ids); openChat(ch.id); } catch (e) { toast(e.message); }
  } });
}

/* ------------------------------ contact info ------------------------------ */
export function openContactInfo(id) {
  nav.push('contact', (ctx) => {
    const body = h('div', { class: 'scroll pad' });
    ctx.el.append(appbar({ title: 'Contact info', onBack: () => nav.pop(ctx) }), body);
    let statsBox;
    const render = async () => {
      const c = D.getContact(id);
      const ch = D.getChat(id);
      const link = net.link(id);
      const online = net.isOnline(id);
      const fp = c?.fp || link?.info?.fp;
      body.replaceChildren(
        h('div', { class: 'hero-card' }, peerAvatar(id, 84, true), h('h2', {}, D.nameOf(id)), h('code', { class: 'idc', onclick: () => { navigator.clipboard?.writeText(id); toast('ID copied'); } }, id),
          h('div', { class: `pill ${online ? 'ok' : ''}` }, online ? `Online · ${link?.route === 'relay' ? 'relayed' : 'direct P2P'}` : c?.lastSeen ? `Last seen ${timeAgo(c.lastSeen)}` : 'Offline'),
          link?.info?.bio ? h('p', { class: 'bio' }, link.info.bio) : null,
          h('div', { class: 'btn-row center' },
            h('button', { class: 'btn primary', onclick: () => { nav.popAll(); openChat(id); } }, icon('chat', 18), ' Message'),
            h('button', { class: 'btn', onclick: () => calls.start(id, false).catch((e) => toast(e.message)) }, icon('phone', 18), ' Call'),
            h('button', { class: 'btn', onclick: () => calls.start(id, true).catch((e) => toast(e.message)) }, icon('video', 18), ' Video'))),
        !c || c.implicit ? h('div', { class: 'banner warn' }, h('div', {}, h('b', {}, 'Not in your contacts')), h('button', { class: 'btn primary sm', onclick: async () => { try { await chatSvc.acceptRequest(id); if (!D.getContact(id)) await chatSvc.addContact(id); render(); } catch (e) { toast(e.message); } } }, 'Add')) : null,
        c?.keyChanged ? h('div', { class: 'banner danger' }, h('div', {}, h('b', {}, 'Security identity changed'), h('div', { class: 'small' }, 'This contact is using a new key. Compare the safety number in person before trusting it.')), h('button', { class: 'btn sm', onclick: async () => { await chatSvc.trustKey(id); render(); } }, 'Trust new key')) : null,
        section('Contact',
          listRow({ icon: 'edit', title: 'Nickname', sub: c?.alias || 'Not set', onClick: async () => { const v = await promptDialog({ title: 'Nickname', value: c?.alias || '', placeholder: c?.name || id, maxlength: 40 }); if (v !== null && c) { await chatSvc.updateContact(id, { alias: v }); render(); } } }),
          listRow({ icon: 'bell-off', title: 'Mute notifications', right: toggle(!!ch?.muted, async (v) => { await chatSvc.ensureDm(id); chatSvc.setMuted(id, v); }) }),
          listRow({ icon: 'clock', title: 'Disappearing messages', sub: ch?.ttl ? fmtTtl(ch.ttl) : 'Off', onClick: () => ttlSheet(ch, render) })),
        section('Security',
          listRow({ icon: 'key', title: 'Identity fingerprint', sub: fp ? fp.match(/.{1,4}/g).join(' ') : 'Not seen yet — connect once to pin their key' }),
          fp ? listRow({ icon: 'shield', title: 'Verify safety number', sub: c?.verified ? 'Verified' : 'Compare with your contact', right: c?.verified ? icon('check', 20) : null, onClick: () => safetyDialog(id, fp, render) }) : null),
        section('Connection',
          h('div', { class: 'lrow' }, h('div', { class: 'lr-main' }, statsBox = h('div', { class: 'stats' }, online ? 'Measuring…' : 'Not connected')),
            online ? h('button', { class: 'btn sm', onclick: loadStats }, 'Refresh') : h('button', { class: 'btn sm', onclick: async () => { try { await net.connect(id); toast('Connected'); } catch { toast('Contact is offline'); } render(); } }, 'Connect'))),
        section('Privacy',
          listRow({ icon: 'block', title: c?.blocked ? 'Unblock contact' : 'Block contact', danger: !c?.blocked, onClick: async () => { if (c?.blocked || await confirmDialog({ title: `Block ${D.nameOf(id)}?`, text: 'They will not be able to message or call you.', ok: 'Block', danger: true })) { await chatSvc.setBlocked(id, !c?.blocked); render(); } } }),
          c && !c.implicit ? listRow({ icon: 'trash', title: 'Remove contact', danger: true, onClick: async () => { if (await confirmDialog({ title: 'Remove contact?', text: 'The conversation stays until you delete it.', ok: 'Remove', danger: true })) { await chatSvc.removeContact(id); nav.pop(ctx); } } }) : null,
          ch ? listRow({ icon: 'trash', title: 'Delete chat', danger: true, onClick: async () => { if (await confirmDialog({ title: 'Delete chat?', text: 'Messages and files are deleted from this device.', ok: 'Delete', danger: true })) { await chatSvc.deleteChat(id); nav.popAll(); } } }) : null));
      if (online) loadStats();
    };
    async function loadStats() {
      const st = await net.stats(id).catch(() => null);
      if (!statsBox || !statsBox.isConnected) return;
      statsBox.replaceChildren(...(st ? [
        kv('Route', st.route === 'relay' ? 'Relayed through TURN' : 'Direct peer-to-peer'),
        kv('Latency', st.rtt != null ? `${st.rtt} ms` : '–'),
        kv('Candidates', `${st.local || '?'} ↔ ${st.remote || '?'} (${st.proto || '?'})${st.mdnsLocal || st.mdnsRemote ? ' · mDNS' : ''}`),
        kv('Data', `↑ ${fmtBytes(st.sent || 0)}  ↓ ${fmtBytes(st.recv || 0)}`),
      ] : ['No statistics available']));
    }
    ctx.on('presence', (pid) => { if (pid === id) render(); });
    ctx.on('contacts', render);
    render();
  });
}

const kv = (k, v) => h('div', { class: 'kv' }, h('span', {}, k), h('b', {}, v));

function ttlSheet(ch, after) {
  if (!ch) return;
  const opts = [[0, 'Off'], [300, '5 minutes'], [3600, '1 hour'], [86400, '24 hours'], [604800, '7 days']];
  const s = sheet('Disappearing messages', opts.map(([v, l]) => h('button', { class: `row-btn${(ch.ttl || 0) === v ? ' sel' : ''}`, onclick: async () => { s.close(); await chatSvc.setTtl(ch, v); after?.(); } }, icon('clock', 22), h('span', {}, l), (ch.ttl || 0) === v ? icon('check', 20) : null)));
}

async function safetyDialog(id, fp, after) {
  const mine = await K.fingerprint(K.publicJwk());
  const num = await K.safetyNumber(mine, fp);
  const c = D.getContact(id);
  const s = sheet('Safety number', [
    h('p', { class: 'sheet-note' }, `If ${D.nameOf(id)} sees exactly the same number on their device, nobody is impersonating them. Compare it in person or over a call you trust.`),
    h('div', { class: 'safety' }, num.split(' ').map((g) => h('span', {}, g))),
    h('div', { class: 'sheet-foot' }, h('button', { class: 'btn primary wide', onclick: async () => { await chatSvc.updateContact(id, { verified: !c?.verified }); s.close(); after?.(); } }, c?.verified ? 'Mark as not verified' : 'Mark as verified')),
  ]);
}

/* ------------------------------ group info ------------------------------ */
export function openGroupInfo(chatId) {
  nav.push('group', (ctx) => {
    const body = h('div', { class: 'scroll pad' });
    ctx.el.append(appbar({ title: 'Group info', onBack: () => nav.pop(ctx) }), body);
    const render = () => {
      const ch = D.getChat(chatId);
      if (!ch) { nav.pop(ctx); return; }
      const admin = ch.admin === S.me.id;
      body.replaceChildren(
        h('div', { class: 'hero-card' }, chatAvatar(ch, 84), h('h2', {}, ch.title), h('div', { class: 'pill' }, `${ch.members.length} members`),
          admin && !ch.left ? h('button', { class: 'btn sm', onclick: async () => { const v = await promptDialog({ title: 'Group name', value: ch.title, maxlength: 60, validate: (x) => (x ? null : 'Enter a name') }); if (v) { await chatSvc.renameGroup(ch, v); render(); } } }, icon('edit', 16), ' Rename') : null),
        section('Settings',
          listRow({ icon: 'bell-off', title: 'Mute notifications', right: toggle(!!ch.muted, (v) => chatSvc.setMuted(chatId, v)) }),
          listRow({ icon: 'clock', title: 'Disappearing messages', sub: ch.ttl ? fmtTtl(ch.ttl) : 'Off', onClick: () => (admin ? ttlSheet(ch, render) : toast('Only the admin can change this')) })),
        section(`Members (${ch.members.length})`,
          ...ch.members.map((id) => {
            const me = id === S.me.id;
            return h('div', { class: 'lrow' }, me ? avatar({ ...S.me }, 40) : peerAvatar(id, 40, true),
              h('div', { class: 'lr-main' }, h('div', { class: 'lr-t' }, me ? 'You' : D.nameOf(id)), h('div', { class: 'lr-s' }, me ? S.me.id : (D.isContact(id) ? id : `${id} · not a contact`))),
              id === ch.admin ? h('span', { class: 'badge' }, 'admin') : null,
              !me ? h('button', { class: 'icon-btn', onclick: () => memberMenu(ch, id, admin) }, icon('more', 20)) : null);
          }),
          admin && !ch.left ? listRow({ icon: 'user-plus', title: 'Add members', onClick: () => pickContacts({ title: 'Add members', exclude: ch.members, onDone: async (ids) => { try { await chatSvc.addMembers(ch, ids); render(); } catch (e) { toast(e.message); } } }) }) : null),
        section('',
          !ch.left ? listRow({ icon: 'back', title: 'Leave group', danger: true, onClick: async () => { if (await confirmDialog({ title: 'Leave group?', text: 'You will stop receiving messages from this group.', ok: 'Leave', danger: true })) { await chatSvc.leaveGroup(ch); render(); } } }) : null,
          listRow({ icon: 'trash', title: 'Delete group chat', danger: true, onClick: async () => { if (await confirmDialog({ title: 'Delete chat?', text: 'Messages and files are deleted from this device.', ok: 'Delete', danger: true })) { if (!ch.left) await chatSvc.leaveGroup(ch); await chatSvc.deleteChat(chatId); nav.popAll(); } } })));
    };
    ctx.on('chats', render);
    ctx.on('presence', render);
    render();
  });
}

function memberMenu(ch, id, admin) {
  actionSheet(D.nameOf(id), [
    { icon: 'user', label: 'View contact', onClick: () => openContactInfo(id) },
    D.isContact(id) ? { icon: 'chat', label: 'Message', onClick: async () => { await chatSvc.ensureDm(id); nav.popAll(); openChat(id); } } : { icon: 'user-plus', label: 'Add to contacts', onClick: () => addContactSheet({ id, name: D.nameOf(id) === id ? '' : D.nameOf(id) }) },
    admin ? { icon: 'x', label: 'Remove from group', danger: true, onClick: async () => { try { await chatSvc.removeMember(ch, id); } catch (e) { toast(e.message); } } } : null,
  ]);
}
