// Reusable UI primitives: avatar, toast, sheets, dialogs, navigation stack.

import { h, icon, colorFor, initials } from '../util.js';
import { S, bus } from '../state.js';
import * as D from '../data.js';

/* ---------- layers (sheets/dialogs) are closed first by the Android back button ---------- */
const layers = [];
export function closeTopLayer() {
  const l = layers[layers.length - 1];
  if (!l) return false;
  l.close();
  return true;
}
export const hasLayer = () => layers.length > 0;

function mountLayer(el, onClose) {
  const layer = { el, close: () => {} };
  let closed = false;
  layer.close = (val) => {
    if (closed) return;
    closed = true;
    const i = layers.indexOf(layer);
    if (i >= 0) layers.splice(i, 1);
    el.classList.add('closing');
    setTimeout(() => el.remove(), 180);
    onClose?.(val);
  };
  layers.push(layer);
  document.body.appendChild(el);
  return layer;
}

export function avatar(o, size = 44, online = false) {
  const name = o.name || o.id || '?';
  const bg = o.color || colorFor(o.id || name);
  const inner = o.emoji || (o.group ? icon('users', Math.round(size * 0.5)) : initials(name));
  return h('div', { class: 'av-wrap', style: { width: `${size}px`, height: `${size}px` } },
    h('div', { class: 'avatar', style: { width: `${size}px`, height: `${size}px`, background: bg, fontSize: `${Math.round(size * 0.4)}px` } }, inner),
    online ? h('span', { class: 'dot' }) : null);
}
export const peerAvatar = (id, size = 44, withDot = false) => avatar({ ...D.profileOf(id) }, size, withDot && !!S.presence.get(id)?.online);
export function chatAvatar(ch, size = 44) {
  if (ch.type === 'group') return avatar({ id: ch.id, name: ch.title, group: true }, size);
  return peerAvatar(ch.id, size, true);
}

/* ---------- toast ---------- */
export function toast(text, opts = {}) {
  let box = document.getElementById('toasts');
  if (!box) { box = h('div', { id: 'toasts' }); document.body.appendChild(box); }
  const close = () => { t.classList.add('out'); setTimeout(() => t.remove(), 200); };
  const t = h('div', { class: 'toast', onclick: () => { opts.onAction?.(); close(); } }, h('span', {}, text), opts.action ? h('b', {}, opts.action) : null);
  box.appendChild(t);
  while (box.children.length > 3) box.firstChild.remove();
  setTimeout(close, opts.ms || 3200);
}
bus.on('toast', (t) => toast(t));

/* ---------- bottom sheet ---------- */
export function sheet(title, content, { onClose, tall } = {}) {
  const panel = h('div', { class: `sheet${tall ? ' tall' : ''}` }, title ? h('div', { class: 'sheet-title' }, title) : null, h('div', { class: 'sheet-body' }, content));
  const back = h('div', { class: 'backdrop', onclick: (e) => { if (e.target === back) layer.close(); } }, panel);
  const layer = mountLayer(back, onClose);
  return { close: layer.close, el: panel };
}

export function actionSheet(title, items) {
  const s = sheet(title, items.filter(Boolean).map((it) => h('button', {
    class: `row-btn${it.danger ? ' danger' : ''}`,
    onclick: () => { s.close(); setTimeout(() => it.onClick?.(), 30); },
  }, it.icon ? icon(it.icon, 22) : null, h('span', {}, it.label), it.hint ? h('small', {}, it.hint) : null)));
  return s;
}

/* ---------- dialogs ---------- */
function dialogShell(children, onClose) {
  const box = h('div', { class: 'dialog' }, children);
  const back = h('div', { class: 'backdrop center', onclick: (e) => { if (e.target === back) layer.close(); } }, box);
  const layer = mountLayer(back, onClose);
  return layer;
}

export function confirmDialog({ title, text, ok = 'OK', cancel = 'Cancel', danger = false }) {
  return new Promise((resolve) => {
    let result = false;
    const layer = dialogShell([
      h('h3', {}, title), text ? h('p', {}, text) : null,
      h('div', { class: 'dialog-actions' },
        h('button', { class: 'btn text', onclick: () => layer.close() }, cancel),
        h('button', { class: `btn ${danger ? 'danger' : 'primary'}`, onclick: () => { result = true; layer.close(); } }, ok)),
    ], () => resolve(result));
  });
}

export function promptDialog({ title, label, value = '', placeholder = '', ok = 'Save', validate, multiline = false, maxlength = 120 }) {
  return new Promise((resolve) => {
    let result = null;
    const input = multiline
      ? h('textarea', { rows: 3, maxlength, placeholder, value })
      : h('input', { type: 'text', maxlength, placeholder, value, autocapitalize: 'none', autocomplete: 'off', spellcheck: 'false' });
    const err = h('div', { class: 'field-err' });
    const submit = () => {
      const v = input.value.trim();
      const msg = validate ? validate(v) : null;
      if (msg) { err.textContent = msg; return; }
      result = v; layer.close();
    };
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !multiline) { e.preventDefault(); submit(); } });
    const layer = dialogShell([
      h('h3', {}, title), label ? h('label', { class: 'field-label' }, label) : null, input, err,
      h('div', { class: 'dialog-actions' },
        h('button', { class: 'btn text', onclick: () => layer.close() }, 'Cancel'),
        h('button', { class: 'btn primary', onclick: submit }, ok)),
    ], () => resolve(result));
    setTimeout(() => { input.focus(); input.select?.(); }, 60);
  });
}

export function infoDialog(title, body) {
  return new Promise((resolve) => {
    const layer = dialogShell([
      h('h3', {}, title), h('div', { class: 'dialog-body' }, body),
      h('div', { class: 'dialog-actions' }, h('button', { class: 'btn primary', onclick: () => layer.close() }, 'Close')),
    ], () => resolve());
  });
}

/* ---------- navigation stack ---------- */
const pagesEl = () => document.getElementById('pages');
export const nav = {
  stack: [],
  push(name, build) {
    const el = h('div', { class: 'page', dataset: { page: name } });
    const ctx = { name, el, offs: [], cleanup: [], on(ev, fn) { ctx.offs.push(bus.on(ev, fn)); }, pop: () => nav.pop(ctx) };
    pagesEl().appendChild(el);
    this.stack.push(ctx);
    build(ctx);
    return ctx;
  },
  pop(ctx) {
    const top = ctx || this.stack[this.stack.length - 1];
    if (!top) return false;
    const i = this.stack.indexOf(top);
    if (i < 0) return false;
    this.stack.splice(i, 1);
    top.offs.forEach((f) => f());
    top.cleanup.forEach((f) => { try { f(); } catch { /* */ } });
    top.el.classList.add('leaving');
    setTimeout(() => top.el.remove(), 200);
    return true;
  },
  popAll() { while (this.stack.length) this.pop(); },
  get depth() { return this.stack.length; },
};

export function appbar({ title, sub, onBack, actions = [], leading }) {
  return h('header', { class: 'appbar' },
    onBack ? h('button', { class: 'icon-btn', 'aria-label': 'Back', onclick: onBack }, icon('back')) : null,
    leading || null,
    h('div', { class: 'ab-title' }, h('div', { class: 't' }, title), sub ? h('div', { class: 's' }, sub) : null),
    h('div', { class: 'ab-actions' }, actions));
}

export const iconBtn = (name, label, onclick, extra = '') => h('button', { class: `icon-btn ${extra}`, 'aria-label': label, onclick }, icon(name));

export function section(title, ...rows) { return h('section', { class: 'sect' }, title ? h('h4', {}, title) : null, h('div', { class: 'card' }, rows)); }

export function listRow({ icon: ic, title, sub, right, onClick, danger, leading }) {
  return h(onClick ? 'button' : 'div', { class: `lrow${danger ? ' danger' : ''}`, onclick: onClick },
    leading || (ic ? h('span', { class: 'lr-ic' }, icon(ic, 20)) : null),
    h('div', { class: 'lr-main' }, h('div', { class: 'lr-t' }, title), sub ? h('div', { class: 'lr-s' }, sub) : null),
    right || null);
}

export function toggle(value, onChange) {
  const el = h('button', { class: `switch${value ? ' on' : ''}`, role: 'switch', 'aria-checked': String(!!value) }, h('i'));
  el.addEventListener('click', (e) => {
    e.stopPropagation();
    const v = !el.classList.contains('on');
    el.classList.toggle('on', v);
    el.setAttribute('aria-checked', String(v));
    onChange(v);
  });
  return el;
}

export function segmented(options, value, onChange) {
  const el = h('div', { class: 'seg' });
  const paint = (v) => [...el.children].forEach((b) => b.classList.toggle('on', b.dataset.v === String(v)));
  for (const [v, label] of options) el.appendChild(h('button', { dataset: { v: String(v) }, onclick: () => { paint(v); onChange(v); } }, label));
  paint(value);
  return el;
}

export function emptyState(ic, title, text, action) {
  return h('div', { class: 'empty' }, h('div', { class: 'empty-ic' }, icon(ic, 40)), h('h3', {}, title), text ? h('p', {}, text) : null, action || null);
}

export function pickContacts({ title, multi = true, exclude = [], onDone, includeGroups = false }) {
  const sel = new Set();
  const list = h('div', { class: 'pick-list' });
  const items = [];
  for (const c of S.contacts.values()) if (!c.blocked && !c.implicit && !exclude.includes(c.id)) items.push({ id: c.id, label: D.nameOf(c.id), sub: c.id, av: () => peerAvatar(c.id, 40) });
  if (includeGroups) for (const ch of S.chats.values()) if (ch.type === 'group' && !ch.left) items.push({ id: ch.id, label: ch.title, sub: 'Group', av: () => chatAvatar(ch, 40) });
  items.sort((a, b) => a.label.localeCompare(b.label));
  const doneBtn = h('button', { class: 'btn primary', disabled: true, onclick: () => { s.close(); onDone([...sel]); } }, 'Done');
  for (const it of items) {
    const row = h('button', { class: 'pick-row', onclick: () => {
      if (!multi) { s.close(); onDone([it.id]); return; }
      if (sel.has(it.id)) sel.delete(it.id); else sel.add(it.id);
      row.classList.toggle('on', sel.has(it.id));
      doneBtn.disabled = !sel.size;
      doneBtn.textContent = sel.size ? `Done (${sel.size})` : 'Done';
    } }, it.av(), h('div', { class: 'lr-main' }, h('div', { class: 'lr-t' }, it.label), h('div', { class: 'lr-s' }, it.sub)), multi ? h('span', { class: 'chk' }, icon('check', 16)) : null);
    list.appendChild(row);
  }
  if (!items.length) list.appendChild(emptyState('users', 'No contacts yet', 'Add a contact first.'));
  const s = sheet(title, [list, multi ? h('div', { class: 'sheet-foot' }, doneBtn) : null], { tall: true });
  return s;
}
