// Full-screen call UI (incoming ring, outgoing, in-call controls).

import { h, icon, fmtDur } from '../util.js';
import { bus } from '../state.js';
import * as D from '../data.js';
import { calls } from '../calls.js';
import { peerAvatar } from './dom.js';

let el = null, tickTimer = null, hideTimer = null;

const STATE_TEXT = { calling: 'Calling…', ringing: 'Incoming call', connecting: 'Connecting…', active: '' };

function ctl(ic, label, onclick, cls = '') {
  return h('button', { class: `cbtn ${cls}`, 'aria-label': label, onclick }, icon(ic, 26), h('span', {}, label));
}

function render(ended) {
  const c = calls.cur;
  if (!c && !ended) { teardown(); return; }
  clearTimeout(hideTimer);
  const info = c || ended;
  const peer = c ? c.peer : null;
  if (!el) {
    el = h('div', { class: 'call-screen' });
    document.body.appendChild(el);
    tickTimer = setInterval(() => { const t = el?.querySelector('.call-time'); const cc = calls.cur; if (t && cc?.started) t.textContent = fmtDur((Date.now() - cc.started) / 1000); }, 500);
  }
  if (!c) { // ended
    el.replaceChildren(h('div', { class: 'call-end' }, icon('phone', 40), h('h2', {}, ended.result === 'ended' ? 'Call ended' : ended.result === 'declined' ? 'Call declined' : ended.result === 'missed' ? 'No answer' : 'Call failed'), ended.dur ? h('p', {}, fmtDur(ended.dur)) : null));
    hideTimer = setTimeout(teardown, 1100);
    return;
  }
  const remoteVideo = h('video', { class: 'remote', autoplay: true, playsinline: true });
  const localVideo = h('video', { class: `local${c.camOff ? ' off' : ''}`, autoplay: true, playsinline: true, muted: true });
  localVideo.muted = true;
  const hasRemoteVideo = !!c.remote?.getVideoTracks().length;
  const hasLocalVideo = !!c.local?.getVideoTracks().length;
  if (c.remote) remoteVideo.srcObject = c.remote;
  if (c.local) localVideo.srcObject = c.local;
  const name = D.nameOf(c.peer);
  const status = c.weak ? 'Reconnecting…' : c.state === 'active' ? null : STATE_TEXT[c.state];
  const center = h('div', { class: `call-center${hasRemoteVideo ? ' over' : ''}` }, hasRemoteVideo ? null : peerAvatar(peer, 112), h('h2', {}, name), status ? h('p', { class: 'call-status' }, status) : null, c.state === 'active' ? h('p', { class: 'call-time' }, fmtDur((Date.now() - c.started) / 1000)) : null);
  let controls;
  if (c.state === 'ringing') {
    controls = h('div', { class: 'call-controls incoming' },
      ctl('phone', 'Decline', () => calls.decline(), 'red hang'),
      c.video ? ctl('mic', 'Audio only', () => calls.accept(true), 'soft') : null,
      ctl(c.video ? 'video' : 'phone', 'Accept', () => calls.accept(false), 'green'));
  } else {
    controls = h('div', { class: 'call-controls' },
      ctl(c.muted ? 'mic-off' : 'mic', c.muted ? 'Unmute' : 'Mute', () => calls.toggleMute(), c.muted ? 'on' : ''),
      hasLocalVideo ? ctl(c.camOff ? 'video-off' : 'video', c.camOff ? 'Camera on' : 'Camera off', () => calls.toggleCamera(), c.camOff ? 'on' : '') : null,
      hasLocalVideo ? ctl('refresh', 'Flip', () => calls.flipCamera()) : null,
      ctl('phone', 'End', () => calls.hangup(), 'red hang'));
  }
  el.replaceChildren(hasRemoteVideo ? remoteVideo : h('div', { class: 'call-bg' }), center, hasLocalVideo && c.state !== 'ringing' ? localVideo : null, controls);
  remoteVideo.play?.().catch(() => {});
  localVideo.play?.().catch(() => {});
}

function teardown() {
  clearInterval(tickTimer); clearTimeout(hideTimer);
  el?.remove(); el = null;
}

export function initCallUI() {
  bus.on('call', (ended) => render(ended && ended.ended ? ended.ended : null));
  bus.on('open-call', () => { if (calls.cur) render(null); });
}
