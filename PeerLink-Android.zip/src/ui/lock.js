// PIN entry (set / verify) and the app-lock screen.

import { h, icon } from '../util.js';
import { S, bus } from '../state.js';
import { checkPin } from '../crypto.js';
import { sheet } from './dom.js';

function pad({ title, sub, onSubmit }) {
  let pin = '';
  const dots = h('div', { class: 'pin-dots' }, [0, 1, 2, 3, 4, 5].map(() => h('i')));
  const msg = h('div', { class: 'pin-msg' }, sub || '');
  const paint = () => [...dots.children].forEach((d, i) => d.classList.toggle('on', i < pin.length));
  const key = (k) => h('button', { class: 'pin-key', 'aria-label': String(k), onclick: () => { if (pin.length < 6) { pin += k; paint(); } } }, k);
  const ok = h('button', { class: 'pin-key act', 'aria-label': 'Confirm', onclick: async () => { if (pin.length < 4) { msg.textContent = 'Use at least 4 digits'; return; } const p = pin; const res = await onSubmit(p); if (res === false) { api.shake(); } } }, icon('check', 24));
  const back = h('button', { class: 'pin-key act', 'aria-label': 'Delete', onclick: () => { pin = pin.slice(0, -1); paint(); } }, icon('back', 22));
  const api = {
    el: h('div', { class: 'pin' }, h('h3', {}, title), msg, dots, h('div', { class: 'pin-grid' }, [1, 2, 3, 4, 5, 6, 7, 8, 9].map(key), back, key(0), ok)),
    shake() { pin = ''; paint(); dots.classList.remove('shake'); void dots.offsetWidth; dots.classList.add('shake'); msg.textContent = 'Incorrect PIN'; },
    reset(text) { pin = ''; paint(); msg.textContent = text || ''; },
    setTitle(t) { api.el.querySelector('h3').textContent = t; },
  };
  return api;
}

/** Resolves with the PIN (set mode), true-ish PIN (verify mode) or null if dismissed. */
export function askPin({ title, confirm = false, verify = null }) {
  return new Promise((resolve) => {
    let first = null, result = null;
    const p = pad({
      title,
      onSubmit: async (pin) => {
        if (verify) { if (!(await checkPin(pin, verify))) return false; result = pin; s.close(); return true; }
        if (confirm) {
          if (first == null) { first = pin; p.reset('Enter it again to confirm'); p.setTitle('Confirm PIN'); return true; }
          if (first !== pin) { first = null; p.reset('PINs did not match — start again'); p.setTitle(title); return true; }
        }
        result = pin; s.close(); return true;
      },
    });
    const s = sheet(null, p.el, { onClose: () => resolve(result) });
  });
}

let lockEl = null;
export function showLock() {
  if (lockEl) return Promise.resolve();
  return new Promise((resolve) => {
    S.locked = true;
    const p = pad({
      title: 'PeerLink is locked', sub: 'Enter your PIN',
      onSubmit: async (pin) => {
        if (!(await checkPin(pin, S.settings.pin))) return false;
        lockEl.remove(); lockEl = null; S.locked = false;
        bus.emit('unlocked');
        resolve();
        return true;
      },
    });
    lockEl = h('div', { class: 'lock-screen' }, h('div', { class: 'lock-logo' }, icon('lock', 34)), p.el);
    document.body.appendChild(lockEl);
  });
}
export const isLockShown = () => !!lockEl;
