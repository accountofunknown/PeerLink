// Identity keys (ECDSA P-256) used to authenticate peers, plus PIN hashing.
// PeerJS IDs are first-come-first-served on the signaling server, so every
// connection runs a signed challenge-response and contacts pin each other's key
// on first use (TOFU). A mismatch is surfaced in the UI as "identity changed".

import * as db from './db.js';
import { b64, unb64, randomB64 } from './util.js';

const ALG = { name: 'ECDSA', namedCurve: 'P-256' };
const SIG = { name: 'ECDSA', hash: 'SHA-256' };
const enc = new TextEncoder();

let keys = null;

export async function ensureKeys() {
  let rec = await db.get('kv', 'keys');
  if (!rec) {
    const kp = await crypto.subtle.generateKey(ALG, false, ['sign', 'verify']);
    const jwk = await crypto.subtle.exportKey('jwk', kp.publicKey);
    rec = { priv: kp.privateKey, pub: { kty: jwk.kty, crv: jwk.crv, x: jwk.x, y: jwk.y } };
    await db.put('kv', rec, 'keys');
  }
  keys = rec;
  return rec.pub;
}

export const publicJwk = () => keys.pub;

export async function sign(text) {
  const sig = await crypto.subtle.sign(SIG, keys.priv, enc.encode(text));
  return b64(new Uint8Array(sig));
}

export async function verify(jwk, text, sigB64) {
  try {
    if (!jwk || jwk.kty !== 'EC' || jwk.crv !== 'P-256' || !jwk.x || !jwk.y) return false;
    const pub = await crypto.subtle.importKey('jwk', { kty: 'EC', crv: 'P-256', x: jwk.x, y: jwk.y, ext: true }, ALG, false, ['verify']);
    return await crypto.subtle.verify(SIG, pub, unb64(sigB64), enc.encode(text));
  } catch { return false; }
}

const hex = (buf) => [...new Uint8Array(buf)].map((n) => n.toString(16).padStart(2, '0')).join('');

export async function fingerprint(jwk) {
  const d = await crypto.subtle.digest('SHA-256', enc.encode(`${jwk.x}.${jwk.y}`));
  return hex(d).slice(0, 40);
}

/** Same on both devices for a given pair; compare it out-of-band to verify. */
export async function safetyNumber(fpA, fpB) {
  const [a, b] = [fpA, fpB].sort();
  const d = new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(`${a}|${b}`)));
  const groups = [];
  for (let i = 0; i < 24; i += 4) {
    const n = ((d[i] << 24) | (d[i + 1] << 16) | (d[i + 2] << 8) | d[i + 3]) >>> 0;
    groups.push(String(n % 100000).padStart(5, '0'));
  }
  return groups.join(' ');
}

/* ---------- PIN ---------- */
async function pbkdf(pin, saltB64) {
  const base = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: unb64(saltB64), iterations: 150000 }, base, 256);
  return b64(new Uint8Array(bits));
}
export async function makePin(pin) {
  const salt = randomB64(16);
  return { salt, hash: await pbkdf(pin, salt) };
}
export async function checkPin(pin, rec) {
  if (!rec) return true;
  return (await pbkdf(pin, rec.salt)) === rec.hash;
}
