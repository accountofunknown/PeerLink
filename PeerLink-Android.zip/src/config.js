export const APP = { name: 'PeerLink', version: '1.0.3', scheme: 'peerlink' };
