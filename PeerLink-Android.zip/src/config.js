export const APP = { name: 'PeerLink', version: '1.0.2', scheme: 'peerlink' };
