export const APP = { name: 'PeerLink', version: '1.1.0', scheme: 'peerlink' };
