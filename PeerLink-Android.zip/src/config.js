export const APP = { name: 'PeerLink', version: '1.0.1', scheme: 'peerlink' };
