export const APP = { name: 'PeerLink', version: '1.0.4', scheme: 'peerlink' };
