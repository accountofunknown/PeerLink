// Voice / video calls on top of PeerJS MediaConnections.

import { net } from './net.js';
import { S, bus } from './state.js';
import * as D from './data.js';
import { chat } from './chat.js';
import { now } from './util.js';
import { startRing, stopRing, startRingback, beep, haptic, showNotification, clearNotification } from './notify.js';

const RING_TIMEOUT = 45000;

class Calls {
  constructor() { this.cur = null; }

  init() {
    net.on('call', (c) => this.onIncoming(c));
    net.on('unavailable', (id) => { if (this.cur?.peer === id && this.cur.state === 'calling') this.end('unavailable'); });
  }

  get busy() { return !!this.cur; }

  media(video, facing = 'user') {
    return navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      video: video ? { facingMode: facing, width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30 } } : false,
    });
  }

  async start(peerId, video) {
    if (this.cur) throw new Error('You are already in a call.');
    if (!net.online) throw new Error('You are offline.');
    if (!navigator.mediaDevices?.getUserMedia) throw new Error('Calls are not supported on this device.');
    let stream;
    try { stream = await this.media(video); } catch { throw new Error(video ? 'Camera or microphone permission was denied.' : 'Microphone permission was denied.'); }
    const call = net.peer.call(peerId, stream, { metadata: { video: !!video, name: S.me.name, v: 1 } });
    if (!call) { stream.getTracks().forEach((t) => t.stop()); throw new Error('Could not start the call.'); }
    const c = (this.cur = { call, peer: peerId, dir: 'out', video: !!video, state: 'calling', local: stream, remote: null, muted: false, camOff: false, facing: 'user', started: 0, t0: now(), weak: false });
    this._bind(c);
    startRingback();
    c.timer = setTimeout(() => { if (this.cur === c && c.state === 'calling') this.end('missed'); }, RING_TIMEOUT);
    bus.emit('call');
  }

  onIncoming(call) {
    const from = call.peer;
    const refuse = (why, log) => {
      net.log('W', 'call refused', from, why);
      try { call.close(); } catch { /* */ }
      if (log && D.isContact(from)) chat.logCall(from, { dir: 'in', video: !!call.metadata?.video, result: 'missed' });
    };
    if (D.isBlocked(from)) return refuse('blocked');
    if (this.cur) return refuse('busy', true);
    if (!D.isContact(from) && !S.settings.callsFromUnknown) return refuse('unknown caller');
    const c = (this.cur = { call, peer: from, dir: 'in', video: !!call.metadata?.video, state: 'ringing', local: null, remote: null, muted: false, camOff: false, facing: 'user', started: 0, t0: now(), weak: false });
    this._bind(c);
    startRing();
    haptic('heavy');
    showNotification({ key: 'call', title: `${D.nameOf(from)} is calling`, body: c.video ? 'Incoming video call' : 'Incoming voice call', chatId: from, channel: 'calls', call: true });
    c.timer = setTimeout(() => { if (this.cur === c && c.state === 'ringing') this.end('missed'); }, RING_TIMEOUT);
    bus.emit('call');
  }

  async accept(audioOnly = false) {
    const c = this.cur;
    if (!c || c.state !== 'ringing') return;
    stopRing();
    clearNotification('call');
    c.state = 'connecting';
    bus.emit('call');
    let stream;
    try { stream = await this.media(c.video && !audioOnly); }
    catch { bus.emit('toast', 'Permission denied — cannot answer the call.'); this.end('failed'); return; }
    if (this.cur !== c) { stream.getTracks().forEach((t) => t.stop()); return; }
    c.local = stream;
    c.localVideo = stream.getVideoTracks().length > 0;
    c.call.answer(stream);
    bus.emit('call');
  }

  decline() { this.end('declined'); }
  hangup() { this.end('ended'); }

  _bind(c) {
    const { call } = c;
    call.on('stream', (rs) => {
      if (this.cur !== c) return;
      c.remote = rs;
      if (c.state !== 'active') {
        c.state = 'active'; c.started = now(); c.weak = false;
        clearTimeout(c.timer); stopRing(); beep('ok');
      }
      bus.emit('call');
    });
    call.on('close', () => { if (this.cur === c) this.end(c.started ? 'ended' : c.dir === 'in' ? 'missed' : 'declined'); });
    call.on('error', (e) => { net.log('E', 'call error', e?.message || e); if (this.cur === c) this.end('failed'); });
    call.on('iceStateChanged', (s) => {
      if (this.cur !== c) return;
      if (s === 'disconnected') { c.weak = true; bus.emit('call'); setTimeout(() => { if (this.cur === c && c.weak) this.end('failed'); }, 12000); }
      else if (s === 'failed') this.end('failed');
      else if (s === 'connected' || s === 'completed') { c.weak = false; bus.emit('call'); }
    });
  }

  end(result) {
    const c = this.cur;
    if (!c) return;
    this.cur = null;
    clearTimeout(c.timer);
    stopRing();
    clearNotification('call');
    try { c.call.close(); } catch { /* */ }
    c.local?.getTracks().forEach((t) => t.stop());
    const dur = c.started ? Math.round((now() - c.started) / 1000) : 0;
    let final = result;
    if (c.started) final = 'ended';
    else if (result === 'unavailable') final = 'failed';
    else if (c.dir === 'out' && result === 'declined') final = 'declined';
    chat.logCall(c.peer, { dir: c.dir, video: c.video, dur, result: final });
    beep('end');
    c.ended = { result: final, dur };
    bus.emit('call', c);
  }

  toggleMute() {
    const c = this.cur;
    if (!c?.local) return;
    c.muted = !c.muted;
    c.local.getAudioTracks().forEach((t) => (t.enabled = !c.muted));
    bus.emit('call');
  }

  toggleCamera() {
    const c = this.cur;
    if (!c?.local?.getVideoTracks().length) return;
    c.camOff = !c.camOff;
    c.local.getVideoTracks().forEach((t) => (t.enabled = !c.camOff));
    bus.emit('call');
  }

  async flipCamera() {
    const c = this.cur;
    if (!c?.local?.getVideoTracks().length) return;
    const facing = c.facing === 'user' ? 'environment' : 'user';
    try {
      const ns = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: facing } } });
      const nt = ns.getVideoTracks()[0];
      const sender = c.call.peerConnection?.getSenders().find((s) => s.track?.kind === 'video');
      if (sender) await sender.replaceTrack(nt);
      const old = c.local.getVideoTracks()[0];
      old?.stop();
      if (old) c.local.removeTrack(old);
      c.local.addTrack(nt);
      nt.enabled = !c.camOff;
      c.facing = facing;
      bus.emit('call');
    } catch (e) { bus.emit('toast', 'Could not switch camera.'); }
  }
}

export const calls = new Calls();
