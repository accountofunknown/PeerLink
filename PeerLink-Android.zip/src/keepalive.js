// Bridge to the native foreground service (Android). Everything is best-effort: on web or when the
// native part is missing these calls fail quietly and PeerLink works as before (foreground only).

import { registerPlugin } from '@capacitor/core';
import { S } from './state.js';
import { isNative } from './notify.js';
import { net } from './net.js';

const KeepAlive = registerPlugin('KeepAlive');

export async function syncKeepAlive() {
  if (!isNative()) return false;
  try {
    if (S.settings.keepAlive) await KeepAlive.start({ title: 'PeerLink', text: 'Connected and ready for messages' });
    else await KeepAlive.stop();
    return true;
  } catch (e) {
    net.log('W', 'keep-alive unavailable:', e?.message || e);
    return false;
  }
}

export async function keepAliveStatus() {
  if (!isNative()) return null;
  try { return await KeepAlive.status(); } catch { return null; }
}

export async function openBatterySettings() {
  try { await KeepAlive.openBatterySettings(); } catch (e) { net.log('W', 'battery settings:', e?.message || e); }
}
