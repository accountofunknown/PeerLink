// Local notifications, haptics, short sounds and the ring tone.

import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Haptics, ImpactStyle, NotificationType } from '@capacitor/haptics';
import { S, bus } from './state.js';

export const isNative = () => { try { return Capacitor.isNativePlatform(); } catch { return false; } };

let ctx = null;
export function unlockAudio() {
  try {
    ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
  } catch { /* no audio */ }
}

function tone(freq, start, dur, vol = 0.12, type = 'sine') {
  if (!ctx || ctx.state !== 'running') return;
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = type; o.frequency.value = freq;
  g.gain.setValueAtTime(0, ctx.currentTime + start);
  g.gain.linearRampToValueAtTime(vol, ctx.currentTime + start + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + dur);
  o.connect(g); g.connect(ctx.destination);
  o.start(ctx.currentTime + start); o.stop(ctx.currentTime + start + dur + 0.05);
}

export function beep(kind) {
  if (!S.settings.sound) return;
  if (kind === 'in') { tone(880, 0, 0.12); tone(1175, 0.1, 0.16); }
  else if (kind === 'out') { tone(660, 0, 0.08, 0.07); }
  else if (kind === 'end') { tone(520, 0, 0.14); tone(390, 0.14, 0.22); }
  else if (kind === 'ok') { tone(784, 0, 0.1); tone(1046, 0.1, 0.18); }
}

let ringTimer = null;
export function startRing() {
  stopRing();
  const ring = () => { tone(740, 0, 0.35, 0.15); tone(988, 0.4, 0.35, 0.15); buzz([500]); };
  ring();
  ringTimer = setInterval(ring, 2200);
}
export function stopRing() { clearInterval(ringTimer); ringTimer = null; }
export function startRingback() {
  stopRing();
  const rb = () => { tone(440, 0, 0.9, 0.06); };
  rb();
  ringTimer = setInterval(rb, 3000);
}

export async function haptic(kind = 'light') {
  if (!S.settings.haptics) return;
  try {
    if (isNative()) {
      if (kind === 'success') await Haptics.notification({ type: NotificationType.Success });
      else await Haptics.impact({ style: kind === 'heavy' ? ImpactStyle.Heavy : kind === 'medium' ? ImpactStyle.Medium : ImpactStyle.Light });
    } else navigator.vibrate?.(kind === 'heavy' ? 30 : 10);
  } catch { /* ignore */ }
}
export function buzz(pattern) {
  if (!S.settings.haptics) return;
  try { navigator.vibrate?.(pattern); } catch { /* ignore */ }
}

/* ---------- notifications ---------- */
let permOk = false;
export async function initNotify() {
  try {
    const p = await LocalNotifications.checkPermissions();
    permOk = p.display === 'granted';
    if (isNative()) {
      await LocalNotifications.createChannel({ id: 'messages', name: 'Messages', importance: 4, visibility: 0, vibration: true });
      await LocalNotifications.createChannel({ id: 'calls', name: 'Calls', importance: 5, visibility: 0, vibration: true });
      await LocalNotifications.createChannel({ id: 'transfers', name: 'File transfers', importance: 3, visibility: 0 });
    }
    LocalNotifications.addListener('localNotificationActionPerformed', (ev) => {
      const x = ev.notification?.extra || {};
      if (x.chatId) bus.emit('open-chat', x.chatId);
      if (x.call) bus.emit('open-call');
    });
  } catch (e) { console.warn('notify init', e); }
}
export async function askNotifyPermission() {
  try {
    const p = await LocalNotifications.requestPermissions();
    permOk = p.display === 'granted';
  } catch { permOk = false; }
  return permOk;
}
export const notifyGranted = () => permOk;

const hash = (s) => { let h = 7; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) | 0; return Math.abs(h) % 2147483000 + 1; };

export async function showNotification({ key, title, body, chatId, channel = 'messages', call = false }) {
  if (!S.settings.notify) return;
  if (!permOk) return;
  try {
    await LocalNotifications.schedule({
      notifications: [{ id: hash(key), title, body, channelId: channel, extra: { chatId, call } }],
    });
  } catch (e) { console.warn('notify', e); }
}
export async function clearNotification(key) {
  try { await LocalNotifications.cancel({ notifications: [{ id: hash(key) }] }); } catch { /* ignore */ }
}
