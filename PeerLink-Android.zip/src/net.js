// Networking layer on top of PeerJS.
//
//  * owns the Peer (signaling connection) and recovers it with back-off
//  * wraps DataConnections in "links" that complete a signed handshake
//  * de-duplicates simultaneous connections, pings, measures RTT / route
//  * exposes send / trySend / drain (back-pressure) to the rest of the app

import { Peer } from 'peerjs';
import { Emitter, sleep, now, randomB64, parseIce } from './util.js';
import { S } from './state.js';
import * as K from './crypto.js';

export const PEERJS_DEFAULT_ICE = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: ['turn:eu-0.turn.peerjs.com:3478', 'turn:us-0.turn.peerjs.com:3478'], username: 'peerjs', credential: 'peerjsp' },
];

const PROTO = 1;
const HS_TIMEOUT = 15000;
const CONNECT_TIMEOUT = 20000;
const PING_EVERY = 10000;
const DEAD_AFTER = 28000;

class Link {
  constructor(id) {
    this.id = id;
    this.conns = new Set();
    this.info = null;      // { name, emoji, color, bio, pk, fp, caps }
    this.ok = false;
    this.since = 0;
    this.lastRx = 0;
    this.rtt = null;
    this.route = null;     // 'direct' | 'relay'
  }
  /** Canonical connection: the one initiated by the lexicographically smaller id. */
  best(myId) {
    const open = [...this.conns].filter((c) => c._pl?.ok && c.open);
    if (!open.length) return null;
    const canonicalOutgoing = myId < this.id;
    return open.find((c) => c._pl.outgoing === canonicalOutgoing) || open[0];
  }
}

class Net extends Emitter {
  constructor() {
    super();
    this.peer = null;
    this.state = 'idle'; // idle | connecting | online | reconnecting | offline | conflict | error
    this.error = null;
    this.links = new Map();
    this.waiting = new Map();
    this.hs = new Set();
    this.logs = [];
    this.myId = null;
    this._backoff = 0;
    this._recoverTimer = null;
    this._idRetries = 0;
    this._gen = 0;
    this._timers = [];
  }

  log(level, ...args) {
    const line = `${new Date().toISOString().slice(11, 23)} ${level} ${args.map((a) => (a instanceof Error ? a.message : typeof a === 'object' ? safeJson(a) : String(a))).join(' ')}`;
    this.logs.push(line);
    if (this.logs.length > 300) this.logs.shift();
    this.emit('log', line);
  }

  _setState(s, err = null) {
    if (this.state === s && !err) return;
    this.state = s;
    this.error = err;
    S.netState = s;
    this.log('I', 'state ->', s, err ? `(${err.type || err.message})` : '');
    this.emit('state', s, err);
  }

  /* ----------------------------- lifecycle ----------------------------- */

  async start() {
    this.stop(true);
    this.myId = S.me.id;
    this._gen++;
    this._setState('connecting');
    if (!navigator.onLine) { this._setState('offline'); this._scheduleRecover(); }
    else this._create();
    this._timers.push(setInterval(() => this._tick(), PING_EVERY));
    this._onlineH = () => { this.log('I', 'network online'); this.recover(true); };
    this._offlineH = () => { this.log('W', 'network offline'); this._setState('offline'); };
    window.addEventListener('online', this._onlineH);
    window.addEventListener('offline', this._offlineH);
  }

  stop(keepListeners) {
    clearTimeout(this._recoverTimer);
    this._timers.forEach(clearInterval);
    this._timers = [];
    if (this._onlineH) { window.removeEventListener('online', this._onlineH); window.removeEventListener('offline', this._offlineH); this._onlineH = null; }
    for (const l of this.links.values()) for (const c of [...l.conns]) { try { c.close(); } catch { /* */ } }
    this.links.clear();
    this.hs.clear();
    for (const id of [...this.waiting.keys()]) this._fail(id, new Error('stopped'));
    if (this.peer) { try { this.peer.destroy(); } catch { /* */ } this.peer = null; }
    if (!keepListeners) this._setState('idle');
  }

  async restart() { await this.start(); }

  _options() {
    const st = S.settings;
    const opts = { debug: st.debug ? 2 : 0, pingInterval: 5000 };
    opts.logFunction = (lvl, ...rest) => this.log(['', 'E', 'W', 'D'][lvl] || 'D', '[peerjs]', ...rest);
    if (st.server.mode === 'custom' && st.server.host) {
      opts.host = st.server.host;
      opts.port = Number(st.server.port) || 443;
      opts.path = st.server.path || '/';
      opts.key = st.server.key || 'peerjs';
      opts.secure = !!st.server.secure;
    }
    let servers = null;
    if (st.ice.mode === 'custom') servers = parseIce(st.ice.servers);
    if ((!servers || !servers.length) && st.ice.relayOnly) servers = PEERJS_DEFAULT_ICE;
    if (servers && servers.length) {
      opts.config = { iceServers: servers, sdpSemantics: 'unified-plan' };
      if (st.ice.relayOnly) opts.config.iceTransportPolicy = 'relay';
    }
    return opts;
  }

  _create() {
    const gen = this._gen;
    let peer;
    try {
      peer = new Peer(this.myId, this._options());
    } catch (e) {
      this.log('E', 'Peer ctor failed', e);
      this._setState('error', { type: 'ctor', message: e.message });
      return;
    }
    this.peer = peer;
    peer.on('open', (id) => {
      if (gen !== this._gen) return;
      this._backoff = 0;
      this._idRetries = 0;
      this.log('I', 'signaling open as', id);
      this._setState('online');
    });
    peer.on('connection', (conn) => { if (gen === this._gen) this._adopt(conn, false); });
    peer.on('call', (call) => { if (gen === this._gen) this.emit('call', call); });
    peer.on('disconnected', () => {
      if (gen !== this._gen) return;
      this.log('W', 'signaling disconnected');
      if (this.state !== 'conflict' && this.state !== 'error') this._setState('reconnecting');
      this._scheduleRecover();
    });
    peer.on('close', () => {
      if (gen !== this._gen) return;
      this.log('W', 'peer closed');
      if (this.state !== 'conflict' && this.state !== 'error') { this._setState('reconnecting'); this._scheduleRecover(); }
    });
    peer.on('error', (err) => { if (gen === this._gen) this._onPeerError(err); });
  }

  _onPeerError(err) {
    const type = err?.type || 'unknown';
    this.log('E', 'peer error', type, err?.message || '');
    switch (type) {
      case 'peer-unavailable': {
        const m = /peer\s+(\S+)\s*$/.exec(err.message || '');
        const id = m ? m[1] : null;
        if (id) {
          for (const c of [...this.hs]) if (c.peer === id && c._pl.outgoing) { try { c.close(); } catch { /* */ } }
          this._fail(id, Object.assign(new Error('peer-unavailable'), { type }));
          this.emit('unavailable', id);
        }
        else for (const k of [...this.waiting.keys()]) this._fail(k, Object.assign(new Error('peer-unavailable'), { type }));
        return;
      }
      case 'unavailable-id':
        // Our previous session may still be registered on the server; retry for a while.
        if (++this._idRetries <= 6) {
          this._setState('reconnecting');
          this._scheduleRecover(4000, true);
        } else {
          this._setState('conflict', { type, message: 'This ID is already in use on the server.' });
        }
        return;
      case 'invalid-id':
      case 'invalid-key':
      case 'ssl-unavailable':
      case 'browser-incompatible':
        this._setState('error', { type, message: err.message });
        return;
      case 'webrtc':
        return; // per-connection problem; the connection's own handlers deal with it
      case 'disconnected':
        this._scheduleRecover(500);
        return;
      default: // network, socket-error, socket-closed, server-error, ...
        if (this.state === 'online') this._setState('reconnecting');
        this._scheduleRecover();
    }
  }

  recover(immediate) { this._scheduleRecover(immediate ? 50 : undefined, false, true); }

  _scheduleRecover(delay, recreate = false, force = false) {
    if (this._recoverTimer && !force) return;
    clearTimeout(this._recoverTimer);
    const wait = delay ?? Math.min(30000, 1000 * 2 ** this._backoff++);
    this._recoverTimer = setTimeout(() => {
      this._recoverTimer = null;
      if (!navigator.onLine) { this._setState('offline'); this._scheduleRecover(5000); return; }
      if (this.state === 'error') return;
      if (this.state === 'offline') this._setState('connecting');
      if (recreate || !this.peer || this.peer.destroyed) {
        try { this.peer?.destroy(); } catch { /* */ }
        this.peer = null;
        this._gen++;
        this._create();
      } else if (this.peer.disconnected) {
        this.log('I', 'reconnect()');
        try { this.peer.reconnect(); } catch (e) { this.log('E', 'reconnect failed', e); this._scheduleRecover(); }
      } else if (!this.peer.open) {
        this._scheduleRecover();
      }
    }, wait);
  }

  get online() { return this.state === 'online' && !!this.peer && !this.peer.disconnected; }

  /* ----------------------------- links ----------------------------- */

  link(id) { return this.links.get(id); }
  isOnline(id) { const l = this.links.get(id); return !!(l && l.ok && l.best(this.myId)); }
  onlineIds() { return [...this.links.values()].filter((l) => l.ok && l.best(this.myId)).map((l) => l.id); }

  connect(id) {
    if (id === this.myId) return Promise.reject(new Error('self'));
    const l = this.links.get(id);
    if (l?.ok && l.best(this.myId)) return Promise.resolve(l);
    const existing = this.waiting.get(id);
    if (existing) return existing.promise;
    if (!this.online) return Promise.reject(Object.assign(new Error('offline'), { type: 'offline' }));
    const w = {};
    w.promise = new Promise((res, rej) => { w.res = res; w.rej = rej; });
    w.promise.catch(() => {}); // avoid unhandled-rejection noise for fire-and-forget callers
    w.timer = setTimeout(() => this._fail(id, Object.assign(new Error('timeout'), { type: 'timeout' })), CONNECT_TIMEOUT);
    this.waiting.set(id, w);
    const incoming = [...this.hs].some((c) => c.peer === id && !c._pl.outgoing);
    if (!incoming) {
      let conn;
      try {
        conn = this.peer.connect(id, { serialization: 'binary-utf8', reliable: true, label: 'pl', metadata: { app: 'peerlink', v: PROTO } });
      } catch (e) { conn = null; this.log('E', 'connect threw', e); }
      if (!conn) this._fail(id, new Error('connect-failed'));
      else this._adopt(conn, true);
    }
    return w.promise;
  }

  _fail(id, err) {
    const w = this.waiting.get(id);
    if (!w) return;
    clearTimeout(w.timer);
    this.waiting.delete(id);
    w.rej(err);
  }
  _succeed(id, link) {
    const w = this.waiting.get(id);
    if (!w) return;
    clearTimeout(w.timer);
    this.waiting.delete(id);
    w.res(link);
  }

  _adopt(conn, outgoing) {
    const st = (conn._pl = { outgoing, ok: false, nonce: randomB64(16), helloIn: null, authSent: false, t: null, pending: [] });
    this.hs.add(conn);
    st.t = setTimeout(() => {
      if (!st.ok) { this.log('W', 'handshake timeout with', conn.peer); try { conn.close(); } catch { /* */ } }
    }, HS_TIMEOUT);
    conn.on('open', () => this._onOpen(conn));
    conn.on('data', (d) => this._onData(conn, d));
    conn.on('close', () => this._onClose(conn));
    conn.on('error', (e) => this.log('E', 'conn error', conn.peer, e?.message || e));
    conn.on('iceStateChanged', (s) => this.log('D', 'ice', conn.peer, s));
    if (conn.open) this._onOpen(conn);
  }

  _onOpen(conn) {
    const st = conn._pl;
    if (st.helloSent) return;
    st.helloSent = true;
    const me = S.me;
    this._raw(conn, { t: 'hello', v: PROTO, id: me.id, name: me.name, emoji: me.emoji, color: me.color, bio: me.bio || '', pk: K.publicJwk(), nonce: st.nonce, caps: ['msg', 'file', 'call', 'group', 'voice', 'ttl'] });
  }

  _raw(conn, obj) { try { conn.send(obj); return true; } catch (e) { this.log('E', 'send failed', e?.message || e); return false; } }

  async _onData(conn, d) {
    const st = conn._pl;
    if (!d || typeof d !== 'object') return;
    const id = conn.peer;
    if (!st.ok) {
      if (d.t === 'hello') {
        if (d.id !== id || !d.pk || typeof d.nonce !== 'string' || d.nonce.length > 64) { this.log('W', 'bad hello from', id); conn.close(); return; }
        st.helloIn = d;
        const sig = await K.sign(`pl1|${d.nonce}|${this.myId}|${id}`);
        this._raw(conn, { t: 'auth', sig });
        st.authSent = true;
        await this._maybeFinish(conn);
      } else if (d.t === 'auth') {
        st.authIn = d;
        await this._maybeFinish(conn);
      } else if (st.pending.length < 200) {
        st.pending.push(d); // arrived before our verification finished; replayed in order afterwards
      }
      return;
    }
    this._dispatch(conn, d);
  }

  _dispatch(conn, d) {
    const id = conn.peer;
    const link = this.links.get(id);
    if (link) link.lastRx = now();
    if (d.t === 'ping') { this._raw(conn, { t: 'pong', ts: d.ts }); return; }
    if (d.t === 'pong') { if (link && typeof d.ts === 'number') link.rtt = Math.max(0, now() - d.ts); return; }
    this.emit('data', id, d, link, conn);
  }

  async _maybeFinish(conn) {
    const st = conn._pl;
    if (st.ok || st.verifying || !st.helloIn || !st.authIn) return;
    st.verifying = true;
    const hello = st.helloIn;
    const id = conn.peer;
    const good = await K.verify(hello.pk, `pl1|${st.nonce}|${hello.id}|${this.myId}`, st.authIn.sig);
    if (!good) { this.log('W', 'auth failed for', id); try { conn.close(); } catch { /* */ } return; }
    const fp = await K.fingerprint(hello.pk);
    if (!conn.open && conn._pl.closed) return;
    // ---- everything below is synchronous so no message can slip in half-initialised ----
    clearTimeout(st.t);
    st.ok = true;
    this.hs.delete(conn);
    let link = this.links.get(id);
    if (!link) { link = new Link(id); this.links.set(id, link); }
    link.conns.add(conn);
    const wasOk = link.ok;
    link.ok = true;
    link.since = link.since || now();
    link.lastRx = now();
    link.info = { name: String(hello.name || '').slice(0, 40), emoji: String(hello.emoji || '').slice(0, 8), color: String(hello.color || '').slice(0, 16), bio: String(hello.bio || '').slice(0, 140), pk: hello.pk, fp, caps: Array.isArray(hello.caps) ? hello.caps : [] };
    this.log('I', 'link up', id, st.outgoing ? '(outgoing)' : '(incoming)');
    this._dedupe(link);
    this._succeed(id, link);
    if (!wasOk) this.emit('link', link, link.info);
    const queued = st.pending.splice(0);
    for (const d of queued) this._dispatch(conn, d);
    this._probe(link);
  }

  /** Keep the canonical connection; close the duplicate shortly after so in-flight data lands. */
  _dedupe(link) {
    const ok = [...link.conns].filter((c) => c._pl?.ok);
    if (ok.length < 2) return;
    const keep = link.best(this.myId);
    for (const c of ok) {
      if (c !== keep) setTimeout(() => { if (keep.open) { link.conns.delete(c); try { c.close(); } catch { /* */ } } }, 2500);
    }
  }

  _onClose(conn) {
    const st = conn._pl;
    if (st) { clearTimeout(st.t); st.closed = true; }
    this.hs.delete(conn);
    const id = conn.peer;
    const link = this.links.get(id);
    if (link) link.conns.delete(conn);
    const stillShaking = [...this.hs].some((c) => c.peer === id);
    const stillUp = !!link && [...link.conns].some((c) => c._pl?.ok);
    if (!st?.ok) {
      if (!stillShaking && !stillUp) this._fail(id, new Error('closed'));
      return;
    }
    if (link && !stillUp) {
      link.ok = false;
      this.links.delete(id);
      this.log('I', 'link down', id);
      this.emit('down', id);
    }
  }

  closeLink(id) {
    const l = this.links.get(id);
    if (l) for (const c of [...l.conns]) { try { c.close(); } catch { /* */ } }
    for (const c of [...this.hs]) if (c.peer === id) { try { c.close(); } catch { /* */ } }
  }

  /* ----------------------------- sending ----------------------------- */

  async send(id, obj) {
    const link = await this.connect(id);
    const c = link.best(this.myId);
    if (!c) throw new Error('no-connection');
    c.send(obj);
  }

  trySend(id, obj) {
    const c = this.links.get(id)?.best(this.myId);
    if (!c) return false;
    try { c.send(obj); return true; } catch (e) { this.log('E', 'trySend', e?.message || e); return false; }
  }

  /** Waits until the data channel has drained below `high` bytes (back-pressure). */
  async drain(id, high = 1_000_000, maxWait = 30000) {
    const t0 = now();
    for (;;) {
      const c = this.links.get(id)?.best(this.myId);
      if (!c) throw new Error('no-connection');
      const buffered = c.dataChannel?.bufferedAmount || 0;
      if (buffered <= high && (c.bufferSize || 0) < 8) return;
      if (now() - t0 > maxWait) throw new Error('drain-timeout');
      await sleep(12);
    }
  }

  /* ----------------------------- health ----------------------------- */

  _tick() {
    const t = now();
    // Spike S1: if the WebView was frozen in the background this interval fires late.
    if (this._lastTick && t - this._lastTick > PING_EVERY * 2.5) this.log('W', `event loop was suspended for ~${Math.round((t - this._lastTick) / 1000)}s`);
    this._lastTick = t;
    for (const l of [...this.links.values()]) {
      if (!l.ok) continue;
      if (t - l.lastRx > DEAD_AFTER) {
        this.log('W', 'link timed out', l.id);
        this.closeLink(l.id);
        continue;
      }
      this.trySend(l.id, { t: 'ping', ts: t });
    }
  }

  async _probe(link) {
    const s = await this.stats(link.id).catch(() => null);
    if (s) { link.route = s.route; this.emit('route', link.id, s); }
  }

  async stats(id) {
    const c = this.links.get(id)?.best(this.myId);
    const pc = c?.peerConnection;
    if (!pc?.getStats) return null;
    const rep = await pc.getStats();
    let transport = null, pair = null;
    rep.forEach((r) => { if (r.type === 'transport') transport = r; });
    rep.forEach((r) => {
      if (r.type !== 'candidate-pair') return;
      if ((transport && r.id === transport.selectedCandidatePairId) || (!pair && r.state === 'succeeded' && (r.nominated || r.selected))) pair = r;
    });
    let local = null, remote = null;
    rep.forEach((r) => {
      if (pair && r.id === pair.localCandidateId) local = r;
      if (pair && r.id === pair.remoteCandidateId) remote = r;
    });
    const relay = local?.candidateType === 'relay' || remote?.candidateType === 'relay';
    const out = {
      route: pair ? (relay ? 'relay' : 'direct') : null,
      rtt: pair?.currentRoundTripTime != null ? Math.round(pair.currentRoundTripTime * 1000) : this.links.get(id)?.rtt,
      local: local?.candidateType, remote: remote?.candidateType, proto: local?.protocol,
      // Spike S2: WebView hides LAN IPs behind mDNS names (*.local); these must resolve on the peer.
      mdnsLocal: /\.local$/i.test(local?.address || local?.ip || ''), mdnsRemote: /\.local$/i.test(remote?.address || remote?.ip || ''),
      sent: pair?.bytesSent, recv: pair?.bytesReceived,
    };
    const l = this.links.get(id);
    if (l && out.route) l.route = out.route;
    return out;
  }
}

function safeJson(o) { try { return JSON.stringify(o); } catch { return String(o); } }

export const net = new Net();
