// On-device connection self-test. It runs the REAL stack (PeerJS + WebRTC) inside this WebView,
// so a failing step points straight at what is wrong on this phone / network.

import { Peer } from 'peerjs';
import { S } from './state.js';
import * as db from './db.js';
import { PEERJS_DEFAULT_ICE, clean } from './net.js';
import { parseIce, sleep } from './util.js';

const timeout = (p, ms, label) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error(`${label} timed out after ${ms / 1000}s`)), ms))]);
const rid = () => Math.random().toString(36).slice(2, 8);

export function iceServers() {
  let s = S.settings.ice.mode === 'custom' ? parseIce(S.settings.ice.servers) : null;
  if (!s || !s.length) s = PEERJS_DEFAULT_ICE;
  return s;
}
function serverOpts() {
  const sv = S.settings.server;
  return sv.mode === 'custom' && sv.host ? { host: sv.host, port: Number(sv.port) || 443, path: sv.path || '/', key: sv.key || 'peerjs', secure: !!sv.secure } : {};
}
function wsUrl(id) {
  const o = serverOpts();
  const host = o.host || '0.peerjs.com', port = o.port || 443, secure = o.host ? o.secure : true;
  let path = o.path || '/';
  if (!path.startsWith('/')) path = `/${path}`;
  if (!path.endsWith('/')) path += '/';
  return `${secure ? 'wss' : 'ws'}://${host}:${port}${path}peerjs?key=${encodeURIComponent(o.key || 'peerjs')}&id=${id}&token=${rid()}`;
}

/* ------------------------------ individual tests ------------------------------ */
const TESTS = [
  {
    id: 'env', name: 'This phone (WebView)',
    async run() {
      const miss = [];
      if (typeof RTCPeerConnection === 'undefined') miss.push('WebRTC');
      if (!crypto?.subtle) miss.push('WebCrypto (needs a secure context)');
      if (!window.indexedDB) miss.push('IndexedDB');
      if (typeof WebSocket === 'undefined') miss.push('WebSocket');
      const chrome = /Chrome\/(\d+)/.exec(navigator.userAgent)?.[1];
      if (miss.length) throw new Error(`missing: ${miss.join(', ')}`);
      return { detail: `WebView Chrome ${chrome || '?'} · online=${navigator.onLine}${chrome && +chrome < 90 ? ' · OLD — update Android System WebView' : ''}`, warn: !navigator.onLine || (chrome && +chrome < 90) };
    },
  },
  {
    id: 'storage', name: 'Local storage',
    async run() {
      const k = `selftest-${rid()}`;
      await db.put('kv', { t: Date.now(), blob: new Blob(['x'.repeat(1000)]) }, k);
      const v = await db.get('kv', k);
      await db.del('kv', k);
      if (!v?.blob || v.blob.size !== 1000) throw new Error('IndexedDB blob round-trip failed');
      return { detail: 'IndexedDB read/write OK' };
    },
  },
  {
    id: 'crypto', name: 'Identity keys & signatures',
    async run() {
      const kp = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign', 'verify']);
      const data = new TextEncoder().encode('peerlink');
      const sig = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, kp.privateKey, data);
      const jwk = await crypto.subtle.exportKey('jwk', kp.publicKey);
      const pub = await crypto.subtle.importKey('jwk', { kty: jwk.kty, crv: jwk.crv, x: jwk.x, y: jwk.y, ext: true }, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
      if (!(await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, pub, sig, data))) throw new Error('signature did not verify');
      return { detail: 'ECDSA P-256 sign/verify OK' };
    },
  },
  {
    id: 'signaling', name: 'Signaling server',
    async run() {
      const url = wsUrl(`plst-${rid()}`);
      const t0 = Date.now();
      await timeout(new Promise((resolve, reject) => {
        let ws;
        try { ws = new WebSocket(url); } catch (e) { reject(new Error(`cannot open WebSocket (${e.message})`)); return; }
        ws.onmessage = (e) => {
          let m = {}; try { m = JSON.parse(e.data); } catch { /* */ }
          if (m.type === 'OPEN') { ws.close(); resolve(); }
          else if (m.type === 'ERROR' || m.type === 'INVALID-KEY' || m.type === 'ID-TAKEN') { ws.close(); reject(new Error(`server replied ${m.type}${m.payload?.msg ? `: ${m.payload.msg}` : ''}`)); }
        };
        ws.onerror = () => reject(new Error('WebSocket error (server unreachable, blocked, or TLS problem)'));
        ws.onclose = (e) => reject(new Error(`WebSocket closed (code ${e.code})`));
      }), 10000, 'signaling');
      return { detail: `${new URL(url.replace(/^ws/, 'http')).host} answered in ${Date.now() - t0} ms` };
    },
  },
  {
    id: 'ice', name: 'NAT traversal (STUN / TURN)',
    async run() {
      const pc = new RTCPeerConnection({ iceServers: iceServers(), iceCandidatePoolSize: 0 });
      const found = { host: 0, srflx: 0, relay: 0, mdns: 0 };
      pc.createDataChannel('probe');
      await new Promise((resolve) => {
        const t = setTimeout(resolve, 10000);
        pc.onicecandidate = (e) => {
          if (!e.candidate) { clearTimeout(t); resolve(); return; }
          const c = e.candidate.candidate || '';
          const typ = /typ (host|srflx|relay|prflx)/.exec(c)?.[1];
          if (typ && found[typ] !== undefined) found[typ]++;
          if (typ === 'host' && /\.local /.test(c)) found.mdns++;
        };
        pc.createOffer().then((o) => pc.setLocalDescription(o));
      });
      pc.close();
      const detail = `host ${found.host}${found.mdns ? ' (mDNS-masked)' : ''} · STUN ${found.srflx} · TURN relay ${found.relay}`;
      if (!found.srflx && !found.relay) return { detail: `${detail} — no STUN/TURN answer: only same-network connections can work`, warn: true };
      if (!found.relay) return { detail: `${detail} — TURN unreachable: may fail on mobile data / strict NAT`, warn: true };
      return { detail };
    },
  },
  {
    id: 'loopback', name: 'WebRTC data channel (on this phone)',
    async run() {
      const a = new RTCPeerConnection({ iceServers: [] }), b = new RTCPeerConnection({ iceServers: [] });
      a.onicecandidate = (e) => e.candidate && b.addIceCandidate(e.candidate).catch(() => {});
      b.onicecandidate = (e) => e.candidate && a.addIceCandidate(e.candidate).catch(() => {});
      const dc = a.createDataChannel('t');
      const got = new Promise((resolve) => { b.ondatachannel = (e) => { e.channel.onmessage = (m) => e.channel.send(`echo:${m.data}`); }; dc.onmessage = (m) => resolve(m.data); });
      dc.onopen = () => dc.send('ping');
      await a.setLocalDescription(await a.createOffer());
      await b.setRemoteDescription(a.localDescription);
      await b.setLocalDescription(await b.createAnswer());
      await a.setRemoteDescription(b.localDescription);
      try { const r = await timeout(got, 8000, 'data channel'); if (r !== 'echo:ping') throw new Error('unexpected echo'); }
      finally { a.close(); b.close(); }
      return { detail: 'RTCDataChannel echo OK' };
    },
  },
  {
    id: 'peerjs', name: 'PeerJS end-to-end (two temporary peers)',
    async run() {
      const idA = `plst-${rid()}-a`, idB = `plst-${rid()}-b`;
      const opts = { ...serverOpts(), config: { iceServers: iceServers(), sdpSemantics: 'unified-plan' }, debug: 0, pingInterval: 5000 };
      const a = new Peer(idA, opts), b = new Peer(idB, opts);
      const kill = () => { try { a.destroy(); } catch { /* */ } try { b.destroy(); } catch { /* */ } };
      const open = (p, n) => new Promise((res, rej) => { p.on('open', res); p.on('error', (e) => rej(new Error(`peer ${n}: ${e.type || ''} ${e.message || ''}`.trim()))); });
      try {
        await timeout(Promise.all([open(a, 'A'), open(b, 'B')]), 15000, 'registering with the server');
        const payload = clean({ t: 'msg', id: 'x', text: 'héllo 👋 ✓ — ünïcode', big: 'z'.repeat(40000), rt: undefined, g: undefined, nested: { arr: [1, 2, { k: 'v' }], n: null }, bin: new Uint8Array([1, 2, 3, 250]).buffer });
        b.on('connection', (c) => c.on('data', (d) => { try { c.send({ echo: d }); } catch { /* */ } }));
        const conn = a.connect(idB, { serialization: 'binary-utf8', reliable: true, label: 'pl' });
        if (!conn) throw new Error('connect() returned nothing');
        const reply = new Promise((res, rej) => { conn.on('data', res); conn.on('error', rej); });
        await timeout(new Promise((res, rej) => { conn.on('open', res); conn.on('error', rej); a.on('error', (e) => e.type === 'peer-unavailable' && rej(e)); }), 30000, 'establishing the WebRTC connection');
        const t0 = Date.now();
        conn.send(payload);
        const r = (await timeout(reply, 15000, 'round trip')).echo;
        const same = r && r.text === payload.text && r.big === payload.big && r.nested?.arr?.[2]?.k === 'v' && new Uint8Array(r.bin instanceof ArrayBuffer ? r.bin : r.bin?.buffer || []).length === 4;
        if (!same) throw new Error('data came back altered (serialization problem)');
        let route = '';
        try {
          const rep = await conn.peerConnection.getStats();
          let tr, pair; rep.forEach((x) => { if (x.type === 'transport') tr = x; });
          rep.forEach((x) => { if (x.type === 'candidate-pair' && ((tr && x.id === tr.selectedCandidatePairId) || x.nominated)) pair = pair || x; });
          let l; rep.forEach((x) => { if (pair && x.id === pair.localCandidateId) l = x; });
          route = l ? ` · via ${l.candidateType}` : '';
        } catch { /* stats optional */ }
        return { detail: `connected + echoed unicode/binary/40 KB in ${Date.now() - t0} ms${route}` };
      } finally { kill(); }
    },
  },
];

export const TEST_NAMES = TESTS.map((t) => ({ id: t.id, name: t.name }));

export async function runSelfTest(onUpdate) {
  const results = [];
  for (const t of TESTS) {
    const r = { id: t.id, name: t.name, state: 'running', detail: '', ms: 0 };
    results.push(r);
    onUpdate?.(results);
    const t0 = Date.now();
    try {
      const out = await t.run();
      r.state = out.warn ? 'warn' : 'ok';
      r.detail = out.detail;
    } catch (e) {
      r.state = 'fail';
      r.detail = e?.message || String(e);
    }
    r.ms = Date.now() - t0;
    onUpdate?.(results);
    if (t.id === 'signaling' && r.state === 'fail') await sleep(50);
  }
  return { results, advice: advise(results) };
}

export function advise(results) {
  const by = Object.fromEntries(results.map((r) => [r.id, r]));
  const out = [];
  if (by.env?.state === 'fail' || by.loopback?.state === 'fail') out.push('This phone’s WebView cannot run WebRTC properly. Update “Android System WebView” and Chrome in Google Play, then restart the phone.');
  if (by.signaling?.state === 'fail') out.push('The phone cannot reach the PeerJS signaling server. Check internet, VPN / private-DNS / ad-blocker settings, or switch to your own server in Settings → Network & servers.');
  if (by.ice?.state === 'warn' || by.ice?.state === 'fail') {
    if (/no STUN\/TURN/.test(by.ice.detail)) out.push('No STUN/TURN server answered (UDP is probably blocked). Phones on different networks will not connect; add a TURN server in Settings → Network, or put both phones on the same Wi-Fi.');
    else out.push('TURN relay is unreachable. Connections work on friendly networks but fail on mobile data or strict NAT. Add your own TURN server in Settings → Network & servers.');
  }
  if (by.peerjs?.state === 'fail' && by.signaling?.state === 'ok' && by.loopback?.state === 'ok') out.push('The PeerJS round-trip failed even though the pieces work. Copy the report and the diagnostics log and send them to the developer.');
  if (!out.length && results.every((r) => r.state === 'ok' || r.state === 'warn')) out.push('This phone’s side is healthy. If messages still do not arrive, the other phone must ALSO have PeerLink open and connected at the same time (peer-to-peer has no server inbox), and both must pass this test.');
  return out;
}

export function reportText(results, advice) {
  const mark = { ok: '[OK]  ', warn: '[WARN]', fail: '[FAIL]', running: '[...] ' };
  return [`PeerLink self-test ${new Date().toISOString()}`, ...results.map((r) => `${mark[r.state]} ${r.name}: ${r.detail}`), '', ...advice.map((a) => `- ${a}`)].join('\n');
}
