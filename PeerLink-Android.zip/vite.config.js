import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    target: 'chrome80',
    chunkSizeWarningLimit: 900,
    sourcemap: false,
  },
  server: { port: 5173 },
});
