package app.peerlink.messenger;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.WebView;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** JS bridge: start/stop the keep-alive foreground service and open battery-optimisation settings. */
@CapacitorPlugin(name = "KeepAlive")
public class KeepAlivePlugin extends Plugin {
    private boolean active = false;

    @PluginMethod
    public void start(PluginCall call) {
        try {
            Context c = getContext();
            Intent i = new Intent(c, KeepAliveService.class);
            i.putExtra("title", call.getString("title", "PeerLink"));
            i.putExtra("text", call.getString("text", "Connected and ready for messages"));
            if (Build.VERSION.SDK_INT >= 26) {
                c.startForegroundService(i);
            } else {
                c.startService(i);
            }
            active = true;
            call.resolve();
        } catch (Throwable t) {
            call.reject("Could not start the background service: " + t.getMessage());
        }
    }

    @PluginMethod
    public void stop(PluginCall call) {
        try {
            active = false;
            getContext().stopService(new Intent(getContext(), KeepAliveService.class));
            call.resolve();
        } catch (Throwable t) {
            call.reject(String.valueOf(t.getMessage()));
        }
    }

    @PluginMethod
    public void status(PluginCall call) {
        JSObject r = new JSObject();
        boolean ignoring = true;
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                PowerManager pm = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
                ignoring = pm != null && pm.isIgnoringBatteryOptimizations(getContext().getPackageName());
            }
        } catch (Throwable ignored) {
        }
        r.put("active", active);
        r.put("ignoringBatteryOptimizations", ignoring);
        call.resolve(r);
    }

    @PluginMethod
    public void openBatterySettings(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Throwable t) {
            try {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getContext().getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
                call.resolve();
            } catch (Throwable t2) {
                call.reject(String.valueOf(t2.getMessage()));
            }
        }
    }

    // Best effort: keep WebView timers (and thus PeerJS heartbeats) running while backgrounded.
    private void keepTimers() {
        if (!active || getBridge() == null) return;
        final WebView wv = getBridge().getWebView();
        if (wv == null) return;
        wv.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    wv.resumeTimers();
                } catch (Throwable ignored) {
                }
            }
        }, 400);
    }

    @Override
    protected void handleOnPause() {
        keepTimers();
    }

    @Override
    protected void handleOnStop() {
        keepTimers();
    }
}
