# PeerLink Android

PeerLink is an Android WebView app for PeerJS/WebRTC peer-to-peer messaging, chunked file transfer, and audio/video calling.

## Package details

- Application ID / package: `com.dra.peerlink`
- Display name: `PeerLink`
- Version: `1.0.0`
- Minimum Android: 8.0 (API 26)
- Target SDK: 35
- Build: Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17

## Build APK in GitHub Actions

1. Create a GitHub repository.
2. Upload `PeerLink-Android.zip` to the repository root.
3. Upload `.github/workflows/build-apk.yml` separately to the repository at that exact path (GitHub cannot run a workflow that exists only inside an unextracted ZIP).
4. Open **Actions** → **Build PeerLink APK** → **Run workflow**, or push a commit.
5. Download the `PeerLink-debug-apk` artifact from the completed workflow.

The workflow extracts the ZIP into the repository and runs `gradle assembleDebug`. The APK is an unsigned debug APK suitable for installation/testing, not a Play Store release. For release distribution, configure signing secrets and a release build.

## Features

- PeerJS signaling with configurable host, port, path and ICE server JSON
- Generated temporary peer ID, copy ID, connect by peer ID
- Direct text messaging with local history and peer labels
- Chunked multi-file transfer with transfer progress and download links
- PeerJS audio/video calls and incoming-call handling
- Reconnect by creating a new Peer instance; connection status/error feedback
- Local preferences, history export and local history deletion
- Responsive dark UI, mobile-first layout, light theme option
- Android WebView file picker and camera/microphone permission bridge
- Uses HTTPS app asset origin via `WebViewAssetLoader` for WebRTC secure-context support

## Important limitations before production deployment

This is a functional starter project, not a security-audited commercial messenger. PeerJS IDs are temporary broker IDs, not verified identities. It has no user accounts, contact discovery, offline message delivery, push notifications, group chat, message receipts, or audited end-to-end encryption. Chat history is stored in local WebView storage and can be lost when app data is cleared.

The client loads PeerJS 1.5.5 from unpkg at runtime, so an internet connection is required and the CDN must remain available. The free PeerJS broker is a signaling service, not a TURN relay. Some networks require a properly configured TURN server for connectivity. Configure your own PeerServer and TURN credentials for dependable production use. Do not place long-lived TURN secrets in a client app; use short-lived credentials from a trusted service.

File transfers are chunked at 48 KiB per message and intended for moderate files. Both apps must remain open. Large files can consume substantial memory on the receiving device; test on target devices before relying on multi-gigabyte transfers. The receiver checks final file size but this starter does not provide cryptographic file integrity verification or resumable transfers.

Transport encryption is provided by WebRTC (DTLS/SRTP). This does not equal independently verified application-level end-to-end encryption: users do not authenticate peer identities, and no audited key verification protocol is implemented.

## Debug / validation

The project files are organized as a standard Android Gradle project. GitHub Actions compiles it, but no claim is made that this generated project has been tested on physical Android devices or that every WebRTC/network combination works. Run the workflow and test on at least two devices before use.


## Build failure fix

The Gradle build configuration aligns transitive Kotlin standard-library artifacts to 1.8.22 to prevent duplicate-class errors when older `kotlin-stdlib-jdk7/jdk8` artifacts are pulled alongside `kotlin-stdlib`.
