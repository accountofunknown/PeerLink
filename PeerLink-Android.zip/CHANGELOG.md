# Changelog

## 1.1.0 — security + messenger + transfer features
* **Verified identity:** QR codes / invite links now carry your key fingerprint. Scanning in person pins the key and marks the contact *verified*; if a different device answers to that ID you get a "wrong identity" warning and the key is **not** pinned. Contact cards (introductions) pin the introduced key the same way.
* **End-to-end file integrity:** every file is hashed (SHA-256) by the sender and re-verified by the receiver after reassembly; mismatches are rejected. The verified hash is shown in file details.
* **Transfer control:** manual pause / resume from either side (mirrored), a send queue (two files at a time per contact), and a bandwidth limit (Settings → File transfers).
* **Messenger:** polls (single / multiple choice, live votes), contact cards, starred messages with a per-chat Starred list.
* **Photos:** "Photos (compressed)" re-encodes to max 1600 px JPEG and strips EXIF/location data; originals still available.

## 1.0.4 — TURN made easy (cross-network connections)
* Evidence from CI (real PeerJS server + Android 14 WebView): messaging, receipts, file transfer and PeerJS round trips all work; the only red item was **TURN: PeerJS's free default relay returned no relay address**. Without TURN, phones on different networks / mobile data often cannot connect.
* Settings → Network & servers: **Test servers** (per-URL STUN/TURN check), **quick-add TURN form**, **load servers from a credentials URL**, and **Copy / Paste settings** to configure the second phone in one step.
* ICE lists are validated; TURN-only lists automatically get STUN; last good URL result is cached.
* New guide: `docs/TURN-SETUP.md` (own coturn in 10 minutes, provider notes, troubleshooting).

## 1.0.3 — CI now tests the real stack
* The emulator job runs the in-app self-test **inside the real Android WebView** (via `peerlink://selftest`) and prints the results in the run log, so signaling / STUN / WebRTC / PeerJS problems on Android show up without a phone.
* Fixed the real-PeerJS integration job (the signaling server is now started in-process; it previously never started).
* `npm audit` now checks shipped dependencies only (the current findings are in build tools: `tar` via `@capacitor/cli`, and `vite`/`esbuild`; they are resolved by the planned Capacitor upgrade).

## 1.0.2 — delivery fixes + diagnosis
* **Connection self-test** (Settings → Connection diagnostics): checks WebView, storage, keys, signaling server, STUN/TURN, WebRTC and a full two-peer PeerJS round trip on the phone, with plain-language advice and a copyable report.
* **Why isn't it delivered?** A queued message now records the reason; tap its clock icon for an explanation, "Retry now" and "Run test". Chats show a banner while the server connection is down.
* **Wire hygiene:** `undefined` fields are stripped from every packet (the real PeerJS serializer does not accept them; the test mock hid this).
* **Reconnect:** after >15 s in the background or a network change the signaling session is rebuilt from scratch instead of trusting a possibly dead socket. Outbox retries every 20 s. Longer handshake/connect timeouts for slow mobile networks. Explicit STUN list plus PeerJS TURN.
* **Background connection (Android):** optional foreground service (`remoteMessaging`) keeps the app connected with the screen off, plus a shortcut to the battery-optimisation setting. If the native part fails to compile, CI automatically rebuilds without it.

## 1.0.1 — Phase 0: verify + harden
* Android backups disabled (`allowBackup=false`, data-extraction rules) so chats/keys never leave the device via cloud backup or device transfer.
* CI: stable public test key (builds update in place), lockfile export + `npm ci`, `npm audit`, real-PeerJS integration test, emulator smoke test — all informational.
* File size cap lowered to 1 GB until streaming-to-disk is implemented (the previous 4 GB limit was never validated on phones).
* Diagnostics: heartbeat gap detection (background-suspension data for spike S1) and mDNS candidate flag (spike S2).
* Boot markers (`PeerLink-boot: …`) for the smoke test; Dependabot config; optional CodeQL workflow in `docs/optional-workflows/`.

## 1.0.0
* Initial release.
