# Changelog

## 1.0.1 — Phase 0: verify + harden
* Android backups disabled (`allowBackup=false`, data-extraction rules) so chats/keys never leave the device via cloud backup or device transfer.
* CI: stable public test key (builds update in place), lockfile export + `npm ci`, `npm audit`, real-PeerJS integration test, emulator smoke test — all informational.
* File size cap lowered to 1 GB until streaming-to-disk is implemented (the previous 4 GB limit was never validated on phones).
* Diagnostics: heartbeat gap detection (background-suspension data for spike S1) and mDNS candidate flag (spike S2).
* Boot markers (`PeerLink-boot: …`) for the smoke test; Dependabot config; optional CodeQL workflow in `docs/optional-workflows/`.

## 1.0.0
* Initial release.
