# Changelog

## 1.0.2 — delivery fixes + diagnosis
* **Connection self-test** (Settings → Connection diagnostics): checks WebView, storage, keys, signaling server, STUN/TURN, WebRTC and a full two-peer PeerJS round trip on the phone, with plain-language advice and a copyable report.
* **Why isn't it delivered?** A queued message now records the reason; tap its clock icon for an explanation, "Retry now" and "Run test". Chats show a banner while the server connection is down.
* **Wire hygiene:** `undefined` fields are stripped from every packet (the real PeerJS serializer does not accept them; the test mock hid this).
* **Reconnect:** after >15 s in the background or a network change the signaling session is rebuilt from scratch instead of trusting a possibly dead socket. Outbox retries every 20 s. Longer handshake/connect timeouts for slow mobile networks. Explicit STUN list plus PeerJS TURN.
* **Background connection (Android):** optional foreground service (`remoteMessaging`) keeps the app connected with the screen off, plus a shortcut to the battery-optimisation setting. If the native part fails to compile, CI automatically rebuilds without it.

## 1.0.1 — Phase 0: verify + harden
* Android backups disabled (`allowBackup=false`, data-extraction rules) so chats/keys never leave the device via cloud backup or device transfer.
* CI: stable public test key (builds update in place), lockfile export + `npm ci`, `npm audit`, real-PeerJS integration test, emulator smoke test — all informational.
* File size cap lowered to 1 GB until streaming-to-disk is implemented (the previous 4 GB limit was never validated on phones).
* Diagnostics: heartbeat gap detection (background-suspension data for spike S1) and mDNS candidate flag (spike S2).
* Boot markers (`PeerLink-boot: …`) for the smoke test; Dependabot config; optional CodeQL workflow in `docs/optional-workflows/`.

## 1.0.0
* Initial release.
