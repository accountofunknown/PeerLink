# Getting PeerLink to connect across networks (TURN)

PeerLink sends everything **directly** between phones (WebRTC). Whether two phones can reach each other depends on
their networks:

| Situation | Works with STUN only? | Needs TURN? |
|---|---|---|
| Both phones on the same home Wi-Fi | usually | sometimes (client isolation, no hairpin NAT) |
| Different Wi-Fi networks | often | sometimes |
| Either phone on **mobile data** (CGNAT / symmetric NAT) | often **no** | **yes** |
| Office / guest / hotel Wi-Fi | often **no** | **yes** |

A **TURN server** relays the encrypted traffic when a direct path is impossible. It never sees message contents
(end-to-end DTLS), but it does carry the bandwidth, so file transfers over TURN use the server's data allowance.

## 1. Check what you have
Settings → **Network & servers → Test servers**. You want at least one `TURN · …` row with a green tick ("relay address
obtained"). PeerJS's free default TURN currently returns **no relay** in our tests (STUN works, TURN does not), so most
people need to add their own.

## 2. Option A — run your own coturn (about 10 minutes, any small VPS)
On a VPS with a public IP (replace `PUBLIC_IP`, `STRONG_PASSWORD`):

```bash
docker run -d --name coturn --restart unless-stopped --network=host coturn/coturn \
  -n --log-file=stdout --realm=peerlink --fingerprint --lt-cred-mech \
  --user=peerlink:STRONG_PASSWORD \
  --external-ip=PUBLIC_IP --listening-port=3478 --min-port=49160 --max-port=49200 \
  --no-multicast-peers --no-cli \
  --denied-peer-ip=10.0.0.0-10.255.255.255 --denied-peer-ip=172.16.0.0-172.31.255.255 --denied-peer-ip=192.168.0.0-192.168.255.255 --denied-peer-ip=127.0.0.0-127.255.255.255
```
Open in the VPS firewall: **3478 UDP+TCP** and **49160–49200 UDP**.
In PeerLink → Network & servers → *Quick add*: `turn:PUBLIC_IP:3478`, username `peerlink`, password `STRONG_PASSWORD`
→ **Add to list** → **Test servers** → **Save & reconnect**.

Tips: use a hostname + TLS (`turns:` on port 5349 or 443) if mobile carriers block 3478; keep the password private;
the denied-peer rules stop the relay being used to reach your internal network.

## 3. Option B — a managed TURN provider
Several providers offer small free tiers. Terms change, so check the current limits yourself. If the provider gives you
**a URL that returns JSON** (a list of `iceServers`), paste it under *Or load servers from a URL*; PeerLink fetches fresh
credentials every time it connects. Otherwise copy the `turn:` URL, username and credential into *Quick add*.

## 4. Configure BOTH phones
Each phone gathers its own relay address. On the first phone tap **Copy settings**, on the second tap **Paste settings**.

## 5. Still not connecting?
* Run **Connection diagnostics → Run test** on both phones and compare.
* Both phones must be running PeerLink at the same time (there is no server inbox).
* Try **Relay only** to confirm TURN works end to end (it forces all traffic through the relay).
