# Real-device test checklist (Phase 0 exit criteria)

Use **two phones** (ideally different Android versions) with the latest CI APK. Tick each line and note device/OS.

## 0. First: run the self-test on EACH phone
Settings → Connection diagnostics → **Run test**. Tap **Copy report** and keep it (send me both reports if anything is red).
Also: Settings → Notifications & sounds → allow notifications, keep "Stay connected in background" on, and tap **Allow** for unrestricted battery.
**Both phones must have PeerLink open (or its "connected" notification showing) at the same time** — there is no server inbox.

### Cross-network check (needs a working TURN, see docs/TURN-SETUP.md)
- [ ] Network & servers → **Test servers** shows a green TURN row on both phones.
- [ ] Phone A on Wi-Fi, phone B on **mobile data**: message + 20 MB file succeed (header shows "relayed" or "direct").

## Install / identity
- [ ] APK installs; app opens to onboarding; ID and name saved after restart.
- [ ] Installing a newer CI build **over** the old one keeps chats and identity (same test key).

## Internet (mobile data on one phone, Wi-Fi on the other)
- [ ] Add contact by ID and by QR; both show "online · direct" or "relayed" in the chat header.
- [ ] Messages deliver; ticks go sent → delivered → read; typing indicator shows.
- [ ] Voice note, photo, 20 MB file send and arrive; Save to device writes into Documents/PeerLink (or share sheet).
- [ ] Voice and video call connect, mute/camera/flip work, hang-up ends both sides.

## Resilience
- [ ] Toggle airplane mode during a 50 MB transfer → it pauses and **resumes** by itself.
- [ ] Message sent while the other phone is offline is delivered when it comes back (app open on both).
- [ ] App locked with PIN: lock appears after the chosen delay.

## Spike data (please send the Diagnostics log screenshot / copy)
- [ ] **S1 Background:** open a chat, press Home, wait 5 min, 15 min, 30 min with screen off; return and open
      Settings → Connection diagnostics. Note any "event loop was suspended" lines, whether the link stayed up,
      and whether a message sent from the other phone during that time arrived while backgrounded.
- [ ] **S2 mDNS/LAN:** both phones on the same Wi-Fi with internet working, then repeat with a phone hotspot.
      In Contact info → Connection, note Route (direct/relayed) and whether Candidates shows "mDNS".
- [ ] **S4 Throughput:** send a 100 MB file on Wi-Fi; note the speed shown in the chat.

## Security sanity
- [ ] Settings → Android → Apps → PeerLink shows "Allow backup" is off for the app (or `adb shell dumpsys package` shows no ALLOW_BACKUP).
- [ ] Changing a contact's identity (reinstall their app without backup) shows the "Security identity changed" warning.
