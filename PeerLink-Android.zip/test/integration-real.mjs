// Two-browser integration test against a REAL PeerJS signaling server and the REAL peerjs client.
//   CI:     npm run build && npx peerjs --port 9000 &  node test/integration-real.mjs
//   Local self-check of this script (no server, mock PeerJS bundle):  node test/integration-real.mjs --mock
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';

const MOCK = process.argv.includes('--mock');
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const dist = path.join(root, MOCK ? 'test/dist' : 'dist');
const PORT_SIG = 9000;

async function loadPlaywright() {
  try { return await import('playwright'); } catch { /* fall through */ }
  const base = process.env.PLAYWRIGHT_PATH || '/home/claude/.npm-global/lib/node_modules/playwright/package.json';
  return createRequire(base)('playwright');
}
const pw = await loadPlaywright();
const { chromium } = pw.chromium ? pw : pw.default;

const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png' };
const web = http.createServer((q, r) => {
  const p = path.join(dist, decodeURIComponent(new URL(q.url, 'http://x').pathname).replace(/^\/$/, '/index.html'));
  fs.readFile(p, (e, d) => { if (e) { r.writeHead(404); r.end(); } else { r.writeHead(200, { 'content-type': mime[path.extname(p)] || 'application/octet-stream' }); r.end(d); } });
}).listen(0);
const webPort = web.address().port;

let sig = null;
if (!MOCK) {
  sig = spawn('npx', ['--no-install', 'peerjs', '--port', String(PORT_SIG), '--path', '/'], { stdio: 'inherit' });
  await new Promise((r) => setTimeout(r, 2500));
}

let failures = 0;
const ok = (c, m) => { if (c) console.log('  ✓', m); else { failures++; console.log('  ✗ FAIL:', m); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const until = async (fn, ms = 15000, what = '') => { const t = Date.now(); for (;;) { try { const v = await fn(); if (v) return v; } catch { /* retry */ } if (Date.now() - t > ms) throw new Error(`timeout: ${what}`); await sleep(100); } };

const browser = await chromium.launch({
  executablePath: process.env.CHROME_PATH || undefined,
  args: ['--no-sandbox', '--disable-features=WebRtcHideLocalIpsWithMdns', '--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream'],
});
const ctx = await browser.newContext({ viewport: { width: 390, height: 800 } });
const settings = JSON.stringify({ server: { mode: 'custom', host: 'localhost', port: PORT_SIG, path: '/', key: 'peerjs', secure: false }, ice: { mode: 'custom', servers: 'stun:stun.l.google.com:19302', relayOnly: false } });

async function device(name, id) {
  const page = await ctx.newPage();
  page.on('pageerror', (e) => console.log(`[${name} pageerror]`, e.message));
  if (!MOCK) await page.addInitScript(([k, v]) => localStorage.setItem(k, v), [`peerlink:${name}:settings`, settings]);
  await page.goto(`http://localhost:${webPort}/index.html?p=${name}&debug`);
  await page.waitForSelector('.onboard', { timeout: 20000 });
  await page.fill('.onboard input[placeholder="Your name"]', name);
  await page.fill('.onboard .id-row input', id);
  await page.click('.onboard .btn.primary');
  await page.waitForSelector('.tabbar');
  await until(() => page.evaluate(() => window.__pl.net.state === 'online'), 20000, `${name} online`);
  return page;
}
const ev = (p, fn, arg) => p.evaluate(fn, arg);

let exit = 0;
try {
  console.log(`\n# ${MOCK ? 'MOCK (script self-check)' : 'REAL PeerJS'} integration`);
  const A = await device('ita', 'it-alice-1');
  const B = await device('itb', 'it-bobby-2');
  ok(true, 'both clients registered with the signaling server');

  await ev(A, () => window.__pl.chat.addContact('it-bobby-2', 'Bobby'));
  await until(() => ev(A, () => window.__pl.net.isOnline('it-bobby-2')), 30000, 'link');
  ok(true, 'WebRTC data connection + signed handshake completed');

  await ev(A, () => window.__pl.chat.sendText('it-bobby-2', 'integration hello'));
  await until(() => ev(B, () => window.__pl.D.getChat('it-alice-1')?.last?.text === 'integration hello'), 15000, 'message');
  ok(true, 'text message delivered over real PeerJS');
  await until(async () => (await ev(A, async () => (await window.__pl.db.msgAll('it-bobby-2')).find((m) => m.kind === 'text')?.status)) === 'delivered', 10000, 'ack');
  ok(true, 'delivery receipt returned');

  await ev(B, () => window.__pl.chat.addContact('it-alice-1', 'Alice'));
  const size = 4 * 1024 * 1024 + 321;
  const sent = await ev(A, async (n) => {
    const b = new Uint8Array(n); let x = 7; for (let i = 0; i < n; i++) { x = (x * 1103515245 + 12345) & 0x7fffffff; b[i] = x >> 16; }
    const f = new File([b], 'it.bin', { type: 'application/octet-stream' });
    const m = await window.__pl.transfer.sendFile('it-bobby-2', f);
    const h = [...new Uint8Array(await crypto.subtle.digest('SHA-256', await f.arrayBuffer()))].map((v) => v.toString(16).padStart(2, '0')).join('');
    return { id: m.id, h };
  }, size);
  const t0 = Date.now();
  await until(async () => (await ev(B, async (id) => (await window.__pl.D.getMsg(id))?.file?.state, sent.id)) === 'done', 90000, 'file');
  const dt = (Date.now() - t0) / 1000;
  const rh = await ev(B, async (id) => { const b = await window.__pl.transfer.blob(id); return [...new Uint8Array(await crypto.subtle.digest('SHA-256', await b.arrayBuffer()))].map((v) => v.toString(16).padStart(2, '0')).join(''); }, sent.id);
  ok(rh === sent.h, `4 MB file intact over real PeerJS (${(size / 1048576 / dt).toFixed(1)} MB/s)`);

  const route = await ev(A, () => window.__pl.net.stats('it-bobby-2'));
  console.log('  route stats:', JSON.stringify(route));
} catch (e) {
  console.log('  ✗ ERROR:', e.message); exit = 1;
}
await browser.close(); web.close(); sig?.kill();
if (failures) exit = 1;
console.log(exit ? '\nINTEGRATION FAILED' : '\nINTEGRATION PASSED');
process.exit(exit);
