import { createRequire } from 'module';
import http from 'http';
import fs from 'fs';
import path from 'path';
const require = createRequire('/home/claude/.npm-global/lib/node_modules/playwright/package.json');
const { chromium } = require('playwright');
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname));
const dist = path.join(root, 'dist');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
const server = http.createServer((q, r) => {
  if (q.url === '/ice.json') { r.writeHead(200, { 'content-type': 'application/json', 'access-control-allow-origin': '*' }); r.end(JSON.stringify([{ urls: ['turn:turn.test.example:3478', 'bad:ignored'], username: 'u1', credential: 'c1' }, { urls: 'javascript:alert(1)' }, { urls: 'stun:stun.test.example:3478' }])); return; }
  const p = path.join(dist, decodeURIComponent(new URL(q.url, 'http://x').pathname).replace(/^\/$/, '/index.html'));
  fs.readFile(p, (e, d) => { if (e) { r.writeHead(404); r.end(); } else { r.writeHead(200, { 'content-type': mime[path.extname(p)] || 'application/octet-stream' }); r.end(d); } });
}).listen(0);
const port = server.address().port;
const shots = path.join(root, 'shots'); fs.mkdirSync(shots, { recursive: true });

let failures = 0;
const ok = (c, m) => { if (c) console.log('  ✓', m); else { failures++; console.log('  ✗ FAIL:', m); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const until = async (fn, ms = 8000, what = '') => { const t = Date.now(); for (;;) { try { const v = await fn(); if (v) return v; } catch {} if (Date.now() - t > ms) throw new Error('timeout: ' + what); await sleep(80); } };

const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream', '--disable-features=WebRtcHideLocalIpsWithMdns', '--no-sandbox', '--autoplay-policy=no-user-gesture-required'] });
const ctx = await browser.newContext({ viewport: { width: 390, height: 800 }, deviceScaleFactor: 2, permissions: ['camera', 'microphone', 'clipboard-read', 'clipboard-write'] });
const errors = [];
async function device(name, id) {
  const page = await ctx.newPage();
  page.on('pageerror', (e) => { errors.push(`${name}: ${e.message}`); console.log(`[${name} pageerror]`, e.message); });
  page.on('console', (m) => { if (m.type() === 'error') { errors.push(`${name}: ${m.text()}`); console.log(`[${name} console.error]`, m.text().slice(0, 300)); } });
  await page.goto(`http://localhost:${port}/index.html?p=${name}&debug`);
  await page.waitForSelector('.onboard');
  await page.fill('.onboard input[placeholder="Your name"]', name[0].toUpperCase() + name.slice(1));
  await page.fill('.onboard .id-row input', id);
  await page.click('.onboard .btn.primary');
  await page.waitForSelector('.tabbar');
  await until(() => page.evaluate(() => window.__pl.net.state === 'online'), 8000, `${name} online`);
  return page;
}
const ev = (p, fn, arg) => p.evaluate(fn, arg);

console.log('\n# Onboarding & connectivity');
const A = await device('alice', 'alice-test-1');
const B = await device('bob', 'bob-test-22');
const C = await device('carol', 'carol-test-3');
ok(true, 'three devices onboarded and connected to mock signaling');
await A.screenshot({ path: path.join(shots, '01-chats-empty.png') });

console.log('\n# Add contact via UI + first message');
await A.click('.tabbtn[aria-label="Contacts"]');
await A.click('.fab[aria-label="Add contact"]');
await A.fill('.sheet input[placeholder^="e.g."]', 'bob-test-22');
await A.fill('.sheet input[placeholder="Name (optional)"]', 'Bob');
await A.click('.sheet .btn.primary.wide');
await A.waitForSelector('.page[data-page="chat"]');
ok(true, 'chat opened after adding contact');
await until(() => ev(A, () => window.__pl.net.isOnline('bob-test-22')), 8000, 'A↔B link');
ok(true, 'authenticated P2P link established (signed handshake)');
await A.fill('.composer textarea', 'Hello Bob 👋 emoji ✓');
await A.click('.send-btn');
await until(() => ev(B, () => window.__pl.D.getChat('alice-test-1')?.last?.text?.includes('Hello Bob')), 8000, 'B got msg');
ok(true, 'B received message (as a request from unknown sender)');
ok(await ev(B, () => window.__pl.D.getChat('alice-test-1').request === true), 'unknown sender flagged as message request');
ok(await ev(B, () => window.__pl.D.getChat('alice-test-1').unread === 1), 'unread counter incremented');
await until(async () => (await ev(A, async () => (await window.__pl.db.msgAll('bob-test-22')).find((m) => m.kind === 'text')?.status)) === 'delivered', 6000, 'delivered');
ok(true, 'A sees "delivered" ack');

console.log('\n# B accepts request, opens chat, replies, read receipts, typing');
await B.click('.crow');
await B.waitForSelector('.page[data-page="chat"] .banner.warn');
await B.click('.banner.warn .btn.primary');
await B.waitForSelector('.banner.warn', { state: 'detached' });
await B.fill('.composer textarea', 'Hi Alice!');
await until(() => ev(A, () => (window.__pl.S.typing.get('bob-test-22')?.size || 0) > 0), 4000, 'typing').then(() => ok(true, 'A sees typing indicator from B')).catch(() => ok(false, 'typing indicator'));
await B.click('.send-btn');
await until(async () => (await ev(A, async () => (await window.__pl.db.msgAll('bob-test-22')).find((m) => m.kind === 'text' && m.from === window.__pl.S.me.id)?.status)) === 'read', 6000, 'read');
ok(true, 'A sees "read" receipt after B opened the chat');
await A.screenshot({ path: path.join(shots, '02-chat.png') });

console.log('\n# Reactions, reply, edit, delete');
const firstId = await ev(A, async () => (await window.__pl.db.msgAll('bob-test-22')).find((m) => m.kind === 'text' && m.from === window.__pl.S.me.id).id);
await ev(A, (id) => window.__pl.chat.react(id, '❤️'), firstId);
await until(async () => (await ev(B, async (id) => (await window.__pl.D.getMsg(id))?.reactions?.['❤️']?.length, firstId)) === 1, 5000, 'reaction');
ok(true, 'reaction synced to B');
await ev(A, (id) => window.__pl.chat.editMessage(id, 'Hello Bob (edited)'), firstId);
await until(async () => (await ev(B, async (id) => (await window.__pl.D.getMsg(id))?.text, firstId)) === 'Hello Bob (edited)', 5000, 'edit');
ok(true, 'edit synced to B');
await ev(A, async () => { const m = (await window.__pl.db.msgAll('bob-test-22')).find((x) => x.from === 'bob-test-22'); await window.__pl.chat.sendText('bob-test-22', 'reply!', { replyTo: m }); });
await until(async () => (await ev(B, async () => (await window.__pl.db.msgAll('alice-test-1')).some((m) => m.replyTo && m.text === 'reply!'))), 5000, 'reply');
ok(true, 'reply with quote delivered');
await ev(A, (id) => window.__pl.chat.deleteMessage(id, true), firstId);
await until(async () => (await ev(B, async (id) => (await window.__pl.D.getMsg(id))?.deleted, firstId)) === true, 5000, 'del');
ok(true, 'delete-for-everyone synced');

console.log('\n# File transfer (small, auto-accept) + integrity');
const mk = (size) => `(() => { const b = new Uint8Array(${size}); let x = 12345; for (let i = 0; i < b.length; i++) { x = (x * 1103515245 + 12345) & 0x7fffffff; b[i] = x >> 16; } return b; })()`;
const sha = `async (blob) => [...new Uint8Array(await crypto.subtle.digest('SHA-256', await blob.arrayBuffer()))].map((n) => n.toString(16).padStart(2, '0')).join('')`;
const sent = await ev(A, async ([mkSrc, shaSrc]) => {
  const bytes = eval(mkSrc); const f = new File([bytes], 'test-data.bin', { type: 'application/octet-stream' });
  const m = await window.__pl.transfer.sendFile('bob-test-22', f);
  return { id: m.id, hash: await eval(shaSrc)(f) };
}, [mk(3 * 1024 * 1024 + 123), sha]);
await until(async () => (await ev(B, async (id) => (await window.__pl.D.getMsg(id))?.file?.state, sent.id)) === 'done', 15000, 'file done');
const rhash = await ev(B, async ([id, shaSrc]) => eval(shaSrc)(await window.__pl.transfer.blob(id)), [sent.id, sha]);
ok(rhash === sent.hash, `3 MB file received intact (sha256 match)`);
await until(async () => (await ev(A, async (id) => (await window.__pl.D.getMsg(id))?.file?.state, sent.id)) === 'sent', 5000, 'sender state');
ok(true, 'sender marked file as sent after receiver confirmation');

console.log('\n# Large file, manual accept, link drop → auto resume');
await ev(B, () => window.__pl.S.settings.autoAcceptMB = 1); // force manual accept for >1MB
const big = await ev(A, async ([mkSrc, shaSrc]) => {
  const bytes = eval(mkSrc); const f = new File([bytes], 'big-video.mp4', { type: 'video/mp4' });
  const m = await window.__pl.transfer.sendFile('bob-test-22', f);
  return { id: m.id, hash: await eval(shaSrc)(f) };
}, [mk(24 * 1024 * 1024 + 77), sha]);
await until(async () => (await ev(B, async (id) => window.__pl.transfer.progress(id)?.state, big.id)) === 'offered', 8000, 'offered');
ok(true, 'large file waits for manual acceptance');
await ev(B, () => { // deterministic network drop after 40 chunks (2.5 MB)
  const t = window.__pl.transfer, orig = t._onChunk.bind(t);
  t._onChunk = async (s, d) => { await orig(s, d); if (s.next === 40 && !window.__dropped) { window.__dropped = true; window.__pl.net.closeLink(s.peer); } };
});
await ev(B, (id) => window.__pl.transfer.accept(`${id}|alice-test-1`), big.id);
await until(() => ev(B, () => window.__dropped === true), 15000, 'dropped');
await until(async () => (await ev(B, async (id) => window.__pl.transfer.progress(id)?.state, big.id)) === 'paused', 5000, 'paused');
await B.screenshot({ path: path.join(shots, '03-transfer-paused.png') });
ok(true, 'transfer paused when the link dropped');
await ev(A, () => window.__pl.net.connect('bob-test-22'));      // link returns
await until(async () => (await ev(B, async (id) => (await window.__pl.D.getMsg(id))?.file?.state, big.id)) === 'done', 40000, 'resumed done');
const bhash = await ev(B, async ([id, shaSrc]) => eval(shaSrc)(await window.__pl.transfer.blob(id)), [big.id, sha]);
ok(bhash === big.hash, '24 MB file resumed after drop and verified (sha256 match)');
await ev(B, () => window.__pl.S.settings.autoAcceptMB = 25);

console.log('\n# Reject path');
await ev(B, () => window.__pl.S.settings.autoAcceptMB = 0);
const rj = await ev(A, async () => { const f = new File([new Uint8Array(70000)], 'nope.txt', { type: 'text/plain' }); return (await window.__pl.transfer.sendFile('bob-test-22', f)).id; });
await until(async () => (await ev(B, async (id) => window.__pl.transfer.progress(id)?.state, rj)) === 'offered', 6000, 'offered2');
await ev(B, (id) => window.__pl.transfer.reject(`${id}|alice-test-1`), rj);
await until(async () => (await ev(A, async (id) => (await window.__pl.D.getMsg(id))?.file?.state, rj)) === 'rejected', 6000, 'rejected');
ok(true, 'sender notified of declined file');
await ev(B, () => window.__pl.S.settings.autoAcceptMB = 25);

console.log('\n# Transfer integrity, pause/resume, queue, bandwidth limit');
const sm = await ev(B, async (id) => (await window.__pl.D.getMsg(id)).file, sent.id);
ok(sm.sha === sent.hash && sm.verified === true, 'receiver verified the end-to-end SHA-256 of the 3 MB file');
const sa = await ev(A, async (id) => (await window.__pl.D.getMsg(id)).file.sha, sent.id);
ok(sa === sent.hash, 'sender recorded the same SHA-256');

// A tampered checksum must be rejected by the receiver
await ev(A, () => { const n = window.__pl.net, orig = n.trySend.bind(n); window.__origTrySend = orig; n.trySend = (id, o) => orig(id, o.t === 'fend' ? { ...o, sha: '0'.repeat(64) } : o); });
const tamperId = await ev(A, async () => (await window.__pl.transfer.sendFile('bob-test-22', new File([new Uint8Array(200000).fill(7)], 'tamper.bin', { type: 'application/octet-stream' }))).id);
await until(async () => (await ev(B, async (id) => (await window.__pl.D.getMsg(id))?.file?.state, tamperId)) === 'failed', 8000, 'tamper rejected');
ok(true, 'receiver rejects a file whose checksum does not match');
await ev(A, () => { window.__pl.net.trySend = window.__origTrySend; });

// Bandwidth cap + manual pause / resume (receiver pauses, then sender pauses)
await ev(A, () => { window.__pl.S.settings.sendLimitKBps = 2048; });
const slow = await ev(A, async ([mkSrc, shaSrc]) => {
  const f = new File([eval(mkSrc)], 'slow.bin', { type: 'application/octet-stream' });
  const m = await window.__pl.transfer.sendFile('bob-test-22', f);
  return { id: m.id, h: await eval(shaSrc)(f), t0: Date.now() };
}, [mk(10 * 1024 * 1024), sha]);
await until(async () => (await ev(B, async (id) => window.__pl.transfer.progress(id)?.bytes, slow.id)) > 1.5 * 1024 * 1024, 12000, 'slow progress');
await ev(B, (id) => window.__pl.transfer.pause(id), slow.id);
await sleep(400);
const b1 = await ev(B, (id) => window.__pl.transfer.progress(id), slow.id);
const a1 = await ev(A, (id) => window.__pl.transfer.progress(id), slow.id);
await sleep(1500);
const b2 = await ev(B, (id) => window.__pl.transfer.progress(id), slow.id);
ok(b1.state === 'paused' && b1.userPaused && a1.state === 'paused' && a1.pausedBy === 'peer', 'receiver pause is mirrored on the sender');
ok(b2.bytes === b1.bytes, 'no data flows while paused');
ok((await ev(A, (id) => window.__pl.transfer.resume(id), slow.id)) === false, 'the other side cannot override a pause');
await ev(B, (id) => window.__pl.transfer.resume(id), slow.id);
await until(async () => (await ev(A, async (id) => window.__pl.transfer.progress(id)?.state, slow.id)) === 'sending', 8000, 'resumed sending');
await sleep(500);
await ev(A, (id) => window.__pl.transfer.pause(id), slow.id);
await sleep(300);
ok((await ev(B, (id) => window.__pl.transfer.progress(id)?.state, slow.id)) === 'paused', 'sender pause is mirrored on the receiver');
await ev(A, (id) => window.__pl.transfer.resume(id), slow.id);
await until(async () => (await ev(B, async (id) => (await window.__pl.D.getMsg(id))?.file?.state, slow.id)) === 'done', 40000, 'slow done');
const slowHash = await ev(B, async ([id, shaSrc]) => eval(shaSrc)(await window.__pl.transfer.blob(id)), [slow.id, sha]);
ok(slowHash === slow.h, '10 MB file intact after pausing/resuming from both sides');
ok(Date.now() - slow.t0 > 3500, `bandwidth cap respected (10 MB at 2 MB/s took ${((Date.now() - slow.t0) / 1000).toFixed(1)} s)`);

// Queue: 4 files at once -> at most 2 send concurrently, all finish
const ids = await ev(A, async () => { const out = []; for (let i = 0; i < 4; i++) out.push((await window.__pl.transfer.sendFile('bob-test-22', new File([new Uint8Array(3 * 1024 * 1024).fill(i + 1)], `q${i}.bin`))).id); return out; });
await sleep(1200);
const states = await ev(A, (l) => l.map((id) => window.__pl.transfer.progress(id)?.state), ids);
ok(states.filter((x) => x === 'sending').length <= 2 && states.includes('queued'), `queue limits concurrency (${states.join(', ')})`);
await until(async () => (await ev(B, async (l) => (await Promise.all(l.map((id) => window.__pl.D.getMsg(id)))).every((m) => m?.file?.state === 'done'), ids)), 60000, 'queue drained');
ok(true, 'all queued files completed');
await ev(A, () => { window.__pl.S.settings.sendLimitKBps = 0; });

console.log('\n# Offline outbox: message to an offline peer is queued then delivered');
await ev(A, () => window.__pl.D.saveContact({ id: 'carol-test-3', name: 'Carol', alias: '', emoji: '', color: '', fp: null, addedAt: Date.now(), blocked: false }));
await ev(A, () => window.__pl.chat.ensureDm('carol-test-3'));
await C.evaluate(() => window.__pl.net.stop());                 // carol goes offline
await sleep(300);
const q = await ev(A, async () => (await window.__pl.chat.sendText('carol-test-3', 'while you were away')).id);
await until(async () => (await ev(A, async (id) => (await window.__pl.D.getMsg(id))?.status, q)) === 'queued', 6000, 'queued');
ok(true, 'message to offline contact is queued');
await C.evaluate(() => window.__pl.net.start());
await until(() => ev(C, () => window.__pl.net.state === 'online'), 6000, 'carol back');
await ev(A, () => window.__pl.chat.retryOutbox());
await until(async () => (await ev(C, async () => (await window.__pl.db.msgAll('alice-test-1')).some((m) => m.text === 'while you were away'))), 12000, 'carol got queued');
ok(true, 'queued message delivered when contact returned');

console.log('\n# Groups');
await ev(B, () => window.__pl.chat.addContact('carol-test-3', 'Carol'));
await ev(C, () => window.__pl.chat.addContact('alice-test-1', 'Alice'));
await ev(C, () => window.__pl.chat.addContact('bob-test-22', 'Bob'));
const gid = await ev(A, async () => (await window.__pl.chat.createGroup('Trip crew', ['bob-test-22', 'carol-test-3'])).id);
await until(async () => (await ev(B, (g) => !!window.__pl.D.getChat(g), gid)) && (await ev(C, (g) => !!window.__pl.D.getChat(g), gid)), 10000, 'group invite');
ok(true, 'group invitation reached both members');
await ev(B, async (g) => { await window.__pl.chat.sendText(g, 'group hello from bob'); }, gid);
await until(async () => (await ev(A, async (g) => (await window.__pl.db.msgAll(g)).some((m) => m.text === 'group hello from bob'), gid)) && (await ev(C, async (g) => (await window.__pl.db.msgAll(g)).some((m) => m.text === 'group hello from bob'), gid)), 12000, 'group fanout');
ok(true, 'group message fanned out to all members (mesh)');
await ev(A, async (g) => { await window.__pl.chat.renameGroup(window.__pl.D.getChat(g), 'Renamed crew'); }, gid);
await until(async () => (await ev(C, (g) => window.__pl.D.getChat(g).title, gid)) === 'Renamed crew', 8000, 'rename');
ok(true, 'admin rename propagated');
await ev(C, async (g) => { await window.__pl.chat.leaveGroup(window.__pl.D.getChat(g)); }, gid);
await until(async () => (await ev(A, (g) => window.__pl.D.getChat(g).members.length, gid)) === 2, 8000, 'leave');
ok(true, 'member leave processed by admin');

console.log('\n# Disappearing messages');
await ev(A, async () => { await window.__pl.chat.setTtl(window.__pl.D.getChat('bob-test-22'), 300); });
await until(async () => (await ev(B, () => window.__pl.D.getChat('alice-test-1').ttl)) === 300, 6000, 'ttl');
ok(true, 'timer setting synced');

console.log('\n# Voice note');
await ev(A, async () => {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  const rec = new MediaRecorder(stream); const ch = []; rec.ondataavailable = (e) => ch.push(e.data);
  rec.start(100); await new Promise((r) => setTimeout(r, 1500)); await new Promise((r) => { rec.onstop = r; rec.stop(); });
  stream.getTracks().forEach((t) => t.stop());
  const f = new File([new Blob(ch, { type: rec.mimeType })], 'voice.webm', { type: rec.mimeType });
  await window.__pl.transfer.sendFile('bob-test-22', f, { kind: 'voice', dur: 2, wave: Array.from({ length: 40 }, (_, i) => (i % 7) / 7) });
});
await until(async () => (await ev(B, async () => (await window.__pl.db.msgAll('alice-test-1')).some((m) => m.kind === 'voice' && m.file.state === 'done'))), 10000, 'voice');
ok(true, 'voice note auto-downloaded on B');

console.log('\n# Calls');
await ev(A, () => window.__pl.calls.start('bob-test-22', true));
await until(() => ev(B, () => window.__pl.calls.cur?.state === 'ringing'), 8000, 'ringing');
ok(true, 'B rings on incoming video call');
await B.waitForSelector('.call-screen .cbtn.green');
await B.screenshot({ path: path.join(shots, '04-incoming-call.png') });
await B.click('.call-screen .cbtn.green');
await until(async () => (await ev(A, () => window.__pl.calls.cur?.state)) === 'active' && (await ev(B, () => window.__pl.calls.cur?.state)) === 'active', 15000, 'call active');
ok(true, 'call connected on both sides (real WebRTC media)');
await sleep(1200);
await A.screenshot({ path: path.join(shots, '05-call-active.png') });
await ev(A, () => window.__pl.calls.toggleMute());
ok(await ev(A, () => window.__pl.calls.cur.muted === true), 'mute toggles');
await ev(A, () => window.__pl.calls.hangup());
await until(async () => !(await ev(B, () => window.__pl.calls.cur)), 6000, 'call ended B');
ok(true, 'hang-up ended the call on both sides');
await until(async () => (await ev(A, async () => (await window.__pl.db.msgAll('bob-test-22')).some((m) => m.kind === 'call'))), 3000, 'call log');
ok(true, 'call logged in chat history');
await ev(B, () => window.__pl.calls.start('alice-test-1', false)); await until(() => ev(A, () => window.__pl.calls.cur?.state === 'ringing'), 8000, 'ringing2');
await ev(A, () => window.__pl.calls.decline());
await until(async () => !(await ev(B, () => window.__pl.calls.cur)), 6000, 'declined');
ok(true, 'declined call handled');

console.log('\n# Polls, contact cards, stars, compressed photos');
const pollMsg = await ev(A, async () => (await window.__pl.chat.sendPoll('bob-test-22', 'Pizza tonight?', ['Yes', 'No', 'Maybe'], false)).id);
await until(async () => !!(await ev(B, (id) => window.__pl.D.getMsg(id), pollMsg)), 8000, 'poll arrives');
const pm = await ev(B, (id) => window.__pl.D.getMsg(id), pollMsg);
ok(pm.kind === 'poll' && pm.poll.q === 'Pizza tonight?' && pm.poll.o.length === 3, 'poll delivered with its options');
await ev(B, (id) => window.__pl.chat.vote(id, ['a', 'c']), pollMsg);   // single-choice poll: only the first option counts
await until(async () => ((await ev(A, async (id) => (await window.__pl.D.getMsg(id)).votes?.a?.length, pollMsg)) === 1), 8000, 'vote synced');
const av = await ev(A, async (id) => (await window.__pl.D.getMsg(id)).votes, pollMsg);
ok(av.a?.[0] === 'bob-test-22' && !av.c, 'vote synced back and extra choices ignored in a single-choice poll');
await ev(A, (id) => window.__pl.chat.vote(id, ['b']), pollMsg);
await ev(B, (id) => window.__pl.chat.vote(id, ['b']), pollMsg);
await until(async () => ((await ev(A, async (id) => (await window.__pl.D.getMsg(id)).votes?.b?.length, pollMsg)) === 2), 8000, 'two votes');
ok(!(await ev(A, async (id) => (await window.__pl.D.getMsg(id)).votes?.a, pollMsg)), 'changing a vote moves it (no double counting)');
const bogus = await ev(A, async () => { await window.__pl.net.send('bob-test-22', { t: 'msg', id: 'bad-poll', ts: Date.now(), kind: 'poll', poll: { q: 'x', o: [{ id: 'a', t: 'only one' }] } }); await new Promise((r) => setTimeout(r, 400)); return null; });
ok(!(await ev(B, () => window.__pl.D.getMsg('bad-poll'))), 'malformed polls are rejected by the receiver');
const card = await ev(A, async () => (await window.__pl.chat.sendContact('bob-test-22', 'carol-test-3')).id);
await until(async () => !!(await ev(B, (id) => window.__pl.D.getMsg(id), card)), 8000, 'card arrives');
const cm = await ev(B, (id) => window.__pl.D.getMsg(id), card);
ok(cm.kind === 'contact' && cm.contact.id === 'carol-test-3', 'contact card delivered');
await ev(B, (id) => window.__pl.chat.toggleStar(id), pollMsg);
ok(await ev(B, async (id) => (await window.__pl.D.getMsg(id)).starred === true, pollMsg), 'message can be starred');
const comp = await ev(A, async () => {
  const cv = document.createElement('canvas'); cv.width = 3200; cv.height = 2400; const g = cv.getContext('2d');
  for (let i = 0; i < 400; i++) { g.fillStyle = `hsl(${i * 7 % 360} 70% 50%)`; g.fillRect((i * 37) % 3200, (i * 53) % 2400, 200, 160); }
  const blob = await new Promise((r) => cv.toBlob(r, 'image/png')); const f = new File([blob], 'big.png', { type: 'image/png' });
  const out = await window.__pl.compressImage(f); const bmp = await createImageBitmap(out);
  return { before: f.size, after: out.size, type: out.type, w: bmp.width, h: bmp.height, name: out.name };
});
ok(comp.type === 'image/jpeg' && Math.max(comp.w, comp.h) === 1600 && comp.after < comp.before, `photo compression (${(comp.before / 1024).toFixed(0)} KB PNG 3200x2400 -> ${(comp.after / 1024).toFixed(0)} KB JPEG ${comp.w}x${comp.h})`);
await A.evaluate(() => { while (document.querySelector('#pages .page')) document.querySelector('#pages .page').remove(); });
await ev(A, () => window.__pl.bus.emit('open-chat', 'bob-test-22'));
await A.waitForSelector('.page[data-page="chat"] .poll');
await A.screenshot({ path: path.join(shots, '09-poll.png') });
await A.evaluate(() => { while (document.querySelector('#pages .page')) document.querySelector('#pages .page').remove(); });

console.log('\n# Verified invites (QR fingerprint)');
const bobFp = await ev(A, () => window.__pl.net.link('bob-test-22').info.fp);
await ev(A, async () => { window.__pl.net.closeLink('bob-test-22'); await window.__pl.D.removeContact('bob-test-22'); });
await ev(A, (fp) => window.__pl.chat.addContact('bob-test-22', 'Bob', { fp, via: 'qr' }), bobFp);
await ev(A, () => window.__pl.net.connect('bob-test-22'));
await until(async () => (await ev(A, () => window.__pl.D.getContact('bob-test-22').verified)) === true, 8000, 'verified by qr');
const cb = await ev(A, () => window.__pl.D.getContact('bob-test-22'));
ok(cb.verified && cb.verifiedBy === 'qr' && cb.fp === bobFp && !cb.expectedFp, 'matching QR fingerprint -> contact pinned and marked verified in person');
await ev(A, async () => { window.__pl.net.closeLink('carol-test-3'); await window.__pl.D.removeContact('carol-test-3'); });
await ev(A, () => window.__pl.chat.addContact('carol-test-3', 'Carol', { fp: 'a'.repeat(40), via: 'qr' }));
await ev(A, () => window.__pl.net.connect('carol-test-3'));
await until(async () => !!(await ev(A, () => window.__pl.D.getContact('carol-test-3').keyChanged)), 8000, 'mismatch flagged');
const cc = await ev(A, () => window.__pl.D.getContact('carol-test-3'));
ok(cc.keyChanged.unexpected === true && !cc.fp && !cc.verified, 'mismatching QR fingerprint -> impostor warning, key NOT pinned, not verified');

console.log('\n# Key pinning / impersonation warning');
await ev(A, async () => { const c = window.__pl.D.getContact('bob-test-22'); c.fp = 'deadbeef'.repeat(5); await window.__pl.D.saveContact(c); window.__pl.net.closeLink('bob-test-22'); });
await sleep(300);
await ev(A, () => window.__pl.net.connect('bob-test-22'));
await until(async () => !!(await ev(A, () => window.__pl.D.getContact('bob-test-22').keyChanged)), 6000, 'keyChanged');
ok(true, 'changed identity key is flagged (TOFU mismatch)');

console.log('\n# Payload hygiene + self-test + delivery explanations');
ok(await ev(A, async () => { const { clean } = await import('./main.js').catch(() => ({})); return true; }) === true, 'page ready');
// undefined values must never reach the wire (real BinaryPack rejects them)
const sendSpy = await ev(A, async () => {
  const l = window.__pl.net.link('bob-test-22'); const c = l.best(window.__pl.net.myId); const seen = [];
  const orig = c.send.bind(c); c.send = (o) => { seen.push(JSON.stringify(o, (k, v) => (v === undefined ? '__UNDEF__' : v))); return orig(o); };
  await window.__pl.chat.sendText('bob-test-22', 'hygiene check');
  await new Promise((r) => setTimeout(r, 300)); c.send = orig;
  return seen.some((x) => x.includes('__UNDEF__'));
});
ok(sendSpy === false, 'outgoing messages contain no undefined fields');
const st = await ev(A, async () => { const m = await import('./main.js'); return null; }).catch(() => null);
await A.evaluate(() => { while (document.querySelector('#pages .page')) document.querySelector('#pages .page').remove(); });
await A.evaluate(() => window.__pl.bus.emit('open-diagnostics', { run: true }));
await A.waitForSelector('.st-row', { timeout: 10000 });
await until(() => A.evaluate(() => [...document.querySelectorAll('.st-row')].length >= 7 && [...document.querySelectorAll('.st-row')].every((r) => !r.classList.contains('running'))), 90000, 'self-test finished');
const rows = await A.evaluate(() => [...document.querySelectorAll('.st-row')].map((r) => `${r.className.replace('st-row ', '')}: ${r.querySelector('b').textContent}`));
console.log(rows.map((r) => '    ' + r).join('\n'));
ok(rows.find((r) => /WebRTC data channel/.test(r))?.startsWith('ok'), 'self-test: WebRTC loopback passes in this browser');
ok(rows.find((r) => /PeerJS end-to-end/.test(r))?.startsWith('ok'), 'self-test: two-peer PeerJS round trip (unicode + binary + 40 KB) passes');
ok(rows.find((r) => /Local storage/.test(r))?.startsWith('ok') && rows.find((r) => /Identity keys/.test(r))?.startsWith('ok'), 'self-test: storage + crypto pass');
await A.screenshot({ path: path.join(shots, '06-selftest.png') });
await A.evaluate(() => { while (document.querySelector('#pages .page')) document.querySelector('#pages .page').remove(); });

// Deep-link/emulator entry point prints machine-readable results to the console (logcat on Android)
const stLines = []; A.on('console', (m) => { if (m.text().startsWith('PeerLink-selftest')) stLines.push(m.text()); });
await ev(A, () => window.__pl.autoSelfTest());
ok(stLines[0] === 'PeerLink-selftest: START' && stLines.at(-1) === 'PeerLink-selftest: DONE' && stLines.some((l) => /^PeerLink-selftest: OK \| WebRTC data channel/.test(l)), 'autoSelfTest logs START / per-test lines / DONE for the emulator job');

// A queued message exposes a reason and the explanation sheet
await C.evaluate(() => window.__pl.net.stop()); await sleep(300);
const q2 = await ev(A, async () => (await window.__pl.chat.sendText('carol-test-3', 'explain me')).id);
await until(async () => (await ev(A, async (id) => (await window.__pl.D.getMsg(id))?.status, q2)) === 'queued', 8000, 'queued2');
const why = await ev(A, async (id) => (await window.__pl.D.getMsg(id)).err, q2);
ok(why === 'peer-unavailable', `queued message records why (${why})`);
await A.evaluate(() => window.__pl.D.getChat('carol-test-3')); 
await ev(A, () => window.__pl.bus.emit('open-chat', 'carol-test-3'));
await A.waitForSelector('.page[data-page="chat"] .tick.bad');
await A.click('.page[data-page="chat"] .tick.bad');
await A.waitForSelector('.sheet .sheet-note');
const expl = await A.textContent('.sheet .sheet-note');
ok(/not connected to the PeerJS server/.test(expl), 'tapping the clock explains the delivery problem in plain language');
await A.screenshot({ path: path.join(shots, '07-delivery-explained.png') });
await A.keyboard.press('Escape'); await A.evaluate(() => document.querySelector('.backdrop')?.click());
await C.evaluate(() => window.__pl.net.start()); await until(() => ev(C, () => window.__pl.net.state === 'online'), 8000, 'carol back2');

console.log('\n# TURN / network settings');
// ICE servers from a credentials URL are validated and merged; TURN-only lists get STUN added
await ev(A, (u) => { window.__pl.S.settings.ice = { ...window.__pl.S.settings.ice, mode: 'default', fetchUrl: u }; }, `http://localhost:${port}/ice.json`);
const ice1 = await ev(A, () => window.__pl.net.resolveIce());
ok(ice1.some((e) => [].concat(e.urls).includes('turn:turn.test.example:3478') && e.username === 'u1' && e.credential === 'c1'), 'ICE JSON URL: TURN entry with credentials loaded');
ok(!JSON.stringify(ice1).includes('javascript:') && !JSON.stringify(ice1).includes('bad:ignored'), 'ICE JSON URL: malformed / unsafe URLs are dropped');
await ev(A, () => { window.__pl.S.settings.ice = { ...window.__pl.S.settings.ice, fetchUrl: 'http://localhost:1/nothing' }; });
const ice2 = await ev(A, () => window.__pl.net.resolveIce());
ok(ice2.some((e) => [].concat(e.urls).includes('turn:turn.test.example:3478')), 'ICE JSON URL: falls back to the last good cached list when the URL is unreachable');
await ev(A, () => { window.__pl.S.settings.ice = { mode: 'custom', servers: 'turn:only.example:3478,user,pass', relayOnly: false, fetchUrl: '' }; });
const ice3 = await ev(A, () => window.__pl.net.resolveIce());
ok(ice3.some((e) => [].concat(e.urls).some((u) => u.startsWith('stun:'))) && ice3.some((e) => [].concat(e.urls).includes('turn:only.example:3478')), 'TURN-only custom list gets default STUN servers added');
await ev(A, () => { window.__pl.S.settings.ice = { mode: 'default', servers: '', relayOnly: false, fetchUrl: '' }; });
await ev(A, () => window.__pl.net.restart());
await until(() => ev(A, () => window.__pl.net.state === 'online'), 8000, 'A restarted');

await A.evaluate(() => { while (document.querySelector('#pages .page')) document.querySelector('#pages .page').remove(); });
await A.click('.tabbtn[aria-label="Settings"]'); await sleep(300);
await A.click('text=Network & servers'); await A.waitForSelector('.page[data-page="network"]');
await A.fill('.page[data-page="network"] input[placeholder="turn:turn.example.com:3478"]', 'turn:quick.example:3478');
await A.fill('.page[data-page="network"] input[placeholder="Username"]', 'bob');
await A.fill('.page[data-page="network"] input[placeholder="Password / credential"]', 'secret');
await A.click('.page[data-page="network"] button:has-text("Add to list")');
ok((await A.inputValue('.page[data-page="network"] textarea')).includes('turn:quick.example:3478,bob,secret'), 'quick-add form writes a url,user,credential line');
await A.click('.page[data-page="network"] button:has-text("Test servers")');
await A.waitForSelector('.page[data-page="network"] .st-row', { timeout: 20000 });
await until(() => A.evaluate(() => document.querySelector('.page[data-page="network"] .banner.warn + .btn-row, .page[data-page="network"] .st-rows .banner.warn') !== null), 20000, 'test result banner');
ok(true, 'Test servers reports per-server results and warns when no TURN works');
await A.screenshot({ path: path.join(shots, '08-network-turn.png'), fullPage: false });
await A.click('.page[data-page="network"] button:has-text("Copy settings")');
const copied = await A.evaluate(() => navigator.clipboard.readText());
ok(copied.startsWith('peerlink-net:'), 'Copy settings puts a peerlink-net: code on the clipboard');
await A.evaluate(() => { while (document.querySelector('#pages .page')) document.querySelector('#pages .page').remove(); });

console.log('\n# UI screens render without errors');
for (const [tab, file] of [['Chats', '10-chats'], ['Transfers', '11-transfers'], ['Contacts', '12-contacts'], ['Settings', '13-settings']]) {
  await A.evaluate(() => { while (document.querySelector('#pages .page')) document.querySelector('#pages .page').remove(); });
  await A.click(`.tabbtn[aria-label="${tab}"]`);
  await sleep(350);
  await A.screenshot({ path: path.join(shots, `${file}.png`) });
}
await A.evaluate(() => window.__pl.S.settings.theme = 'dark');
await A.evaluate(() => document.documentElement.dataset.theme = 'dark');
await A.click('.tabbtn[aria-label="Chats"]'); await sleep(200);
await A.screenshot({ path: path.join(shots, '14-chats-dark.png') });
await A.click('.crow'); await sleep(500);
await A.screenshot({ path: path.join(shots, '15-chat-dark.png') });

console.log('\n# Summary');
const bad = errors.filter((e) => !/ResizeObserver|favicon|peerjs\.com|ERR_UNSAFE_PORT/.test(e));
ok(bad.length === 0, `no uncaught page errors (${bad.length})`);
if (bad.length) console.log(bad.slice(0, 8).join('\n'));
console.log(failures ? `\n${failures} FAILED` : '\nALL PASSED');
await browser.close(); server.close();
process.exit(failures ? 1 : 0);
