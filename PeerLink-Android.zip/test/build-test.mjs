import { createRequire } from 'module';
import fs from 'fs';
import path from 'path';
const require = createRequire('/home/claude/.npm-global/lib/node_modules/tsx/package.json');
const esbuild = require('esbuild');
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const stub = (f) => path.join(root, 'test/stubs', f);
fs.rmSync(path.join(root, 'test/dist'), { recursive: true, force: true });
fs.mkdirSync(path.join(root, 'test/dist'), { recursive: true });
const cap = ['@capacitor/core', '@capacitor/app', '@capacitor/splash-screen', '@capacitor/status-bar', '@capacitor/haptics', '@capacitor/local-notifications', '@capacitor/filesystem', '@capacitor/share'];
const alias = { peerjs: stub('mock-peerjs.js'), jsqr: stub('jsqr.js'), 'qrcode-generator': stub('qrcode.js') };
for (const c of cap) alias[c] = stub('capacitor.js');
const res = await esbuild.build({
  entryPoints: [path.join(root, 'src/main.js')], bundle: true, outdir: path.join(root, 'test/dist'), format: 'esm', splitting: true, target: 'chrome100',
  alias, loader: { '.css': 'css' }, logLevel: 'warning', sourcemap: 'inline', metafile: true,
});
let html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
html = html.replace('<script type="module" src="/src/main.js"></script>', '<link rel="stylesheet" href="./main.css"><script type="module" src="./main.js"></script>');
fs.writeFileSync(path.join(root, 'test/dist/index.html'), html);
console.log('bundled', Object.keys(res.metafile.outputs).length, 'files');
