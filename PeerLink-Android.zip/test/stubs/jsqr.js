export default function jsQR() { return null; }
