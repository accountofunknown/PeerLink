// Minimal stand-ins for the Capacitor plugins so the web bundle can run in plain Chromium.
export const Capacitor = { isNativePlatform: () => false };
const noop = async () => ({});
export const App = { addListener: () => ({ remove() {} }), getLaunchUrl: async () => null, minimizeApp: noop, exitApp: noop };
export const SplashScreen = { hide: noop, show: noop };
export const StatusBar = { setStyle: noop, setBackgroundColor: noop, setOverlaysWebView: noop };
export const Style = { Dark: 'DARK', Light: 'LIGHT' };
export const Haptics = { impact: noop, notification: noop, vibrate: noop };
export const ImpactStyle = { Heavy: 'HEAVY', Medium: 'MEDIUM', Light: 'LIGHT' };
export const NotificationType = { Success: 'SUCCESS' };
export const LocalNotifications = { checkPermissions: async () => ({ display: 'denied' }), requestPermissions: async () => ({ display: 'denied' }), createChannel: noop, addListener: () => ({ remove() {} }), schedule: noop, cancel: noop };
export const Filesystem = { writeFile: noop, appendFile: noop, getUri: async () => ({ uri: 'file:///x' }) };
export const Directory = { Documents: 'DOCUMENTS', Cache: 'CACHE' };
export const Share = { share: noop };
export const registerPlugin = () => new Proxy({}, { get: () => async () => ({ active: false, ignoringBatteryOptimizations: true }) });
