// Test-only QR stand-in (deterministic pseudo pattern). The real library is used in production builds.
export default function qrcode() {
  let data = '';
  return { addData(d) { data = d; }, make() {}, getModuleCount: () => 29, isDark: (r, c) => ((r * 31 + c * 17 + data.length) % 3) === 0 };
}
