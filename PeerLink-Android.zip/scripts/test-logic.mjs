// Fast offline sanity tests for pure helpers:  npm test
import assert from 'node:assert/strict';
globalThis.document = { createElement: () => ({ style: {}, setAttribute() {}, appendChild() {}, addEventListener() {} }), createTextNode: (t) => ({ t }) };
const u = await import('../src/util.js');

assert.equal(u.crc32(new TextEncoder().encode('123456789')), 0xcbf43926, 'crc32 check value');
assert.deepEqual(u.parseInvite('peerlink://add?id=swift-otter-4821&n=Ann'), { id: 'swift-otter-4821', name: 'Ann', fp: '' });
assert.deepEqual(u.parseInvite('  Swift-Otter-4821 '), { id: 'swift-otter-4821', name: '', fp: '' });
assert.equal(u.parseInvite('not valid!!'), null);
assert.equal(u.parseInvite('peerlink://add?id=a'), null);
for (const id of ['abcd', 'a-b-c-d', 'user_name-1234']) assert.ok(u.validId(id), id);
for (const id of ['abc', 'a--b', '-abc', 'abc-', 'a b c d', 'x'.repeat(49), 'ünï-code']) assert.ok(!u.validId(id), id);
for (let i = 0; i < 200; i++) assert.ok(u.validId(u.genPeerId()), 'generated ids are valid');
assert.deepEqual(u.parseIce('stun:a.com:3478\n# c\nturn:t.com:3478,user,pw\nbad'), [{ urls: 'stun:a.com:3478' }, { urls: 'turn:t.com:3478', username: 'user', credential: 'pw' }]);
assert.equal(u.fmtBytes(1536), '1.5 KB');
assert.equal(u.fmtDur(75), '1:15');
assert.ok(!/[\\/:*]/.test(u.safeName('a/b\\c:d*e')));
const b = crypto.getRandomValues(new Uint8Array(1000));
assert.deepEqual(u.unb64(u.b64(b)), b, 'base64 round-trip');
let t1 = u.tick(), t2 = u.tick(); assert.ok(t2 > t1, 'tick is strictly increasing');
const { Sha256 } = await import('../src/sha256.js');
const subtle = async (u8) => [...new Uint8Array(await crypto.subtle.digest('SHA-256', u8))].map((n) => n.toString(16).padStart(2, '0')).join('');
for (const n of [0, 1, 3, 55, 56, 57, 63, 64, 65, 119, 120, 128, 1000, 65536, 1048577]) {
  const d = crypto.getRandomValues(new Uint8Array(Math.min(n, 65536))); const full = n > 65536 ? new Uint8Array(n).map((_, i) => (i * 31 + 7) & 255) : d;
  assert.equal(new Sha256().update(full).hex(), await subtle(full), `sha256 one-shot ${n}`);
  const inc = new Sha256(); for (let i = 0; i < full.length; i += 37) inc.update(full.subarray(i, Math.min(full.length, i + 37)));
  assert.equal(inc.hex(), await subtle(full), `sha256 incremental ${n}`);
}
assert.equal(new Sha256().update(new TextEncoder().encode('abc')).hex(), 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad', 'sha256 known vector');
const fp40 = 'ab12'.repeat(10);
const inv = u.makeInvite('swift-otter-4821', 'Ann Lee', fp40);
assert.deepEqual(u.parseInvite(inv), { id: 'swift-otter-4821', name: 'Ann Lee', fp: fp40 }, 'invite carries the key fingerprint');
assert.equal(u.parseInvite(u.makeInvite('swift-otter-4821', 'x', 'zz')).fp, '', 'malformed fingerprints are ignored');
assert.equal(u.parseInvite('swift-otter-4821').fp, '', 'bare ids have no fingerprint');
console.log('all logic tests passed');
