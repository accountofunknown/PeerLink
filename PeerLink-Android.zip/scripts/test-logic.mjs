// Fast offline sanity tests for pure helpers:  npm test
import assert from 'node:assert/strict';
globalThis.document = { createElement: () => ({ style: {}, setAttribute() {}, appendChild() {}, addEventListener() {} }), createTextNode: (t) => ({ t }) };
const u = await import('../src/util.js');

assert.equal(u.crc32(new TextEncoder().encode('123456789')), 0xcbf43926, 'crc32 check value');
assert.deepEqual(u.parseInvite('peerlink://add?id=swift-otter-4821&n=Ann'), { id: 'swift-otter-4821', name: 'Ann' });
assert.deepEqual(u.parseInvite('  Swift-Otter-4821 '), { id: 'swift-otter-4821', name: '' });
assert.equal(u.parseInvite('not valid!!'), null);
assert.equal(u.parseInvite('peerlink://add?id=a'), null);
for (const id of ['abcd', 'a-b-c-d', 'user_name-1234']) assert.ok(u.validId(id), id);
for (const id of ['abc', 'a--b', '-abc', 'abc-', 'a b c d', 'x'.repeat(49), 'ünï-code']) assert.ok(!u.validId(id), id);
for (let i = 0; i < 200; i++) assert.ok(u.validId(u.genPeerId()), 'generated ids are valid');
assert.deepEqual(u.parseIce('stun:a.com:3478\n# c\nturn:t.com:3478,user,pw\nbad'), [{ urls: 'stun:a.com:3478' }, { urls: 'turn:t.com:3478', username: 'user', credential: 'pw' }]);
assert.equal(u.fmtBytes(1536), '1.5 KB');
assert.equal(u.fmtDur(75), '1:15');
assert.ok(!/[\\/:*]/.test(u.safeName('a/b\\c:d*e')));
const b = crypto.getRandomValues(new Uint8Array(1000));
assert.deepEqual(u.unb64(u.b64(b)), b, 'base64 round-trip');
let t1 = u.tick(), t2 = u.tick(); assert.ok(t2 > t1, 'tick is strictly increasing');
console.log('all logic tests passed');
