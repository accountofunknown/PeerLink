#!/usr/bin/env bash
# Installs the debug APK on a running emulator, launches it, and checks the WebView booted.
# Usage: scripts/emulator-smoke.sh <dir-containing-*-debug.apk>
set -euo pipefail
PKG=app.peerlink.messenger
APK=$(ls "$1"/*-debug.apk | head -n1)
echo "Installing $APK"
adb wait-for-device
adb shell input keyevent 82 || true
adb logcat -c
adb install -r "$APK"
adb shell monkey -p "$PKG" -c android.intent.category.LAUNCHER 1
fail=0
for i in $(seq 1 30); do
  sleep 2
  adb logcat -d > logcat.txt
  if grep -q "PeerLink-boot: onboarding" logcat.txt || grep -q "PeerLink-boot: ready" logcat.txt; then break; fi
done
echo "---- boot markers"; grep "PeerLink-boot" logcat.txt || true
if ! grep -qE "PeerLink-boot: (onboarding|ready)" logcat.txt; then echo "::error::App UI never reached onboarding/ready"; fail=1; fi
if grep -q "FATAL EXCEPTION" logcat.txt; then echo "::error::Crash detected"; grep -A15 "FATAL EXCEPTION" logcat.txt | head -40; fail=1; fi
if [ -z "$(adb shell pidof "$PKG" | tr -d '\r')" ]; then echo "::error::App process is not running"; fail=1; fi
adb exec-out screencap -p > screenshot.png || true

# ---- run the in-app self-test inside the REAL Android WebView (real network, real PeerJS cloud)
if [ $fail -eq 0 ]; then
  echo "---- in-app self-test via deep link"
  adb shell am start -a android.intent.action.VIEW -d "peerlink://selftest" -p "$PKG" >/dev/null || true
  for i in $(seq 1 60); do
    sleep 3
    adb logcat -d > logcat.txt
    grep -q "PeerLink-selftest: DONE" logcat.txt && break
  done
  echo "======== SELF-TEST RESULTS (Android WebView on emulator) ========"
  grep "PeerLink-selftest" logcat.txt | sed 's/.*Msg: //' || true
  echo "================================================================="
  if ! grep -q "PeerLink-selftest: DONE" logcat.txt; then echo "::warning::In-app self-test did not finish within 3 minutes"; fi
  grep "PeerLink-selftest: FAIL" logcat.txt | sed 's/.*Msg: //' | while read -r l; do echo "::warning::$l"; done || true
  adb exec-out screencap -p > screenshot-after.png || true
fi
exit $fail
