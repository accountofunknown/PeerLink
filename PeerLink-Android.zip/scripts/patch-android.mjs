// Patches the Capacitor-generated Android project (idempotent).
// Usage: node scripts/patch-android.mjs [androidDir]
import fs from 'node:fs';
import path from 'node:path';

const dir = path.resolve(process.argv[2] || 'android');
const manifestPath = path.join(dir, 'app/src/main/AndroidManifest.xml');
if (!fs.existsSync(manifestPath)) {
  console.error(`AndroidManifest.xml not found at ${manifestPath}. Run "npx cap add android" first.`);
  process.exit(1);
}
let xml = fs.readFileSync(manifestPath, 'utf8');
const before = xml;

const perms = [
  'android.permission.INTERNET', 'android.permission.ACCESS_NETWORK_STATE', 'android.permission.CHANGE_NETWORK_STATE',
  'android.permission.CAMERA', 'android.permission.RECORD_AUDIO', 'android.permission.MODIFY_AUDIO_SETTINGS',
  'android.permission.POST_NOTIFICATIONS', 'android.permission.VIBRATE', 'android.permission.WAKE_LOCK',
];
let add = '';
for (const p of perms) if (!xml.includes(`"${p}"`)) add += `    <uses-permission android:name="${p}" />\n`;
for (const p of ['READ_EXTERNAL_STORAGE', 'WRITE_EXTERNAL_STORAGE']) {
  if (!xml.includes(`android.permission.${p}`)) add += `    <uses-permission android:name="android.permission.${p}" android:maxSdkVersion="${p.startsWith('WRITE') ? 28 : 32}" />\n`;
}
for (const f of ['android.hardware.camera', 'android.hardware.camera.autofocus', 'android.hardware.microphone']) {
  if (!xml.includes(`"${f}"`)) add += `    <uses-feature android:name="${f}" android:required="false" />\n`;
}
if (add) xml = xml.replace('</manifest>', `\n    <!-- PeerLink -->\n${add}</manifest>`);

// <application> attributes. Values listed in `force` REPLACE whatever the template ships (allowBackup defaults to true).
const force = { 'android:allowBackup': 'false', 'android:fullBackupContent': 'false', 'android:dataExtractionRules': '@xml/data_extraction_rules' };
const soft = { 'android:largeHeap': 'true', 'android:requestLegacyExternalStorage': 'true', 'android:usesCleartextTraffic': 'false' };
xml = xml.replace(/<application\b([^>]*)>/, (m, attrs) => {
  for (const [k, v] of Object.entries(force)) {
    const re = new RegExp(`${k}="[^"]*"`);
    attrs = re.test(attrs) ? attrs.replace(re, `${k}="${v}"`) : `${attrs}\n        ${k}="${v}"`;
  }
  for (const [k, v] of Object.entries(soft)) if (!new RegExp(`${k}=`).test(attrs)) attrs += `\n        ${k}="${v}"`;
  return `<application${attrs}>`;
});

// Keep chats, keys and files out of cloud backup and device-to-device transfer (Android 12+ rules file).
const xmlDir = path.join(dir, 'app/src/main/res/xml');
fs.mkdirSync(xmlDir, { recursive: true });
const rules = `<?xml version="1.0" encoding="utf-8"?>
<data-extraction-rules>
    <cloud-backup>
        <exclude domain="root" />
        <exclude domain="file" />
        <exclude domain="database" />
        <exclude domain="sharedpref" />
        <exclude domain="external" />
    </cloud-backup>
    <device-transfer>
        <exclude domain="root" />
        <exclude domain="file" />
        <exclude domain="database" />
        <exclude domain="sharedpref" />
        <exclude domain="external" />
    </device-transfer>
</data-extraction-rules>
`;
fs.writeFileSync(path.join(xmlDir, 'data_extraction_rules.xml'), rules);

// MainActivity: resize for the keyboard + peerlink:// deep links
xml = xml.replace(/<activity\b([^>]*android:name="\.MainActivity"[^>]*)>/, (m, attrs) => {
  if (/android:windowSoftInputMode=/.test(attrs)) return m;
  return `<activity${attrs}\n            android:windowSoftInputMode="adjustResize">`;
});
if (!xml.includes('android:scheme="peerlink"')) {
  const filter = `
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="peerlink" />
            </intent-filter>
`;
  xml = xml.replace(/(<activity\b[^>]*android:name="\.MainActivity"[\s\S]*?)(<\/activity>)/, `$1${filter}        $2`);
}
if (xml !== before) { fs.writeFileSync(manifestPath, xml); console.log('patched AndroidManifest.xml'); } else console.log('AndroidManifest.xml already patched');

// Version from env (CI) so every build installs over the previous one.
const gradlePath = path.join(dir, 'app/build.gradle');
if (fs.existsSync(gradlePath)) {
  let g = fs.readFileSync(gradlePath, 'utf8');
  const code = process.env.VERSION_CODE, name = process.env.VERSION_NAME;
  if (code) g = g.replace(/versionCode\s+\d+/, `versionCode ${parseInt(code, 10)}`);
  if (name) g = g.replace(/versionName\s+"[^"]*"/, `versionName "${name}"`);
  fs.writeFileSync(gradlePath, g);
  console.log(`versionCode=${code || '(unchanged)'} versionName=${name || '(unchanged)'}`);
}
